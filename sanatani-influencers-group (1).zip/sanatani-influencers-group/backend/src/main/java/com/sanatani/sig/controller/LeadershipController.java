package com.sanatani.sig.controller;

import com.sanatani.sig.model.Leadership;
import com.sanatani.sig.repository.LeadershipRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/leadership")
public class LeadershipController {

    private final LeadershipRepository repo;

    public LeadershipController(LeadershipRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Leadership> all() {
        return repo.findAllByOrderByOrderIndexAsc();
    }

    @GetMapping("/president")
    public Leadership president() {
        List<Leadership> list = repo.findByIsPresidentTrue();
        return list.isEmpty() ? null : list.get(0);
    }
}
