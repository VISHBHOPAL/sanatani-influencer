package com.sanatani.sig.repository;

import com.sanatani.sig.model.Certificate;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface CertificateRepository extends JpaRepository<Certificate, Long> {
    Optional<Certificate> findByCertificateNumber(String certificateNumber);
    List<Certificate> findAllByOrderByCreatedAtDesc();
}
