package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "settings")
public class Setting {
    @Id
    @Column(name = "setting_key")
    private String key;

    @Column(name = "setting_value", columnDefinition = "LONGTEXT")
    private String value;

    public Setting() {}
    public Setting(String key, String value) {
        this.key = key;
        this.value = value;
    }
}
