package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.Instant;

@Data
@Entity
@Table(name = "event_registrations")
public class EventRegistration {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long eventId;
    private String registrationId; // EVT-2026-0001

    private String fullName;
    private String mobile;
    private String email;
    private String city;
    private Integer age;
    private String instagram;
    private String youtube;
    private String creatorCategory;
    private String followers;
    private String interestedIn;
    @Column(columnDefinition = "TEXT")
    private String volunteerExperience;

    private Boolean agreedTerms = false;
    private Instant createdAt = Instant.now();
}
