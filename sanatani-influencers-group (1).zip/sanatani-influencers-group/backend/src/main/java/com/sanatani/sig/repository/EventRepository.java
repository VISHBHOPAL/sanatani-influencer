package com.sanatani.sig.repository;

import com.sanatani.sig.model.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EventRepository extends JpaRepository<Event, Long> {
    List<Event> findByStatus(String status);
    List<Event> findAllByOrderByCreatedAtDesc();
}
