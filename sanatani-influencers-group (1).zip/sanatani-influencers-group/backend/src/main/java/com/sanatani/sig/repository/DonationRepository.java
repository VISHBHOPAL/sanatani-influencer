package com.sanatani.sig.repository;

import com.sanatani.sig.model.Donation;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface DonationRepository extends JpaRepository<Donation, Long> {
    Optional<Donation> findByDonationId(String donationId);
    Optional<Donation> findByOrderId(String orderId);
    List<Donation> findByStatus(String status);
    List<Donation> findAllByOrderByCreatedAtDesc();
}
