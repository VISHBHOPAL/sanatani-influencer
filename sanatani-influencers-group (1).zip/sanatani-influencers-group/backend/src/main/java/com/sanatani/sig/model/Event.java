package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.Instant;

@Data
@Entity
@Table(name = "events")
public class Event {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String banner;
    private String date;
    private String time;
    private String venue;
    private String mapsLocation;

    @Column(columnDefinition = "TEXT")
    private String description;

    private String organizer;
    private Boolean registrationRequired = true;
    private String registrationDeadline;
    private Integer maxParticipants;
    private String category; // Sanatan Event, Temple Event, Creator Meet...
    private String status = "UPCOMING"; // UPCOMING, ONGOING, PAST

    private Instant createdAt = Instant.now();
}
