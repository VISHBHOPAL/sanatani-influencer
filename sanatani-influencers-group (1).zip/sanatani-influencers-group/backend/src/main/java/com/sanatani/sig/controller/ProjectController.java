package com.sanatani.sig.controller;

import com.sanatani.sig.model.Project;
import com.sanatani.sig.repository.ProjectRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {

    private final ProjectRepository repo;

    public ProjectController(ProjectRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Project> all(@RequestParam(required = false) String category) {
        if (category != null) return repo.findByCategory(category);
        return repo.findAllByOrderByCreatedAtDesc();
    }

    @GetMapping("/temple-seva")
    public List<Project> templeSeva() {
        return repo.findByTempleSevaTrue();
    }

    @GetMapping("/{id}")
    public Project one(@PathVariable Long id) {
        return repo.findById(id).orElse(null);
    }
}
