package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.Instant;

@Data
@Entity
@Table(name = "news_articles", indexes = {
        @Index(name = "idx_news_slug", columnList = "slug", unique = true)
})
public class News {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String slug;
    private String featuredImage;

    @Column(columnDefinition = "LONGTEXT")
    private String content;

    private String author;
    private String date;
    private String category; // Announcement, Event, Seva Update...
    private String tags;

    private String seoTitle;
    @Column(columnDefinition = "TEXT")
    private String seoDescription;

    private Boolean published = false;
    private Instant createdAt = Instant.now();
}
