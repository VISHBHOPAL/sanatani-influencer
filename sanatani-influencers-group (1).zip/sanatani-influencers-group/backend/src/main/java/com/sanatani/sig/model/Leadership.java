package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "leadership")
public class Leadership {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String designation; // Founder, President / Adhyaksh, Vice President...
    @Column(columnDefinition = "TEXT")
    private String bio;
    private String photo;
    private String instagram;
    private String linkedin;
    private Boolean contactEnabled = false;
    private String email;

    private Integer orderIndex = 0;
    private Boolean isPresident = false;
    @Column(columnDefinition = "TEXT")
    private String presidentMessage; // अध्यक्ष का संदेश
    @Column(columnDefinition = "TEXT")
    private String vision;
}
