package com.sanatani.sig.repository;

import com.sanatani.sig.model.Leadership;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LeadershipRepository extends JpaRepository<Leadership, Long> {
    List<Leadership> findAllByOrderByOrderIndexAsc();
    List<Leadership> findByIsPresidentTrue();
}
