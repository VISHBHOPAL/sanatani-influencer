package com.sanatani.sig.dto;

import lombok.Data;

@Data
public class AuthResponse {
    private String token;
    private Long userId;
    private String name;
    private String email;
    private String role;
    private Long memberId;

    public AuthResponse(String token, Long userId, String name, String email, String role, Long memberId) {
        this.token = token;
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.role = role;
        this.memberId = memberId;
    }
}
