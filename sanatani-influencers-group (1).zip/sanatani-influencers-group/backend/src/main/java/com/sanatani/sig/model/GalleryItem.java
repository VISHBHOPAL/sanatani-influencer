package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.Instant;

@Data
@Entity
@Table(name = "gallery_items")
public class GalleryItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String category; // Events, Temple Seva, Creator Meets...
    private String imageUrl;
    private String videoUrl;
    private String album;
    @Column(columnDefinition = "TEXT")
    private String caption;
    private String date;
    private String location;

    private Instant createdAt = Instant.now();
}
