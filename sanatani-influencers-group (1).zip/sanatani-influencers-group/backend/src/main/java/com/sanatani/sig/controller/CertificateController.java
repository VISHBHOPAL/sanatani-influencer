package com.sanatani.sig.controller;

import com.sanatani.sig.dto.ApiResponse;
import com.sanatani.sig.model.Certificate;
import com.sanatani.sig.service.CertificateService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/certificates")
public class CertificateController {

    private final CertificateService service;

    public CertificateController(CertificateService service) {
        this.service = service;
    }

    // Public verification
    @GetMapping("/verify/{number}")
    public ResponseEntity<?> verify(@PathVariable String number) {
        Certificate c = service.verify(number);
        if (c == null) {
            return ResponseEntity.ok(Map.of("valid", false, "message", "No certificate found with this number."));
        }
        return ResponseEntity.ok(Map.of(
                "valid", "VALID".equals(c.getStatus()),
                "certificateNumber", c.getCertificateNumber(),
                "recipient", c.getRecipient(),
                "type", c.getType(),
                "eventProject", c.getEventProject() == null ? "" : c.getEventProject(),
                "issueDate", c.getIssueDate() == null ? "" : c.getIssueDate(),
                "issuedBy", c.getIssuedBy() == null ? "" : c.getIssuedBy(),
                "status", c.getStatus()));
    }
}
