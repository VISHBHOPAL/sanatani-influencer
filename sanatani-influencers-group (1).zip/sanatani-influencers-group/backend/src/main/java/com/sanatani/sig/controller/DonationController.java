package com.sanatani.sig.controller;

import com.sanatani.sig.dto.ApiResponse;
import com.sanatani.sig.model.Donation;
import com.sanatani.sig.repository.DonationRepository;
import com.sanatani.sig.service.DonationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/donations")
public class DonationController {

    private final DonationService donationService;
    private final DonationRepository donationRepository;

    public DonationController(DonationService donationService, DonationRepository donationRepository) {
        this.donationService = donationService;
        this.donationRepository = donationRepository;
    }

    @PostMapping("/create")
    public ResponseEntity<?> create(@RequestBody Donation donation) {
        if (donation.getAmount() == null || donation.getAmount() <= 0) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Please enter a valid donation amount."));
        }
        return ResponseEntity.ok(donationService.create(donation));
    }

    @PostMapping("/verify")
    public ResponseEntity<?> verify(@RequestBody Map<String, String> body) {
        try {
            Donation d = donationService.verify(
                    body.get("donationId"), body.get("orderId"),
                    body.get("paymentId"), body.get("signature"));
            return ResponseEntity.ok(ApiResponse.ok("Payment verified", d));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @GetMapping("/receipt/{donationId}")
    public ResponseEntity<?> receipt(@PathVariable String donationId) {
        Donation d = donationRepository.findByDonationId(donationId).orElse(null);
        if (d == null) return ResponseEntity.status(404).body(ApiResponse.error("Receipt not found"));
        if (!"SUCCESS".equals(d.getStatus())) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Receipt available only for successful payments"));
        }
        return ResponseEntity.ok(d);
    }

    // Public transparency report (no private donor info)
    @GetMapping("/report")
    public Map<String, Object> report() {
        List<Donation> success = donationRepository.findByStatus("SUCCESS");
        double total = success.stream().mapToDouble(d -> d.getAmount() == null ? 0 : d.getAmount()).sum();
        java.util.Map<String, Double> byCategory = new java.util.LinkedHashMap<>();
        success.forEach(d -> byCategory.merge(
                d.getCategory() == null ? "General" : d.getCategory(),
                d.getAmount() == null ? 0 : d.getAmount(), Double::sum));
        return Map.of(
                "totalFundsReceived", total,
                "successfulDonations", success.size(),
                "byCategory", byCategory);
    }
}
