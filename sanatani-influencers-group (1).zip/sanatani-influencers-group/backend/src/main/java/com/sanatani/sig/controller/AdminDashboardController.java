package com.sanatani.sig.controller;

import com.sanatani.sig.dto.ApiResponse;
import com.sanatani.sig.model.Certificate;
import com.sanatani.sig.repository.CertificateRepository;
import com.sanatani.sig.service.CertificateService;
import com.sanatani.sig.service.DashboardService;
import com.sanatani.sig.service.SettingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class AdminDashboardController {

    private final DashboardService dashboardService;
    private final SettingService settingService;
    private final CertificateService certificateService;
    private final CertificateRepository certificateRepo;

    public AdminDashboardController(DashboardService dashboardService, SettingService settingService,
                                    CertificateService certificateService, CertificateRepository certificateRepo) {
        this.dashboardService = dashboardService;
        this.settingService = settingService;
        this.certificateService = certificateService;
        this.certificateRepo = certificateRepo;
    }

    @GetMapping("/dashboard/stats")
    public Map<String, Object> stats() { return dashboardService.stats(); }

    @GetMapping("/dashboard/charts")
    public Map<String, Object> charts() { return dashboardService.charts(); }

    // ---------- Settings (CMS) ----------
    @GetMapping("/settings")
    public Map<String, String> settings() { return settingService.all(); }

    @PutMapping("/settings")
    public ResponseEntity<?> updateSettings(@RequestBody Map<String, String> body) {
        settingService.setAll(body);
        return ResponseEntity.ok(ApiResponse.ok("Settings updated", settingService.all()));
    }

    // ---------- Certificates ----------
    @GetMapping("/certificates")
    public List<Certificate> certificates() { return certificateRepo.findAllByOrderByCreatedAtDesc(); }

    @PostMapping("/certificates/generate")
    public Certificate generate(@RequestBody Certificate c) { return certificateService.generate(c); }

    @PostMapping("/certificates/{id}/revoke")
    public Certificate revoke(@PathVariable Long id) {
        Certificate c = certificateRepo.findById(id).orElseThrow();
        c.setStatus("REVOKED");
        return certificateRepo.save(c);
    }
}
