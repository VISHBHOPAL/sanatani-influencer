package com.sanatani.sig.repository;

import com.sanatani.sig.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProjectRepository extends JpaRepository<Project, Long> {
    List<Project> findByTempleSevaTrue();
    List<Project> findByCategory(String category);
    List<Project> findAllByOrderByCreatedAtDesc();
}
