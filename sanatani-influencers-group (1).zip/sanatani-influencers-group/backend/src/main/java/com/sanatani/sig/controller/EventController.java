package com.sanatani.sig.controller;

import com.sanatani.sig.dto.ApiResponse;
import com.sanatani.sig.model.Event;
import com.sanatani.sig.model.EventRegistration;
import com.sanatani.sig.repository.EventRegistrationRepository;
import com.sanatani.sig.repository.EventRepository;
import com.sanatani.sig.service.IdGen;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/events")
public class EventController {

    private final EventRepository eventRepository;
    private final EventRegistrationRepository regRepository;

    public EventController(EventRepository eventRepository, EventRegistrationRepository regRepository) {
        this.eventRepository = eventRepository;
        this.regRepository = regRepository;
    }

    @GetMapping
    public List<Event> all(@RequestParam(required = false) String status) {
        if (status != null) return eventRepository.findByStatus(status.toUpperCase());
        return eventRepository.findAllByOrderByCreatedAtDesc();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> one(@PathVariable Long id) {
        return eventRepository.findById(id)
                .<ResponseEntity<?>>map(e -> {
                    long regs = regRepository.countByEventId(id);
                    return ResponseEntity.ok(Map.of("event", e, "registrations", regs));
                })
                .orElse(ResponseEntity.status(404).body(ApiResponse.error("Event not found")));
    }

    @PostMapping("/{id}/register")
    public ResponseEntity<?> register(@PathVariable Long id, @RequestBody EventRegistration reg) {
        Event e = eventRepository.findById(id).orElse(null);
        if (e == null) return ResponseEntity.status(404).body(ApiResponse.error("Event not found"));
        if (!Boolean.TRUE.equals(reg.getAgreedTerms())) {
            return ResponseEntity.badRequest().body(ApiResponse.error("You must agree to the terms and conditions."));
        }
        if (e.getMaxParticipants() != null && regRepository.countByEventId(id) >= e.getMaxParticipants()) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Registrations are full for this event."));
        }
        reg.setId(null);
        reg.setEventId(id);
        reg.setRegistrationId(IdGen.seq("EVT", regRepository.count() + 1));
        EventRegistration saved = regRepository.save(reg);
        return ResponseEntity.ok(ApiResponse.ok("Registered successfully",
                Map.of("registrationId", saved.getRegistrationId())));
    }
}
