package com.sanatani.sig.controller;

import com.sanatani.sig.dto.ApiResponse;
import com.sanatani.sig.model.*;
import com.sanatani.sig.repository.*;
import com.sanatani.sig.service.MemberService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class AdminManagementController {

    private final MemberRepository memberRepo;
    private final MemberService memberService;
    private final VolunteerRepository volunteerRepo;
    private final EventRegistrationRepository eventRegRepo;
    private final DonationRepository donationRepo;
    private final ContactMessageRepository contactRepo;
    private final NotificationRepository notificationRepo;
    private final AuditLogRepository auditRepo;

    public AdminManagementController(MemberRepository memberRepo, MemberService memberService,
                                     VolunteerRepository volunteerRepo, EventRegistrationRepository eventRegRepo,
                                     DonationRepository donationRepo, ContactMessageRepository contactRepo,
                                     NotificationRepository notificationRepo, AuditLogRepository auditRepo) {
        this.memberRepo = memberRepo;
        this.memberService = memberService;
        this.volunteerRepo = volunteerRepo;
        this.eventRegRepo = eventRegRepo;
        this.donationRepo = donationRepo;
        this.contactRepo = contactRepo;
        this.notificationRepo = notificationRepo;
        this.auditRepo = auditRepo;
    }

    // ---------- Members ----------
    @GetMapping("/members")
    public List<Member> members(@RequestParam(required = false) String status,
                                @RequestParam(required = false) String city) {
        List<Member> list = (status != null) ? memberRepo.findByStatus(status.toUpperCase()) : memberRepo.findAll();
        if (city != null && !city.isBlank()) {
            list = list.stream().filter(m -> city.equalsIgnoreCase(m.getCity())).toList();
        }
        return list;
    }

    @GetMapping("/members/pending")
    public List<Member> pending() { return memberRepo.findByStatus("PENDING"); }

    @PostMapping("/members/{id}/approve")
    public Member approve(@PathVariable Long id) { return memberService.approve(id); }

    @PostMapping("/members/{id}/reject")
    public Member reject(@PathVariable Long id, @RequestBody(required = false) Map<String, String> body) {
        return memberService.reject(id, body == null ? null : body.get("note"));
    }

    @PostMapping("/members/{id}/suspend")
    public Member suspend(@PathVariable Long id) { return memberService.suspend(id); }

    @PutMapping("/members/{id}")
    public Member editMember(@PathVariable Long id, @RequestBody Member m) { m.setId(id); return memberRepo.save(m); }

    @DeleteMapping("/members/{id}")
    public ResponseEntity<?> deleteMember(@PathVariable Long id) { memberRepo.deleteById(id); return ResponseEntity.ok(ApiResponse.ok("Deleted")); }

    @GetMapping(value = "/members/export", produces = "text/csv")
    public ResponseEntity<byte[]> exportCsv() {
        StringBuilder sb = new StringBuilder("MemberID,Name,Email,Mobile,City,State,Category,Status,Joined\n");
        for (Member m : memberRepo.findAll()) {
            sb.append(csv(m.getMemberId())).append(',')
              .append(csv(m.getFullName())).append(',')
              .append(csv(m.getEmail())).append(',')
              .append(csv(m.getMobile())).append(',')
              .append(csv(m.getCity())).append(',')
              .append(csv(m.getState())).append(',')
              .append(csv(m.getCreatorCategory())).append(',')
              .append(csv(m.getStatus())).append(',')
              .append(csv(m.getJoinedDate())).append('\n');
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("text/csv"));
        headers.setContentDispositionFormData("attachment", "members.csv");
        return new ResponseEntity<>(sb.toString().getBytes(), headers, org.springframework.http.HttpStatus.OK);
    }

    private String csv(String v) { return v == null ? "" : "\"" + v.replace("\"", "\"\"") + "\""; }

    // ---------- Volunteers ----------
    @GetMapping("/volunteers")
    public List<Volunteer> volunteers() { return volunteerRepo.findAll(); }
    @PostMapping("/volunteers/{id}/approve")
    public Volunteer approveVolunteer(@PathVariable Long id) {
        Volunteer v = volunteerRepo.findById(id).orElseThrow();
        v.setStatus("APPROVED"); return volunteerRepo.save(v);
    }
    @PostMapping("/volunteers/{id}/reject")
    public Volunteer rejectVolunteer(@PathVariable Long id) {
        Volunteer v = volunteerRepo.findById(id).orElseThrow();
        v.setStatus("REJECTED"); return volunteerRepo.save(v);
    }

    // ---------- Event registrations ----------
    @GetMapping("/event-registrations")
    public List<EventRegistration> eventRegs(@RequestParam(required = false) Long eventId) {
        return eventId != null ? eventRegRepo.findByEventId(eventId) : eventRegRepo.findAll();
    }

    // ---------- Donations ----------
    @GetMapping("/donations")
    public List<Donation> donations() { return donationRepo.findAllByOrderByCreatedAtDesc(); }

    // ---------- Contact messages ----------
    @GetMapping("/messages")
    public List<ContactMessage> messages() { return contactRepo.findAllByOrderByCreatedAtDesc(); }
    @PostMapping("/messages/{id}/read")
    public ContactMessage markRead(@PathVariable Long id) {
        ContactMessage m = contactRepo.findById(id).orElseThrow();
        m.setReadFlag(true); return contactRepo.save(m);
    }

    // ---------- Notifications ----------
    @GetMapping("/notifications")
    public List<Notification> notifications() { return notificationRepo.findAllByOrderByCreatedAtDesc(); }
    @PostMapping("/notifications")
    public Notification broadcast(@RequestBody Notification n) { n.setId(null); return notificationRepo.save(n); }

    // ---------- Audit log ----------
    @GetMapping("/audit")
    public List<AuditLog> audit() { return auditRepo.findTop100ByOrderByTimestampDesc(); }
}
