package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.Instant;

@Data
@Entity
@Table(name = "certificates", indexes = {
        @Index(name = "idx_cert_number", columnList = "certificateNumber", unique = true)
})
public class Certificate {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String certificateNumber; // SIG-CERT-2026-0001
    private String recipient;
    private String type; // Volunteer, Event Participation, Seva...
    private String eventProject;
    private String issueDate;
    private String issuedBy;
    private String designation; // signatory
    private String status = "VALID"; // VALID, REVOKED

    private Instant createdAt = Instant.now();
}
