package com.sanatani.sig.controller;

import com.sanatani.sig.dto.*;
import com.sanatani.sig.model.User;
import com.sanatani.sig.repository.UserRepository;
import com.sanatani.sig.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final UserRepository userRepository;

    public AuthController(AuthService authService, UserRepository userRepository) {
        this.authService = authService;
        this.userRepository = userRepository;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req) {
        return ResponseEntity.ok(authService.register(req));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        return ResponseEntity.ok(authService.login(req));
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgot(@RequestBody Map<String, String> body) {
        String token = authService.forgotPassword(body.getOrDefault("email", ""));
        // In production the token is emailed. Returned here only when mail is not configured.
        return ResponseEntity.ok(ApiResponse.ok("If the email exists, reset instructions were sent.",
                Map.of("resetToken", token == null ? "" : token)));
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> reset(@RequestBody PasswordRequest req) {
        authService.resetPassword(req);
        return ResponseEntity.ok(ApiResponse.ok("Password reset successful"));
    }

    @GetMapping("/me")
    public ResponseEntity<?> me(Authentication auth) {
        if (auth == null) return ResponseEntity.status(401).body(ApiResponse.error("Unauthorized"));
        User u = userRepository.findByEmail(auth.getName()).orElseThrow();
        return ResponseEntity.ok(Map.of(
                "id", u.getId(), "name", u.getName(), "email", u.getEmail(),
                "role", u.getRole().name(), "memberId", u.getMemberId() == null ? "" : u.getMemberId()));
    }
}
