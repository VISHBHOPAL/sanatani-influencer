package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.Instant;

@Data
@Entity
@Table(name = "members", indexes = {
        @Index(name = "idx_member_status", columnList = "status"),
        @Index(name = "idx_member_city", columnList = "city"),
        @Index(name = "idx_member_memberId", columnList = "memberId", unique = true)
})
public class Member {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String memberId; // generated on approval: SIG-2026-0001

    private String fullName;
    private String email;
    private String mobile;
    private String whatsapp;
    private String dob;
    private String gender;
    private String city;
    private String state;

    private String instagram;
    private String instagramUrl;
    private Integer instagramFollowers;
    private String youtube;
    private Integer youtubeSubscribers;
    private String facebook;

    private String creatorCategory;
    private String contentCategory;
    private String languages;
    private String profession;

    @Column(columnDefinition = "TEXT")
    private String skills;
    @Column(columnDefinition = "TEXT")
    private String whyJoin;
    @Column(columnDefinition = "TEXT")
    private String howContribute;
    @Column(columnDefinition = "TEXT")
    private String prevExperience;

    private Boolean interestedVolunteering = false;
    private Boolean interestedEvents = false;
    private Boolean interestedTempleSeva = false;

    private String profilePhoto;
    // private, never exposed on public endpoints
    private String idProof;

    @Column(columnDefinition = "TEXT")
    private String bio;
    @Column(columnDefinition = "TEXT")
    private String achievements;

    private String status = "PENDING"; // PENDING, APPROVED, REJECTED, SUSPENDED
    @Column(columnDefinition = "TEXT")
    private String reviewNote;

    private Boolean publicProfile = true;
    private Boolean consent = false;

    private String joinedDate;
    private Instant createdAt = Instant.now();
}
