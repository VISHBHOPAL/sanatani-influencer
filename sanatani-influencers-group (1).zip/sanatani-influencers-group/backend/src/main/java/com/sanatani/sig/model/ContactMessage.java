package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.Instant;

@Data
@Entity
@Table(name = "contact_messages")
public class ContactMessage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String mobile;
    private String email;
    private String subject;
    @Column(columnDefinition = "TEXT")
    private String message;

    private Boolean readFlag = false;
    private Instant createdAt = Instant.now();
}
