package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "achievements")
public class Achievement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    @Column(columnDefinition = "TEXT")
    private String description;
    private String date;
    private String category; // Award, Recognition, Milestone...
    private String image;
    private Integer orderIndex = 0;
    private Boolean published = true;
}
