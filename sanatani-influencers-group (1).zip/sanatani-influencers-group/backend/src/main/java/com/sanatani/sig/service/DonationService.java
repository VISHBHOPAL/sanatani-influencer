package com.sanatani.sig.service;

import com.sanatani.sig.model.Donation;
import com.sanatani.sig.repository.DonationRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@Service
public class DonationService {

    private final DonationRepository donationRepository;
    private final AuditService auditService;

    @Value("${razorpay.key.id}")
    private String razorpayKeyId;
    @Value("${razorpay.key.secret}")
    private String razorpayKeySecret;

    public DonationService(DonationRepository donationRepository, AuditService auditService) {
        this.donationRepository = donationRepository;
        this.auditService = auditService;
    }

    public boolean paymentConfigured() {
        return razorpayKeyId != null && !razorpayKeyId.isBlank()
                && razorpayKeySecret != null && !razorpayKeySecret.isBlank();
    }

    public Map<String, Object> create(Donation donation) {
        donation.setId(null);
        donation.setStatus("PENDING");
        long count = donationRepository.count() + 1;
        donation.setDonationId(IdGen.seq("DON", count));
        Donation saved = donationRepository.save(donation);

        Map<String, Object> res = new HashMap<>();
        res.put("donation", saved);
        res.put("paymentConfigured", paymentConfigured());
        if (paymentConfigured()) {
            // NOTE: For a real order call Razorpay Orders API here with saved amount.
            // We expose keyId so the frontend Razorpay checkout can open.
            res.put("razorpayKeyId", razorpayKeyId);
            res.put("amount", (int) (donation.getAmount() * 100)); // paise
            res.put("currency", "INR");
        } else {
            res.put("message", "Payment gateway not configured. Add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET to enable live payments.");
        }
        return res;
    }

    // Verify Razorpay signature: HMAC_SHA256(order_id + "|" + payment_id, secret) == signature
    public Donation verify(String donationId, String orderId, String paymentId, String signature) {
        Donation d = donationRepository.findByDonationId(donationId)
                .orElseThrow(() -> new IllegalArgumentException("Donation not found"));
        if (!paymentConfigured()) {
            throw new IllegalStateException("Payment gateway not configured. Cannot verify payment.");
        }
        String expected = hmacSha256(orderId + "|" + paymentId, razorpayKeySecret);
        if (!expected.equals(signature)) {
            d.setStatus("FAILED");
            donationRepository.save(d);
            throw new IllegalArgumentException("Payment signature verification failed");
        }
        d.setStatus("SUCCESS");
        d.setOrderId(orderId);
        d.setPaymentReference(paymentId);
        donationRepository.save(d);
        auditService.log("DONATION_VERIFIED", "Donation " + donationId + " paid");
        return d;
    }

    private String hmacSha256(String data, String secret) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] hash = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException("HMAC error", e);
        }
    }
}
