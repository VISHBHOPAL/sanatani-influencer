package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.Instant;

@Data
@Entity
@Table(name = "volunteers")
public class Volunteer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String mobile;
    private String email;
    private String city;
    private Integer age;

    @Column(columnDefinition = "TEXT")
    private String skills;
    private String availability;
    private String interestedActivities;
    @Column(columnDefinition = "TEXT")
    private String prevExperience;

    private String category; // Temple Seva, Event Management, Photography...
    private String status = "PENDING"; // PENDING, APPROVED, REJECTED

    private Instant createdAt = Instant.now();
}
