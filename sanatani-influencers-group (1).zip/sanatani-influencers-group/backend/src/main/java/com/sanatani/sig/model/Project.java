package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.Instant;

@Data
@Entity
@Table(name = "projects")
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String location;
    private String date;

    @Column(columnDefinition = "TEXT")
    private String description;

    private String category; // Temple Seva, Cleanliness Drive, Cultural Event...

    @Column(columnDefinition = "TEXT")
    private String photos; // comma separated urls
    @Column(columnDefinition = "TEXT")
    private String videos;

    private Integer volunteersCount = 0;
    private String status = "ONGOING"; // ONGOING, COMPLETED, PLANNED
    @Column(columnDefinition = "TEXT")
    private String impact;

    private String beforeImage;
    private String afterImage;

    private Boolean templeSeva = false;

    private Instant createdAt = Instant.now();
}
