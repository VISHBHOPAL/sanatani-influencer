package com.sanatani.sig.model;

public enum Role {
    SUPER_ADMIN,
    ADMIN,
    MEMBER,
    VOLUNTEER,
    EVENT_MANAGER,
    CONTENT_MANAGER
}
