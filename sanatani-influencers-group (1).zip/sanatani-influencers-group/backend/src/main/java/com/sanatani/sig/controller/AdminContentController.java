package com.sanatani.sig.controller;

import com.sanatani.sig.dto.ApiResponse;
import com.sanatani.sig.model.*;
import com.sanatani.sig.repository.*;
import com.sanatani.sig.service.AuditService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminContentController {

    private final EventRepository eventRepo;
    private final ProjectRepository projectRepo;
    private final LeadershipRepository leadershipRepo;
    private final NewsRepository newsRepo;
    private final GalleryRepository galleryRepo;
    private final AchievementRepository achievementRepo;
    private final PartnerRepository partnerRepo;
    private final AuditService audit;

    public AdminContentController(EventRepository eventRepo, ProjectRepository projectRepo,
                                  LeadershipRepository leadershipRepo, NewsRepository newsRepo,
                                  GalleryRepository galleryRepo, AchievementRepository achievementRepo,
                                  PartnerRepository partnerRepo, AuditService audit) {
        this.eventRepo = eventRepo;
        this.projectRepo = projectRepo;
        this.leadershipRepo = leadershipRepo;
        this.newsRepo = newsRepo;
        this.galleryRepo = galleryRepo;
        this.achievementRepo = achievementRepo;
        this.partnerRepo = partnerRepo;
        this.audit = audit;
    }

    // ---------- Events ----------
    @PostMapping("/events")
    public Event createEvent(@RequestBody Event e) { e.setId(null); audit.log("EVENT_CREATE", e.getName()); return eventRepo.save(e); }
    @PutMapping("/events/{id}")
    public Event updateEvent(@PathVariable Long id, @RequestBody Event e) { e.setId(id); audit.log("EVENT_UPDATE", "id=" + id); return eventRepo.save(e); }
    @DeleteMapping("/events/{id}")
    public ResponseEntity<?> deleteEvent(@PathVariable Long id) { eventRepo.deleteById(id); audit.log("EVENT_DELETE", "id=" + id); return ResponseEntity.ok(ApiResponse.ok("Deleted")); }

    // ---------- Projects ----------
    @GetMapping("/projects")
    public List<Project> projects() { return projectRepo.findAllByOrderByCreatedAtDesc(); }
    @PostMapping("/projects")
    public Project createProject(@RequestBody Project p) { p.setId(null); audit.log("PROJECT_CREATE", p.getName()); return projectRepo.save(p); }
    @PutMapping("/projects/{id}")
    public Project updateProject(@PathVariable Long id, @RequestBody Project p) { p.setId(id); return projectRepo.save(p); }
    @DeleteMapping("/projects/{id}")
    public ResponseEntity<?> deleteProject(@PathVariable Long id) { projectRepo.deleteById(id); audit.log("PROJECT_DELETE", "id=" + id); return ResponseEntity.ok(ApiResponse.ok("Deleted")); }

    // ---------- Leadership ----------
    @PostMapping("/leadership")
    public Leadership createLeader(@RequestBody Leadership l) { l.setId(null); return leadershipRepo.save(l); }
    @PutMapping("/leadership/{id}")
    public Leadership updateLeader(@PathVariable Long id, @RequestBody Leadership l) { l.setId(id); return leadershipRepo.save(l); }
    @DeleteMapping("/leadership/{id}")
    public ResponseEntity<?> deleteLeader(@PathVariable Long id) { leadershipRepo.deleteById(id); return ResponseEntity.ok(ApiResponse.ok("Deleted")); }

    // ---------- News ----------
    @GetMapping("/news")
    public List<News> news() { return newsRepo.findAllByOrderByCreatedAtDesc(); }
    @PostMapping("/news")
    public News createNews(@RequestBody News n) { n.setId(null); if (n.getSlug() == null || n.getSlug().isBlank()) n.setSlug(slugify(n.getTitle())); audit.log("NEWS_CREATE", n.getTitle()); return newsRepo.save(n); }
    @PutMapping("/news/{id}")
    public News updateNews(@PathVariable Long id, @RequestBody News n) { n.setId(id); if (n.getSlug() == null || n.getSlug().isBlank()) n.setSlug(slugify(n.getTitle())); return newsRepo.save(n); }
    @DeleteMapping("/news/{id}")
    public ResponseEntity<?> deleteNews(@PathVariable Long id) { newsRepo.deleteById(id); return ResponseEntity.ok(ApiResponse.ok("Deleted")); }

    // ---------- Gallery ----------
    @PostMapping("/gallery")
    public GalleryItem createGallery(@RequestBody GalleryItem g) { g.setId(null); return galleryRepo.save(g); }
    @PutMapping("/gallery/{id}")
    public GalleryItem updateGallery(@PathVariable Long id, @RequestBody GalleryItem g) { g.setId(id); return galleryRepo.save(g); }
    @DeleteMapping("/gallery/{id}")
    public ResponseEntity<?> deleteGallery(@PathVariable Long id) { galleryRepo.deleteById(id); return ResponseEntity.ok(ApiResponse.ok("Deleted")); }

    // ---------- Achievements ----------
    @GetMapping("/achievements")
    public List<Achievement> achievements() { return achievementRepo.findAllByOrderByOrderIndexAsc(); }
    @PostMapping("/achievements")
    public Achievement createAchievement(@RequestBody Achievement a) { a.setId(null); return achievementRepo.save(a); }
    @PutMapping("/achievements/{id}")
    public Achievement updateAchievement(@PathVariable Long id, @RequestBody Achievement a) { a.setId(id); return achievementRepo.save(a); }
    @DeleteMapping("/achievements/{id}")
    public ResponseEntity<?> deleteAchievement(@PathVariable Long id) { achievementRepo.deleteById(id); return ResponseEntity.ok(ApiResponse.ok("Deleted")); }

    // ---------- Partners ----------
    @PostMapping("/partners")
    public Partner createPartner(@RequestBody Partner p) { p.setId(null); return partnerRepo.save(p); }
    @PutMapping("/partners/{id}")
    public Partner updatePartner(@PathVariable Long id, @RequestBody Partner p) { p.setId(id); return partnerRepo.save(p); }
    @DeleteMapping("/partners/{id}")
    public ResponseEntity<?> deletePartner(@PathVariable Long id) { partnerRepo.deleteById(id); return ResponseEntity.ok(ApiResponse.ok("Deleted")); }

    private String slugify(String s) {
        if (s == null) return "article-" + System.currentTimeMillis();
        return s.toLowerCase().replaceAll("[^a-z0-9]+", "-").replaceAll("(^-|-$)", "") + "-" + System.currentTimeMillis() % 10000;
    }
}
