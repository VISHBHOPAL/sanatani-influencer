package com.sanatani.sig.controller;

import com.sanatani.sig.model.GalleryItem;
import com.sanatani.sig.repository.GalleryRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/gallery")
public class GalleryController {

    private final GalleryRepository repo;

    public GalleryController(GalleryRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<GalleryItem> all(@RequestParam(required = false) String category) {
        if (category != null) return repo.findByCategory(category);
        return repo.findAllByOrderByCreatedAtDesc();
    }
}
