package com.sanatani.sig.repository;

import com.sanatani.sig.model.Volunteer;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface VolunteerRepository extends JpaRepository<Volunteer, Long> {
    List<Volunteer> findByStatus(String status);
    long countByStatus(String status);
}
