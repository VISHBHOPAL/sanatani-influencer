package com.sanatani.sig.repository;

import com.sanatani.sig.model.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface MemberRepository extends JpaRepository<Member, Long> {
    Optional<Member> findByMemberId(String memberId);
    Optional<Member> findByEmail(String email);
    List<Member> findByStatus(String status);
    List<Member> findByStatusAndPublicProfileTrue(String status);
    long countByStatus(String status);
}
