package com.sanatani.sig.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sanatani.sig.model.Setting;
import com.sanatani.sig.repository.SettingRepository;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class SettingService {

    private final SettingRepository repo;
    private final ObjectMapper mapper = new ObjectMapper();

    // keys that must never be exposed on the public endpoint
    private static final java.util.Set<String> PRIVATE_KEYS = java.util.Set.of(
            "razorpayKeySecret", "smtpPassword", "mailApiKey");

    public SettingService(SettingRepository repo) {
        this.repo = repo;
    }

    public Map<String, String> all() {
        Map<String, String> map = new LinkedHashMap<>();
        repo.findAll().forEach(s -> map.put(s.getKey(), s.getValue()));
        return map;
    }

    public Map<String, String> publicSettings() {
        Map<String, String> map = all();
        PRIVATE_KEYS.forEach(map::remove);
        return map;
    }

    public String get(String key, String def) {
        return repo.findById(key).map(Setting::getValue).orElse(def);
    }

    public void set(String key, String value) {
        repo.save(new Setting(key, value));
    }

    public void setAll(Map<String, String> values) {
        values.forEach(this::set);
    }
}
