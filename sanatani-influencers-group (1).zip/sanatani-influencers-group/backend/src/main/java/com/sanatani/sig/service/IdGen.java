package com.sanatani.sig.service;

import java.time.Year;

public final class IdGen {
    private IdGen() {}
    public static String seq(String prefix, long count) {
        return prefix + "-" + Year.now().getValue() + "-" + String.format("%04d", count);
    }
}
