package com.sanatani.sig.repository;

import com.sanatani.sig.model.Achievement;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AchievementRepository extends JpaRepository<Achievement, Long> {
    List<Achievement> findByPublishedTrueOrderByOrderIndexAsc();
    List<Achievement> findAllByOrderByOrderIndexAsc();
}
