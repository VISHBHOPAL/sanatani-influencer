package com.sanatani.sig.controller;

import com.sanatani.sig.service.SettingService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/settings")
public class SettingController {

    private final SettingService settingService;

    public SettingController(SettingService settingService) {
        this.settingService = settingService;
    }

    @GetMapping("/public")
    public Map<String, String> publicSettings() {
        return settingService.publicSettings();
    }
}
