package com.sanatani.sig.repository;

import com.sanatani.sig.model.GalleryItem;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface GalleryRepository extends JpaRepository<GalleryItem, Long> {
    List<GalleryItem> findByCategory(String category);
    List<GalleryItem> findAllByOrderByCreatedAtDesc();
}
