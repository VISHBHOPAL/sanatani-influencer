package com.sanatani.sig.repository;

import com.sanatani.sig.model.Setting;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SettingRepository extends JpaRepository<Setting, String> {
}
