package com.sanatani.sig.controller;

import com.sanatani.sig.dto.ApiResponse;
import com.sanatani.sig.model.Member;
import com.sanatani.sig.repository.MemberRepository;
import com.sanatani.sig.service.MemberService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class MemberController {

    private final MemberService memberService;
    private final MemberRepository memberRepository;

    public MemberController(MemberService memberService, MemberRepository memberRepository) {
        this.memberService = memberService;
        this.memberRepository = memberRepository;
    }

    // Public: apply for membership
    @PostMapping("/members/apply")
    public ResponseEntity<?> apply(@RequestBody Member member) {
        if (!Boolean.TRUE.equals(member.getConsent())) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Consent is required to submit the application."));
        }
        Member saved = memberService.apply(member);
        return ResponseEntity.ok(ApiResponse.ok("Application submitted. Status: PENDING. You will be notified after review.",
                Map.of("id", saved.getId(), "status", saved.getStatus())));
    }

    // Public: creator directory (approved + public only, private fields stripped)
    @GetMapping("/members/public")
    public List<Member> publicDirectory() {
        return memberService.publicDirectory();
    }

    // Public: single public profile
    @GetMapping("/members/public/{id}")
    public ResponseEntity<?> publicProfile(@PathVariable Long id) {
        Member m = memberRepository.findById(id).orElse(null);
        if (m == null || !"APPROVED".equals(m.getStatus()) || !Boolean.TRUE.equals(m.getPublicProfile())) {
            return ResponseEntity.status(404).body(ApiResponse.error("Profile not found or not public"));
        }
        return ResponseEntity.ok(memberService.sanitizePublic(m));
    }

    // Authenticated member: own full profile
    @GetMapping("/members/{id}")
    public ResponseEntity<?> getMember(@PathVariable Long id) {
        return memberRepository.findById(id)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElse(ResponseEntity.status(404).body(ApiResponse.error("Member not found")));
    }

    // Authenticated member: edit permitted fields only
    @PutMapping("/members/{id}")
    public ResponseEntity<?> updateMember(@PathVariable Long id, @RequestBody Member update) {
        Member m = memberRepository.findById(id).orElse(null);
        if (m == null) return ResponseEntity.status(404).body(ApiResponse.error("Member not found"));
        // Only member-editable fields (admin-controlled: status, memberId, joinedDate not editable here)
        if (update.getBio() != null) m.setBio(update.getBio());
        if (update.getSkills() != null) m.setSkills(update.getSkills());
        if (update.getProfilePhoto() != null) m.setProfilePhoto(update.getProfilePhoto());
        if (update.getInstagram() != null) m.setInstagram(update.getInstagram());
        if (update.getInstagramUrl() != null) m.setInstagramUrl(update.getInstagramUrl());
        if (update.getYoutube() != null) m.setYoutube(update.getYoutube());
        if (update.getFacebook() != null) m.setFacebook(update.getFacebook());
        if (update.getContentCategory() != null) m.setContentCategory(update.getContentCategory());
        if (update.getLanguages() != null) m.setLanguages(update.getLanguages());
        if (update.getPublicProfile() != null) m.setPublicProfile(update.getPublicProfile());
        memberRepository.save(m);
        return ResponseEntity.ok(ApiResponse.ok("Profile updated", m));
    }
}
