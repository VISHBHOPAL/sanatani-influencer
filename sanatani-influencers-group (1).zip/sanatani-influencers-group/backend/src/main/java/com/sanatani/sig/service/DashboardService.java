package com.sanatani.sig.service;

import com.sanatani.sig.model.Donation;
import com.sanatani.sig.repository.*;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class DashboardService {

    private final MemberRepository memberRepo;
    private final VolunteerRepository volunteerRepo;
    private final EventRepository eventRepo;
    private final EventRegistrationRepository eventRegRepo;
    private final DonationRepository donationRepo;
    private final ProjectRepository projectRepo;
    private final NewsRepository newsRepo;
    private final CertificateRepository certRepo;
    private final ContactMessageRepository contactRepo;

    public DashboardService(MemberRepository memberRepo, VolunteerRepository volunteerRepo,
                            EventRepository eventRepo, EventRegistrationRepository eventRegRepo,
                            DonationRepository donationRepo, ProjectRepository projectRepo,
                            NewsRepository newsRepo, CertificateRepository certRepo,
                            ContactMessageRepository contactRepo) {
        this.memberRepo = memberRepo;
        this.volunteerRepo = volunteerRepo;
        this.eventRepo = eventRepo;
        this.eventRegRepo = eventRegRepo;
        this.donationRepo = donationRepo;
        this.projectRepo = projectRepo;
        this.newsRepo = newsRepo;
        this.certRepo = certRepo;
        this.contactRepo = contactRepo;
    }

    public Map<String, Object> stats() {
        Map<String, Object> s = new LinkedHashMap<>();
        s.put("totalMembers", memberRepo.countByStatus("APPROVED"));
        s.put("pendingApplications", memberRepo.countByStatus("PENDING"));
        s.put("totalVolunteers", volunteerRepo.count());
        s.put("upcomingEvents", eventRepo.findByStatus("UPCOMING").size());
        s.put("eventRegistrations", eventRegRepo.count());
        s.put("activeProjects", projectRepo.count());
        s.put("publishedArticles", newsRepo.countByPublishedTrue());
        s.put("certificatesIssued", certRepo.count());
        s.put("unreadMessages", contactRepo.countByReadFlagFalse());

        List<Donation> success = donationRepo.findByStatus("SUCCESS");
        double total = success.stream().mapToDouble(d -> d.getAmount() == null ? 0 : d.getAmount()).sum();
        s.put("totalDonations", total);

        LocalDate now = LocalDate.now();
        double monthly = success.stream()
                .filter(d -> {
                    LocalDate dt = LocalDate.ofInstant(d.getCreatedAt(), ZoneId.systemDefault());
                    return dt.getMonthValue() == now.getMonthValue() && dt.getYear() == now.getYear();
                })
                .mapToDouble(d -> d.getAmount() == null ? 0 : d.getAmount()).sum();
        s.put("monthlyDonations", monthly);
        return s;
    }

    public Map<String, Object> charts() {
        Map<String, Object> c = new HashMap<>();

        // city-wise members
        Map<String, Long> byCity = new LinkedHashMap<>();
        Map<String, Long> byCategory = new LinkedHashMap<>();
        memberRepo.findByStatus("APPROVED").forEach(m -> {
            if (m.getCity() != null) byCity.merge(m.getCity(), 1L, Long::sum);
            if (m.getCreatorCategory() != null) byCategory.merge(m.getCreatorCategory(), 1L, Long::sum);
        });
        c.put("membersByCity", byCity);
        c.put("membersByCategory", byCategory);

        // donation by category
        Map<String, Double> donByCat = new LinkedHashMap<>();
        donationRepo.findByStatus("SUCCESS").forEach(d -> {
            String cat = d.getCategory() == null ? "General" : d.getCategory();
            donByCat.merge(cat, d.getAmount() == null ? 0 : d.getAmount(), Double::sum);
        });
        c.put("donationsByCategory", donByCat);
        return c;
    }
}
