package com.sanatani.sig.controller;

import com.sanatani.sig.dto.ApiResponse;
import com.sanatani.sig.model.ContactMessage;
import com.sanatani.sig.model.Volunteer;
import com.sanatani.sig.repository.ContactMessageRepository;
import com.sanatani.sig.repository.VolunteerRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class PublicFormController {

    private final VolunteerRepository volunteerRepo;
    private final ContactMessageRepository contactRepo;

    public PublicFormController(VolunteerRepository volunteerRepo, ContactMessageRepository contactRepo) {
        this.volunteerRepo = volunteerRepo;
        this.contactRepo = contactRepo;
    }

    @PostMapping("/volunteers/apply")
    public ResponseEntity<?> applyVolunteer(@RequestBody Volunteer v) {
        v.setId(null);
        v.setStatus("PENDING");
        volunteerRepo.save(v);
        return ResponseEntity.ok(ApiResponse.ok("Volunteer application submitted. Admin approval required."));
    }

    @PostMapping("/contact")
    public ResponseEntity<?> contact(@RequestBody ContactMessage msg) {
        msg.setId(null);
        msg.setReadFlag(false);
        contactRepo.save(msg);
        return ResponseEntity.ok(ApiResponse.ok("Message sent. We will get back to you soon."));
    }
}
