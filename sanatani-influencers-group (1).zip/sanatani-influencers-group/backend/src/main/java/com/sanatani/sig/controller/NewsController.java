package com.sanatani.sig.controller;

import com.sanatani.sig.model.News;
import com.sanatani.sig.repository.NewsRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/news")
public class NewsController {

    private final NewsRepository repo;

    public NewsController(NewsRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<News> all() {
        return repo.findByPublishedTrueOrderByCreatedAtDesc();
    }

    @GetMapping("/{slug}")
    public News bySlug(@PathVariable String slug) {
        return repo.findBySlug(slug).orElse(null);
    }
}
