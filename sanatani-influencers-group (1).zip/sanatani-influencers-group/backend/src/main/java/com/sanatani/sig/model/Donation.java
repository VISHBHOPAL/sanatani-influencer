package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.Instant;

@Data
@Entity
@Table(name = "donations")
public class Donation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String donationId; // DON-2026-0001

    private String name;
    private String mobile;
    private String email;
    private String city;

    private Double amount;
    private String purpose;
    private String category; // Temple Seva, Temple Cleaning, Social Work...
    private Boolean anonymous = false;

    private String status = "PENDING"; // PENDING, SUCCESS, FAILED, REFUNDED
    private String paymentReference; // razorpay_payment_id
    private String orderId;          // razorpay_order_id

    private Instant createdAt = Instant.now();
}
