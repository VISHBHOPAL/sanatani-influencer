package com.sanatani.sig.config;

import com.sanatani.sig.model.*;
import com.sanatani.sig.repository.*;
import com.sanatani.sig.service.SettingService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Component
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepo;
    private final MemberRepository memberRepo;
    private final EventRepository eventRepo;
    private final ProjectRepository projectRepo;
    private final LeadershipRepository leadershipRepo;
    private final NewsRepository newsRepo;
    private final GalleryRepository galleryRepo;
    private final AchievementRepository achievementRepo;
    private final PartnerRepository partnerRepo;
    private final PasswordEncoder encoder;
    private final SettingService settingService;

    @Value("${app.seed.enabled:true}")
    private boolean seedEnabled;
    @Value("${app.seed.superadmin.email}")
    private String adminEmail;
    @Value("${app.seed.superadmin.password}")
    private String adminPassword;

    public DataSeeder(UserRepository userRepo, MemberRepository memberRepo, EventRepository eventRepo,
                      ProjectRepository projectRepo, LeadershipRepository leadershipRepo, NewsRepository newsRepo,
                      GalleryRepository galleryRepo, AchievementRepository achievementRepo,
                      PartnerRepository partnerRepo, PasswordEncoder encoder, SettingService settingService) {
        this.userRepo = userRepo;
        this.memberRepo = memberRepo;
        this.eventRepo = eventRepo;
        this.projectRepo = projectRepo;
        this.leadershipRepo = leadershipRepo;
        this.newsRepo = newsRepo;
        this.galleryRepo = galleryRepo;
        this.achievementRepo = achievementRepo;
        this.partnerRepo = partnerRepo;
        this.encoder = encoder;
        this.settingService = settingService;
    }

    @Override
    public void run(String... args) {
        if (!seedEnabled) return;

        // Super admin (idempotent)
        if (!userRepo.existsByEmail(adminEmail.toLowerCase())) {
            User admin = new User();
            admin.setName("Super Admin");
            admin.setEmail(adminEmail.toLowerCase());
            admin.setPassword(encoder.encode(adminPassword));
            admin.setRole(Role.SUPER_ADMIN);
            userRepo.save(admin);
        }

        // Default CMS settings (only if empty)
        if (settingService.all().isEmpty()) {
            settingService.setAll(Map.ofEntries(
                Map.entry("orgName", "Sanatani Influencers Group"),
                Map.entry("tagline", "Digital Creators • Sanatan Culture • Seva • Sanskar"),
                Map.entry("taglineHindi", "जुड़ें संस्कृति से, जुड़ें सेवा से, जुड़ें सनातन से"),
                Map.entry("heroSubtitle", "एक ऐसा creator community platform जो digital creators को Sanatan culture, seva, social responsibility और community initiatives से जोड़ता है।"),
                Map.entry("aboutText", "Sanatani Influencers Group is a creator/community initiative connecting digital creators and volunteers for promoting cultural awareness, Sanatan traditions, temple seva, social responsibility and positive community initiatives."),
                Map.entry("visionText", "एक ऐसी युवा और डिजिटल community का निर्माण करना जो अपनी संस्कृति, परंपराओं और सामाजिक जिम्मेदारियों से जुड़ी रहे और technology तथा social media का उपयोग सकारात्मक परिवर्तन के लिए करे।"),
                Map.entry("statMembers", "1000+"),
                Map.entry("statCreators", "100+"),
                Map.entry("statSeva", "25+"),
                Map.entry("statInitiatives", "40+"),
                Map.entry("statEvents", "50+"),
                Map.entry("city", "Bhopal, Madhya Pradesh, India"),
                Map.entry("phone", "Official information will be updated soon."),
                Map.entry("whatsapp", ""),
                Map.entry("email", "Official information will be updated soon."),
                Map.entry("address", "Bhopal, Madhya Pradesh, India"),
                Map.entry("instagram", ""),
                Map.entry("youtube", ""),
                Map.entry("facebook", ""),
                Map.entry("upiId", ""),
                Map.entry("mapsEmbed", "")
            ));
        }

        if (memberRepo.count() == 0) seedDemo();
    }

    private void seedDemo() {
        // 5 demo members (clearly fictional) - APPROVED so directory shows content
        String[][] members = {
            {"Aarav Sharma (Demo)", "Bhopal", "Instagram Creator", "Aarav creates devotional reels.", "45000"},
            {"Diya Verma (Demo)", "Indore", "YouTuber", "Diya vlogs about temple visits.", "120000"},
            {"Kabir Nair (Demo)", "Bhopal", "Photographer", "Kabir captures cultural events.", "8000"},
            {"Ananya Iyer (Demo)", "Ujjain", "Religious Content Creator", "Ananya shares Sanatan knowledge.", "67000"},
            {"Rohan Mehta (Demo)", "Bhopal", "Videographer", "Rohan documents seva drives.", "15000"},
        };
        int i = 1;
        for (String[] d : members) {
            Member m = new Member();
            m.setFullName(d[0]);
            m.setCity(d[1]);
            m.setState("Madhya Pradesh");
            m.setCreatorCategory(d[2]);
            m.setBio(d[3]);
            m.setInstagramFollowers(Integer.parseInt(d[4]));
            m.setInstagram("@demo_creator_" + i);
            m.setStatus("APPROVED");
            m.setPublicProfile(true);
            m.setMemberId(String.format("SIG-%d-%04d", LocalDate.now().getYear(), i));
            m.setJoinedDate(LocalDate.now().minusDays(i * 10L).toString());
            m.setSkills("Content Creation, Editing");
            memberRepo.save(m);
            i++;
        }

        // 3 demo events
        eventRepo.saveAll(List.of(
            demoEvent("Temple Seva Abhiyan - Bhopal", "Creator Meet", "UPCOMING", "2026-07-20", "Bhojeshwar Temple, Bhopal"),
            demoEvent("Sanatani Creators Meetup", "Creator Meet", "UPCOMING", "2026-08-05", "Bhopal Haat, Bhopal"),
            demoEvent("Cultural Program - Janmashtami", "Cultural Program", "PAST", "2025-08-26", "New Market, Bhopal")
        ));

        // 3 demo projects (2 temple seva)
        projectRepo.saveAll(List.of(
            demoProject("Temple Cleanliness Drive", "Temple Seva", true, "COMPLETED", "50 volunteers cleaned the temple premises."),
            demoProject("Riverbank Cleanup", "Cleanliness Drive", false, "ONGOING", "Ongoing cleanliness at Upper Lake."),
            demoProject("Temple Renovation Support", "Temple Seva", true, "ONGOING", "Supporting renovation of a local temple.")
        ));

        // 3 leadership placeholders (do NOT invent real people)
        leadershipRepo.saveAll(List.of(
            demoLeader("Official information will be updated soon.", "Founder", 1, false),
            demoLeader("Official information will be updated soon.", "President / Adhyaksh", 2, true),
            demoLeader("Official information will be updated soon.", "General Secretary", 3, false)
        ));

        // 3 demo articles
        for (int a = 1; a <= 3; a++) {
            News n = new News();
            n.setTitle("Community Update #" + a + " (Demo)");
            n.setSlug("community-update-" + a);
            n.setContent("This is demo content for a news article. Admin can edit or delete this from the dashboard.");
            n.setAuthor("SIG Team");
            n.setCategory("Announcement");
            n.setDate(LocalDate.now().minusDays(a * 5L).toString());
            n.setPublished(true);
            newsRepo.save(n);
        }

        // 5 demo gallery items
        String[] cats = {"Events", "Temple Seva", "Creator Meets", "Cultural Programs", "Social Work"};
        for (int g = 0; g < 5; g++) {
            GalleryItem gi = new GalleryItem();
            gi.setTitle("Demo Photo " + (g + 1));
            gi.setCategory(cats[g]);
            gi.setImageUrl("https://images.unsplash.com/photo-1524069290683-0457abfe42c3?w=800");
            gi.setDate(LocalDate.now().minusDays(g * 3L).toString());
            gi.setLocation("Bhopal");
            galleryRepo.save(gi);
        }

        // achievements
        achievementRepo.saveAll(List.of(
            demoAchievement("Community Milestone (Demo)", "Crossed demo milestone of active members.", 1),
            demoAchievement("Temple Seva Milestone (Demo)", "Completed demo seva projects.", 2)
        ));
    }

    private Event demoEvent(String name, String cat, String status, String date, String venue) {
        Event e = new Event();
        e.setName(name); e.setCategory(cat); e.setStatus(status);
        e.setDate(date); e.setVenue(venue); e.setTime("10:00 AM");
        e.setOrganizer("Sanatani Influencers Group");
        e.setDescription("Demo event. Admin can edit details from the dashboard.");
        e.setRegistrationRequired(true); e.setMaxParticipants(200);
        return e;
    }

    private Project demoProject(String name, String cat, boolean temple, String status, String impact) {
        Project p = new Project();
        p.setName(name); p.setCategory(cat); p.setTempleSeva(temple);
        p.setStatus(status); p.setImpact(impact); p.setLocation("Bhopal");
        p.setDate(LocalDate.now().minusMonths(1).toString());
        p.setVolunteersCount(30);
        p.setDescription("Demo project. Admin can edit or delete from the dashboard.");
        p.setBeforeImage("https://images.unsplash.com/photo-1524069290683-0457abfe42c3?w=600");
        p.setAfterImage("https://images.unsplash.com/photo-1587271636175-90d58cdad458?w=600");
        return p;
    }

    private Leadership demoLeader(String name, String designation, int order, boolean president) {
        Leadership l = new Leadership();
        l.setName(name); l.setDesignation(designation); l.setOrderIndex(order);
        l.setIsPresident(president);
        l.setBio("Official information will be updated soon.");
        if (president) l.setPresidentMessage("अध्यक्ष का संदेश यहाँ जल्द ही अपडेट किया जाएगा।");
        return l;
    }

    private Achievement demoAchievement(String title, String desc, int order) {
        Achievement a = new Achievement();
        a.setTitle(title); a.setDescription(desc); a.setOrderIndex(order);
        a.setDate(LocalDate.now().minusMonths(order).toString());
        a.setCategory("Milestone"); a.setPublished(true);
        return a;
    }
}
