package com.sanatani.sig.repository;

import com.sanatani.sig.model.News;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface NewsRepository extends JpaRepository<News, Long> {
    List<News> findByPublishedTrueOrderByCreatedAtDesc();
    List<News> findAllByOrderByCreatedAtDesc();
    Optional<News> findBySlug(String slug);
    long countByPublishedTrue();
}
