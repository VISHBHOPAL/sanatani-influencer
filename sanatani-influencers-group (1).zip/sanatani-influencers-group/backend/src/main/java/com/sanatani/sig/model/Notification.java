package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.Instant;

@Data
@Entity
@Table(name = "notifications")
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId; // null = broadcast
    private String title;
    @Column(columnDefinition = "TEXT")
    private String message;
    private String type; // event, approval, seva, announcement...
    private Boolean readFlag = false;
    private Instant createdAt = Instant.now();
}
