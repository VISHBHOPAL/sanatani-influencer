package com.sanatani.sig.service;

import com.sanatani.sig.model.AuditLog;
import com.sanatani.sig.repository.AuditLogRepository;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
public class AuditService {

    private final AuditLogRepository repo;

    public AuditService(AuditLogRepository repo) {
        this.repo = repo;
    }

    public void log(String action, String details) {
        AuditLog log = new AuditLog();
        try {
            Object principal = SecurityContextHolder.getContext().getAuthentication().getName();
            log.setAdminEmail(principal.toString());
        } catch (Exception e) {
            log.setAdminEmail("system");
        }
        log.setAction(action);
        log.setDetails(details);
        repo.save(log);
    }
}
