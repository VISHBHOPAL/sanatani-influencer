package com.sanatani.sig.service;

import com.sanatani.sig.model.Certificate;
import com.sanatani.sig.repository.CertificateRepository;
import org.springframework.stereotype.Service;

@Service
public class CertificateService {

    private final CertificateRepository repo;
    private final AuditService auditService;

    public CertificateService(CertificateRepository repo, AuditService auditService) {
        this.repo = repo;
        this.auditService = auditService;
    }

    public Certificate generate(Certificate c) {
        c.setId(null);
        long count = repo.count() + 1;
        c.setCertificateNumber(IdGen.seq("SIG-CERT", count));
        c.setStatus("VALID");
        Certificate saved = repo.save(c);
        auditService.log("CERTIFICATE_GENERATED", "Cert " + saved.getCertificateNumber() + " for " + saved.getRecipient());
        return saved;
    }

    public Certificate verify(String number) {
        return repo.findByCertificateNumber(number).orElse(null);
    }
}
