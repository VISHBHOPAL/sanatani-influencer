package com.sanatani.sig.service;

import com.sanatani.sig.model.Member;
import com.sanatani.sig.model.Notification;
import com.sanatani.sig.model.Role;
import com.sanatani.sig.model.User;
import com.sanatani.sig.repository.MemberRepository;
import com.sanatani.sig.repository.NotificationRepository;
import com.sanatani.sig.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class MemberService {

    private final MemberRepository memberRepository;
    private final UserRepository userRepository;
    private final NotificationRepository notificationRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuditService auditService;

    public MemberService(MemberRepository memberRepository, UserRepository userRepository,
                         NotificationRepository notificationRepository, PasswordEncoder passwordEncoder,
                         AuditService auditService) {
        this.memberRepository = memberRepository;
        this.userRepository = userRepository;
        this.notificationRepository = notificationRepository;
        this.passwordEncoder = passwordEncoder;
        this.auditService = auditService;
    }

    public Member apply(Member member) {
        member.setId(null);
        member.setStatus("PENDING");
        member.setMemberId(null);
        member.setJoinedDate(null);
        return memberRepository.save(member);
    }

    public Member approve(Long id) {
        Member m = memberRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Member not found"));
        if (!"APPROVED".equals(m.getStatus())) {
            long count = memberRepository.countByStatus("APPROVED") + 1;
            m.setMemberId(IdGen.seq("SIG", count));
            m.setStatus("APPROVED");
            m.setJoinedDate(LocalDate.now().toString());
            memberRepository.save(m);
            createMemberUserIfNeeded(m);
            notify(m, "Membership Approved",
                    "Congratulations! Your membership has been approved. Member ID: " + m.getMemberId(), "approval");
            auditService.log("MEMBER_APPROVED", "Member " + m.getId() + " (" + m.getFullName() + ")");
        }
        return m;
    }

    public Member reject(Long id, String note) {
        Member m = memberRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Member not found"));
        m.setStatus("REJECTED");
        m.setReviewNote(note);
        memberRepository.save(m);
        notify(m, "Membership Update", "Your application status: REJECTED. " + (note == null ? "" : note), "approval");
        auditService.log("MEMBER_REJECTED", "Member " + m.getId());
        return m;
    }

    public Member suspend(Long id) {
        Member m = memberRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Member not found"));
        m.setStatus("SUSPENDED");
        memberRepository.save(m);
        auditService.log("MEMBER_SUSPENDED", "Member " + m.getId());
        return m;
    }

    private void createMemberUserIfNeeded(Member m) {
        if (m.getEmail() == null || m.getEmail().isBlank()) return;
        if (userRepository.existsByEmail(m.getEmail().toLowerCase())) {
            userRepository.findByEmail(m.getEmail().toLowerCase()).ifPresent(u -> {
                u.setMemberId(m.getId());
                userRepository.save(u);
            });
            return;
        }
        User u = new User();
        u.setName(m.getFullName());
        u.setEmail(m.getEmail().toLowerCase());
        // temporary password = memberId; member should reset via Forgot Password
        u.setPassword(passwordEncoder.encode(m.getMemberId()));
        u.setPhone(m.getMobile());
        u.setRole(Role.MEMBER);
        u.setMemberId(m.getId());
        userRepository.save(u);
    }

    private void notify(Member m, String title, String message, String type) {
        Notification n = new Notification();
        n.setTitle(title);
        n.setMessage(message);
        n.setType(type);
        userRepository.findByEmail(m.getEmail() == null ? "" : m.getEmail().toLowerCase())
                .ifPresent(u -> n.setUserId(u.getId()));
        notificationRepository.save(n);
    }

    // Strip private fields for public exposure
    public Member sanitizePublic(Member m) {
        m.setIdProof(null);
        m.setMobile(null);
        m.setWhatsapp(null);
        m.setEmail(null);
        m.setDob(null);
        return m;
    }

    public List<Member> publicDirectory() {
        return memberRepository.findByStatusAndPublicProfileTrue("APPROVED")
                .stream().map(this::sanitizePublic).toList();
    }
}
