package com.sanatani.sig.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "partners")
public class Partner {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String logo;
    private String website;
    @Column(columnDefinition = "TEXT")
    private String description;
    private String partnershipType;
}
