package com.sanatani.sig.controller;

import com.sanatani.sig.model.Achievement;
import com.sanatani.sig.model.Partner;
import com.sanatani.sig.repository.AchievementRepository;
import com.sanatani.sig.repository.PartnerRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MiscPublicController {

    private final AchievementRepository achievementRepo;
    private final PartnerRepository partnerRepo;

    public MiscPublicController(AchievementRepository achievementRepo, PartnerRepository partnerRepo) {
        this.achievementRepo = achievementRepo;
        this.partnerRepo = partnerRepo;
    }

    @GetMapping("/api/achievements")
    public List<Achievement> achievements() {
        return achievementRepo.findByPublishedTrueOrderByOrderIndexAsc();
    }

    @GetMapping("/api/partners")
    public List<Partner> partners() {
        return partnerRepo.findAll();
    }

    @GetMapping("/api/health")
    public Object health() {
        return java.util.Map.of("status", "UP", "service", "Sanatani Influencers Group API");
    }
}
