package com.sanatani.sig.dto;

import lombok.Data;

@Data
public class PasswordRequest {
    private String email;
    private String token;
    private String newPassword;
}
