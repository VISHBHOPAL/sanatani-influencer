import { useEffect, useState } from 'react'
import api from '../../lib/api'
import { Spinner, EmptyState } from '../../components/ui'
import { AdminHeader } from './CrudManager'
import { ClipboardList } from 'lucide-react'

export default function Registrations() {
  const [list, setList] = useState(null)
  useEffect(() => { api.get('/admin/event-registrations').then((r) => setList(r.data)).catch(() => setList([])) }, [])
  return (
    <div>
      <AdminHeader title="Event Registrations" />
      {list === null ? <Spinner /> : list.length === 0 ? <EmptyState icon={ClipboardList} title="No registrations yet" /> : (
        <div className="bg-white rounded-2xl shadow-card border border-gold/20 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-cream-muted text-left text-maroon"><tr>
              <th className="px-4 py-3">Reg ID</th><th className="px-4 py-3">Name</th><th className="px-4 py-3">Mobile</th><th className="px-4 py-3">City</th><th className="px-4 py-3">Category</th><th className="px-4 py-3">Event</th>
            </tr></thead>
            <tbody className="divide-y divide-cream-muted">
              {list.map((r) => (
                <tr key={r.id} className="hover:bg-cream/50">
                  <td className="px-4 py-3 text-saffron font-medium">{r.registrationId}</td>
                  <td className="px-4 py-3 text-maroon">{r.fullName}</td>
                  <td className="px-4 py-3 text-ink/70">{r.mobile}</td>
                  <td className="px-4 py-3 text-ink/70">{r.city}</td>
                  <td className="px-4 py-3 text-ink/70">{r.creatorCategory}</td>
                  <td className="px-4 py-3 text-ink/70">#{r.eventId}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
