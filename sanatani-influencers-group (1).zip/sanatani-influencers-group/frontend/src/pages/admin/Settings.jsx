import { useEffect, useState } from 'react'
import api from '../../lib/api'
import { useToast, Spinner } from '../../components/ui'
import { AdminHeader } from './CrudManager'
import { Save, Info } from 'lucide-react'

const groups = [
  { title: 'Organization', fields: [['orgName', 'Organization Name'], ['tagline', 'Tagline (English)'], ['taglineHindi', 'Tagline (Hindi)'], ['heroSubtitle', 'Hero Subtitle', 'textarea'], ['aboutText', 'About Text', 'textarea'], ['visionText', 'Vision Text (Hindi)', 'textarea']] },
  { title: 'Impact Statistics', note: 'Only publish verified statistics.', fields: [['statMembers', 'Community Members'], ['statCreators', 'Creators'], ['statSeva', 'Temple Seva Projects'], ['statInitiatives', 'Social Initiatives'], ['statEvents', 'Cultural Events']] },
  { title: 'Contact Details', fields: [['phone', 'Phone'], ['whatsapp', 'WhatsApp Number'], ['email', 'Email'], ['address', 'Address'], ['city', 'City'], ['mapsEmbed', 'Google Maps Embed (iframe HTML)', 'textarea']] },
  { title: 'Social Links', fields: [['instagram', 'Instagram URL'], ['youtube', 'YouTube URL'], ['facebook', 'Facebook URL']] },
  { title: 'Payment (stored securely on server)', note: 'Razorpay secret is never exposed to the website. Set RAZORPAY_KEY_ID & RAZORPAY_KEY_SECRET as backend env vars for live payments.', fields: [['upiId', 'UPI ID']] },
]

export default function Settings() {
  const toast = useToast()
  const [data, setData] = useState(null)
  const [saving, setSaving] = useState(false)
  useEffect(() => { api.get('/admin/settings').then((r) => setData(r.data)).catch(() => setData({})) }, [])
  const set = (k, v) => setData((d) => ({ ...d, [k]: v }))
  const save = async () => { setSaving(true); try { await api.put('/admin/settings', data); toast.success('Settings saved') } catch { toast.error('Save failed') } setSaving(false) }

  if (!data) return <Spinner />
  return (
    <div>
      <AdminHeader title="Settings & CMS" action={<button onClick={save} disabled={saving} className="btn-primary !py-2 !px-4 text-sm" data-testid="settings-save"><Save className="w-4 h-4" /> {saving ? 'Saving…' : 'Save All'}</button>} />
      <div className="grid lg:grid-cols-2 gap-6">
        {groups.map((g) => (
          <div key={g.title} className="bg-white rounded-2xl shadow-card border border-gold/20 p-6">
            <h3 className="font-semibold text-maroon mb-1">{g.title}</h3>
            {g.note && <p className="text-xs text-amber-700 bg-amber-50 rounded-lg px-3 py-2 mb-4 flex items-center gap-1.5"><Info className="w-3.5 h-3.5" /> {g.note}</p>}
            <div className="space-y-3 mt-2">
              {g.fields.map(([key, label, type]) => (
                <div key={key}>
                  <label className="label">{label}</label>
                  {type === 'textarea'
                    ? <textarea rows="2" className="input" data-testid={`setting-${key}`} value={data[key] || ''} onChange={(e) => set(key, e.target.value)} />
                    : <input className="input" data-testid={`setting-${key}`} value={data[key] || ''} onChange={(e) => set(key, e.target.value)} />}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
