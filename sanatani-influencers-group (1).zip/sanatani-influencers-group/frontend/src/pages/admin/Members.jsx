import { useEffect, useState } from 'react'
import api, { imgUrl, ASSET_BASE } from '../../lib/api'
import { useToast, Spinner, EmptyState, Modal } from '../../components/ui'
import { AdminHeader } from './CrudManager'
import { Search, Download, Check, X, Ban, Trash2, Eye, Users } from 'lucide-react'

export default function Members({ pendingOnly }) {
  const toast = useToast()
  const [members, setMembers] = useState(null)
  const [q, setQ] = useState('')
  const [status, setStatus] = useState(pendingOnly ? 'PENDING' : 'All')
  const [view, setView] = useState(null)

  const load = () => {
    const url = pendingOnly ? '/admin/members/pending' : (status === 'All' ? '/admin/members' : `/admin/members?status=${status}`)
    api.get(url).then((r) => setMembers(r.data)).catch(() => setMembers([]))
  }
  useEffect(() => { load() }, [status, pendingOnly])

  const act = async (id, action, note) => {
    try {
      await api.post(`/admin/members/${id}/${action}`, note ? { note } : {})
      toast.success(`Member ${action}d`); load()
    } catch { toast.error('Action failed') }
  }
  const del = async (id) => { if (!confirm('Delete member?')) return; try { await api.delete(`/admin/members/${id}`); toast.success('Deleted'); load() } catch { toast.error('Failed') } }
  const exportCsv = () => { window.open(`${ASSET_BASE}/api/admin/members/export`, '_blank') }

  const shown = (members || []).filter((m) => !q || m.fullName?.toLowerCase().includes(q.toLowerCase()) || m.city?.toLowerCase().includes(q.toLowerCase()))

  return (
    <div>
      <AdminHeader title={pendingOnly ? 'Pending Applications' : 'Members'} action={
        !pendingOnly && <button onClick={exportCsv} className="btn-secondary !py-2 !px-4 text-sm" data-testid="members-export"><Download className="w-4 h-4" /> Export CSV</button>
      } />

      <div className="flex flex-wrap gap-3 mb-4">
        <div className="relative flex-1 min-w-[200px]"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-ink/40" /><input className="input !pl-9" placeholder="Search name or city…" data-testid="members-search" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        {!pendingOnly && (
          <select className="input max-w-[180px]" value={status} onChange={(e) => setStatus(e.target.value)} data-testid="members-status-filter">
            {['All', 'PENDING', 'APPROVED', 'REJECTED', 'SUSPENDED'].map((s) => <option key={s}>{s}</option>)}
          </select>
        )}
      </div>

      {members === null ? <Spinner /> : shown.length === 0 ? (
        <EmptyState icon={Users} title="No members found" />
      ) : (
        <div className="bg-white rounded-2xl shadow-card border border-gold/20 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-cream-muted text-left text-maroon"><tr>
              <th className="px-4 py-3">Name</th><th className="px-4 py-3">Member ID</th><th className="px-4 py-3">City</th><th className="px-4 py-3">Category</th><th className="px-4 py-3">Status</th><th className="px-4 py-3 text-right">Actions</th>
            </tr></thead>
            <tbody className="divide-y divide-cream-muted">
              {shown.map((m) => (
                <tr key={m.id} className="hover:bg-cream/50" data-testid={`member-row-${m.id}`}>
                  <td className="px-4 py-3 font-medium text-maroon">{m.fullName}</td>
                  <td className="px-4 py-3 text-ink/70">{m.memberId || '—'}</td>
                  <td className="px-4 py-3 text-ink/70">{m.city}</td>
                  <td className="px-4 py-3 text-ink/70">{m.creatorCategory}</td>
                  <td className="px-4 py-3"><span className={`text-xs px-2 py-0.5 rounded-full ${m.status === 'APPROVED' ? 'bg-green-100 text-green-700' : m.status === 'PENDING' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'}`}>{m.status}</span></td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-1">
                      <button onClick={() => setView(m)} className="p-1.5 text-ink/50 hover:text-blue-500" data-testid={`member-view-${m.id}`}><Eye className="w-4 h-4" /></button>
                      {m.status !== 'APPROVED' && <button onClick={() => act(m.id, 'approve')} className="p-1.5 text-ink/50 hover:text-green-600" data-testid={`member-approve-${m.id}`}><Check className="w-4 h-4" /></button>}
                      {m.status !== 'REJECTED' && <button onClick={() => act(m.id, 'reject', prompt('Reason (optional)') || '')} className="p-1.5 text-ink/50 hover:text-red-500" data-testid={`member-reject-${m.id}`}><X className="w-4 h-4" /></button>}
                      <button onClick={() => act(m.id, 'suspend')} className="p-1.5 text-ink/50 hover:text-amber-600"><Ban className="w-4 h-4" /></button>
                      <button onClick={() => del(m.id)} className="p-1.5 text-ink/50 hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={!!view} onClose={() => setView(null)} title="Member Details" testid="member-detail-modal">
        {view && (
          <div className="space-y-3 text-sm">
            <div className="flex items-center gap-4">
              <img src={view.profilePhoto ? imgUrl(view.profilePhoto) : ''} onError={(e) => e.target.style.display = 'none'} alt="" className="w-16 h-16 rounded-full object-cover bg-cream-muted" />
              <div><p className="text-lg font-bold text-maroon">{view.fullName}</p><p className="text-saffron">{view.creatorCategory}</p></div>
            </div>
            {[['Member ID', view.memberId], ['Email', view.email], ['Mobile', view.mobile], ['City', view.city], ['State', view.state], ['Instagram', view.instagram], ['Followers', view.instagramFollowers], ['Why Join', view.whyJoin], ['Contribute', view.howContribute]].map(([k, v]) => v && (
              <div key={k} className="flex justify-between border-b border-cream-muted pb-1"><span className="text-ink/50">{k}</span><span className="text-maroon text-right max-w-[60%]">{v}</span></div>
            ))}
            {view.idProof && <div className="text-xs text-ink/40 mt-2">ID proof uploaded (kept private, visible to admins only)</div>}
          </div>
        )}
      </Modal>
    </div>
  )
}
