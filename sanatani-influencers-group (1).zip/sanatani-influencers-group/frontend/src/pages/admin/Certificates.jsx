import { useEffect, useState } from 'react'
import api, { ASSET_BASE } from '../../lib/api'
import { useToast, Spinner, EmptyState, Modal } from '../../components/ui'
import { AdminHeader } from './CrudManager'
import { Award, Plus, Ban, QrCode } from 'lucide-react'

const TYPES = ['Volunteer Certificate', 'Event Participation Certificate', 'Seva Participation Certificate', 'Appreciation Certificate', 'Creator Recognition Certificate', 'Event Organizer Certificate']

export default function Certificates() {
  const toast = useToast()
  const [list, setList] = useState(null)
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({ recipient: '', type: TYPES[0], eventProject: '', issueDate: new Date().toISOString().slice(0, 10), issuedBy: '', designation: '' })
  const [saving, setSaving] = useState(false)
  const load = () => api.get('/admin/certificates').then((r) => setList(r.data)).catch(() => setList([]))
  useEffect(() => { load() }, [])

  const submit = async (e) => {
    e.preventDefault(); setSaving(true)
    try { await api.post('/admin/certificates/generate', form); toast.success('Certificate generated'); setOpen(false); load() }
    catch { toast.error('Failed') } setSaving(false)
  }
  const revoke = async (id) => { if (!confirm('Revoke certificate?')) return; try { await api.post(`/admin/certificates/${id}/revoke`); toast.success('Revoked'); load() } catch { toast.error('Failed') } }

  return (
    <div>
      <AdminHeader title="Certificates" action={<button onClick={() => setOpen(true)} className="btn-primary !py-2 !px-4 text-sm" data-testid="cert-generate-btn"><Plus className="w-4 h-4" /> Generate</button>} />
      {list === null ? <Spinner /> : list.length === 0 ? <EmptyState icon={Award} title="No certificates yet" message="Generate volunteer, event or seva certificates." /> : (
        <div className="bg-white rounded-2xl shadow-card border border-gold/20 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-cream-muted text-left text-maroon"><tr>
              <th className="px-4 py-3">Number</th><th className="px-4 py-3">Recipient</th><th className="px-4 py-3">Type</th><th className="px-4 py-3">Status</th><th className="px-4 py-3 text-right">Verify / Actions</th>
            </tr></thead>
            <tbody className="divide-y divide-cream-muted">
              {list.map((c) => (
                <tr key={c.id} className="hover:bg-cream/50">
                  <td className="px-4 py-3 text-saffron font-medium">{c.certificateNumber}</td>
                  <td className="px-4 py-3 text-maroon">{c.recipient}</td>
                  <td className="px-4 py-3 text-ink/70">{c.type}</td>
                  <td className="px-4 py-3"><span className={`text-xs px-2 py-0.5 rounded-full ${c.status === 'VALID' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{c.status}</span></td>
                  <td className="px-4 py-3"><div className="flex justify-end gap-2 items-center">
                    <a href={`/verify-certificate/${c.certificateNumber}`} target="_blank" rel="noreferrer" className="p-1.5 text-ink/50 hover:text-blue-500" title="Verify page"><QrCode className="w-4 h-4" /></a>
                    {c.status === 'VALID' && <button onClick={() => revoke(c.id)} className="p-1.5 text-ink/50 hover:text-red-500"><Ban className="w-4 h-4" /></button>}
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Generate Certificate" testid="cert-modal">
        <form onSubmit={submit} className="space-y-4">
          <div><label className="label">Recipient *</label><input required className="input" data-testid="cert-recipient" value={form.recipient} onChange={(e) => setForm({ ...form, recipient: e.target.value })} /></div>
          <div><label className="label">Type</label><select className="input" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>{TYPES.map((t) => <option key={t}>{t}</option>)}</select></div>
          <div><label className="label">Event / Project</label><input className="input" value={form.eventProject} onChange={(e) => setForm({ ...form, eventProject: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label">Issue Date</label><input type="date" className="input" value={form.issueDate} onChange={(e) => setForm({ ...form, issueDate: e.target.value })} /></div>
            <div><label className="label">Issued By</label><input className="input" value={form.issuedBy} onChange={(e) => setForm({ ...form, issuedBy: e.target.value })} /></div>
          </div>
          <div><label className="label">Signatory Designation</label><input className="input" value={form.designation} onChange={(e) => setForm({ ...form, designation: e.target.value })} /></div>
          <button disabled={saving} className="btn-primary w-full" data-testid="cert-save-btn">{saving ? 'Generating…' : 'Generate Certificate'}</button>
        </form>
      </Modal>
    </div>
  )
}
