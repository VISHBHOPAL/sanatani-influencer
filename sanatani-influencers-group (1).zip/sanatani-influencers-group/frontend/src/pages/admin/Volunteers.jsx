import { useEffect, useState } from 'react'
import api from '../../lib/api'
import { useToast, Spinner, EmptyState } from '../../components/ui'
import { AdminHeader } from './CrudManager'
import { HandHeart, Check, X } from 'lucide-react'

export default function Volunteers() {
  const toast = useToast()
  const [list, setList] = useState(null)
  const load = () => api.get('/admin/volunteers').then((r) => setList(r.data)).catch(() => setList([]))
  useEffect(() => { load() }, [])
  const act = async (id, a) => { try { await api.post(`/admin/volunteers/${id}/${a}`); toast.success(`Volunteer ${a}d`); load() } catch { toast.error('Failed') } }

  return (
    <div>
      <AdminHeader title="Volunteers" />
      {list === null ? <Spinner /> : list.length === 0 ? <EmptyState icon={HandHeart} title="No volunteer applications yet" /> : (
        <div className="bg-white rounded-2xl shadow-card border border-gold/20 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-cream-muted text-left text-maroon"><tr>
              <th className="px-4 py-3">Name</th><th className="px-4 py-3">City</th><th className="px-4 py-3">Category</th><th className="px-4 py-3">Mobile</th><th className="px-4 py-3">Status</th><th className="px-4 py-3 text-right">Actions</th>
            </tr></thead>
            <tbody className="divide-y divide-cream-muted">
              {list.map((v) => (
                <tr key={v.id} className="hover:bg-cream/50" data-testid={`volunteer-row-${v.id}`}>
                  <td className="px-4 py-3 font-medium text-maroon">{v.name}</td>
                  <td className="px-4 py-3 text-ink/70">{v.city}</td>
                  <td className="px-4 py-3 text-ink/70">{v.category}</td>
                  <td className="px-4 py-3 text-ink/70">{v.mobile}</td>
                  <td className="px-4 py-3"><span className={`text-xs px-2 py-0.5 rounded-full ${v.status === 'APPROVED' ? 'bg-green-100 text-green-700' : v.status === 'PENDING' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'}`}>{v.status}</span></td>
                  <td className="px-4 py-3"><div className="flex justify-end gap-1">
                    <button onClick={() => act(v.id, 'approve')} className="p-1.5 text-ink/50 hover:text-green-600"><Check className="w-4 h-4" /></button>
                    <button onClick={() => act(v.id, 'reject')} className="p-1.5 text-ink/50 hover:text-red-500"><X className="w-4 h-4" /></button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
