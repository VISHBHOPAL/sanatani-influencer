import CrudManager from './CrudManager'
import { EVENT_CATEGORIES } from '../../constants'

export default function EventsAdmin() {
  return (
    <CrudManager
      title="Events" listUrl="/events" mutateUrl="/admin/events"
      fields={[
        { name: 'name', label: 'Event Name', required: true },
        { name: 'category', label: 'Category', type: 'select', options: EVENT_CATEGORIES },
        { name: 'status', label: 'Status', type: 'select', options: ['UPCOMING', 'ONGOING', 'PAST'] },
        { name: 'date', label: 'Date', type: 'date' },
        { name: 'time', label: 'Time' },
        { name: 'venue', label: 'Venue' },
        { name: 'mapsLocation', label: 'Google Maps URL' },
        { name: 'organizer', label: 'Organizer' },
        { name: 'registrationRequired', label: 'Registration Required?', type: 'checkbox' },
        { name: 'registrationDeadline', label: 'Registration Deadline', type: 'date' },
        { name: 'maxParticipants', label: 'Max Participants', type: 'number' },
        { name: 'banner', label: 'Banner Image', type: 'image' },
        { name: 'description', label: 'Description', type: 'textarea' },
      ]}
      columns={['name', 'category', 'date', 'status']} imageCol="banner"
    />
  )
}
