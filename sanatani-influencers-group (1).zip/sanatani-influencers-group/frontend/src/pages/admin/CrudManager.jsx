import { useEffect, useState } from 'react'
import api, { imgUrl } from '../../lib/api'
import { useToast, Spinner, Modal, EmptyState } from '../../components/ui'
import { Plus, Pencil, Trash2, Upload, Inbox } from 'lucide-react'

export function AdminHeader({ title, action }) {
  return (
    <div className="flex items-center justify-between mb-6">
      <h1 className="text-2xl font-bold text-maroon">{title}</h1>
      {action}
    </div>
  )
}

export default function CrudManager({ title, listUrl, mutateUrl, fields, columns, imageCol, defaults = {} }) {
  const toast = useToast()
  const [items, setItems] = useState(null)
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({})
  const [editing, setEditing] = useState(null)
  const [saving, setSaving] = useState(false)

  const load = () => api.get(listUrl).then((r) => setItems(r.data)).catch(() => setItems([]))
  useEffect(() => { load() }, [listUrl])

  const openNew = () => { setForm({ ...defaults }); setEditing(null); setOpen(true) }
  const openEdit = (item) => { setForm({ ...item }); setEditing(item.id); setOpen(true) }

  const upload = async (file, key) => {
    if (!file) return
    const fd = new FormData(); fd.append('file', file)
    try { const res = await api.post('/upload', fd, { headers: { 'Content-Type': 'multipart/form-data' } }); setForm((f) => ({ ...f, [key]: res.data.data.url })); toast.success('Uploaded') }
    catch (e) { toast.error(e.response?.data?.message || 'Upload failed') }
  }

  const submit = async (e) => {
    e.preventDefault(); setSaving(true)
    try {
      if (editing) await api.put(`${mutateUrl}/${editing}`, form)
      else await api.post(mutateUrl, form)
      toast.success('Saved'); setOpen(false); load()
    } catch (err) { toast.error(err.response?.data?.message || 'Save failed') }
    setSaving(false)
  }

  const remove = async (id) => {
    if (!confirm('Delete this item?')) return
    try { await api.delete(`${mutateUrl}/${id}`); toast.success('Deleted'); load() }
    catch { toast.error('Delete failed') }
  }

  return (
    <div>
      <AdminHeader title={title} action={<button onClick={openNew} className="btn-primary !py-2 !px-4 text-sm" data-testid="crud-add-btn"><Plus className="w-4 h-4" /> Add New</button>} />
      {items === null ? <Spinner /> : items.length === 0 ? (
        <EmptyState icon={Inbox} title={`No ${title.toLowerCase()} yet`} message="Click 'Add New' to create your first entry." />
      ) : (
        <div className="bg-white rounded-2xl shadow-card border border-gold/20 overflow-hidden overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-cream-muted text-left text-maroon">
              <tr>
                {imageCol && <th className="px-4 py-3 font-semibold">Image</th>}
                {columns.map((c) => <th key={c} className="px-4 py-3 font-semibold capitalize">{c}</th>)}
                <th className="px-4 py-3 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-cream-muted">
              {items.map((it) => (
                <tr key={it.id} className="hover:bg-cream/50" data-testid={`crud-row-${it.id}`}>
                  {imageCol && <td className="px-4 py-2">{it[imageCol] ? <img src={imgUrl(it[imageCol])} alt="" className="w-10 h-10 rounded object-cover" /> : <span className="text-ink/30">—</span>}</td>}
                  {columns.map((c) => <td key={c} className="px-4 py-3 text-ink/80">{typeof it[c] === 'boolean' ? (it[c] ? 'Yes' : 'No') : (String(it[c] ?? '—').slice(0, 40))}</td>)}
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-2">
                      <button onClick={() => openEdit(it)} className="p-1.5 text-ink/50 hover:text-saffron" data-testid={`crud-edit-${it.id}`}><Pencil className="w-4 h-4" /></button>
                      <button onClick={() => remove(it.id)} className="p-1.5 text-ink/50 hover:text-red-500" data-testid={`crud-delete-${it.id}`}><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? `Edit ${title}` : `Add ${title}`} testid="crud-modal">
        <form onSubmit={submit} className="space-y-4">
          {fields.map((f) => (
            <div key={f.name}>
              <label className="label">{f.label}{f.required && ' *'}</label>
              {f.type === 'textarea' ? (
                <textarea rows="3" className="input" required={f.required} value={form[f.name] || ''} onChange={(e) => setForm({ ...form, [f.name]: e.target.value })} />
              ) : f.type === 'select' ? (
                <select className="input" required={f.required} value={form[f.name] || ''} onChange={(e) => setForm({ ...form, [f.name]: e.target.value })}>
                  <option value="">Select</option>{f.options.map((o) => <option key={o}>{o}</option>)}
                </select>
              ) : f.type === 'checkbox' ? (
                <label className="flex items-center gap-2 text-sm text-ink/70"><input type="checkbox" checked={!!form[f.name]} onChange={(e) => setForm({ ...form, [f.name]: e.target.checked })} /> {f.label}</label>
              ) : f.type === 'image' ? (
                <div className="flex items-center gap-3">
                  {form[f.name] && <img src={imgUrl(form[f.name])} alt="" className="w-12 h-12 rounded object-cover" />}
                  <label className="flex items-center gap-2 input cursor-pointer text-ink/60 flex-1"><Upload className="w-4 h-4" /> {form[f.name] ? 'Replace' : 'Upload'}<input type="file" accept="image/*" className="hidden" onChange={(e) => upload(e.target.files[0], f.name)} /></label>
                  <input className="input flex-1" placeholder="or paste URL" value={form[f.name] || ''} onChange={(e) => setForm({ ...form, [f.name]: e.target.value })} />
                </div>
              ) : (
                <input type={f.type || 'text'} className="input" required={f.required} value={form[f.name] || ''} onChange={(e) => setForm({ ...form, [f.name]: e.target.value })} />
              )}
            </div>
          ))}
          <button disabled={saving} className="btn-primary w-full" data-testid="crud-save-btn">{saving ? 'Saving…' : 'Save'}</button>
        </form>
      </Modal>
    </div>
  )
}
