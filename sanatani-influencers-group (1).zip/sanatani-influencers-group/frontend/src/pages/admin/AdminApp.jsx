import { Routes, Route, NavLink, useNavigate, Navigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { LOGO } from '../../constants'
import {
  LayoutDashboard, Users, UserCheck, HandHeart, Calendar, ClipboardList,
  FolderKanban, Landmark, IndianRupee, Award, Image, Newspaper, Trophy,
  Crown, Handshake, MessageSquare, Settings as SettingsIcon, LogOut, Home,
} from 'lucide-react'

import Dashboard from './Dashboard'
import Members from './Members'
import Volunteers from './Volunteers'
import EventsAdmin from './EventsAdmin'
import Registrations from './Registrations'
import Donations from './Donations'
import Certificates from './Certificates'
import Messages from './Messages'
import Settings from './Settings'
import CrudManager from './CrudManager'
import { PROJECT_CATEGORIES, EVENT_CATEGORIES, GALLERY_CATEGORIES } from '../../constants'

const nav = [
  { to: '', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: 'members', label: 'Members', icon: Users },
  { to: 'pending', label: 'Pending Applications', icon: UserCheck },
  { to: 'volunteers', label: 'Volunteers', icon: HandHeart },
  { to: 'events', label: 'Events', icon: Calendar },
  { to: 'registrations', label: 'Event Registrations', icon: ClipboardList },
  { to: 'projects', label: 'Projects', icon: FolderKanban },
  { to: 'seva', label: 'Temple Seva', icon: Landmark },
  { to: 'donations', label: 'Donations', icon: IndianRupee },
  { to: 'certificates', label: 'Certificates', icon: Award },
  { to: 'gallery', label: 'Gallery', icon: Image },
  { to: 'news', label: 'News', icon: Newspaper },
  { to: 'achievements', label: 'Achievements', icon: Trophy },
  { to: 'leadership', label: 'Leadership', icon: Crown },
  { to: 'partners', label: 'Partners', icon: Handshake },
  { to: 'messages', label: 'Contact Messages', icon: MessageSquare },
  { to: 'settings', label: 'Settings', icon: SettingsIcon },
]

export default function AdminApp() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  return (
    <div className="min-h-screen flex bg-cream-muted">
      <aside className="w-64 bg-charcoal text-cream/80 flex flex-col fixed inset-y-0 print:hidden overflow-y-auto">
        <div className="px-5 py-5 flex items-center gap-3 border-b border-white/10">
          <img src={LOGO} alt="logo" className="w-10 h-10 rounded-full ring-2 ring-gold/40" />
          <div><p className="font-display font-bold text-cream text-sm">Admin Panel</p><p className="text-[10px] text-gold uppercase tracking-wide">{user?.role}</p></div>
        </div>
        <nav className="flex-1 py-3 px-2 space-y-0.5">
          {nav.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end}
              className={({ isActive }) => `flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${isActive ? 'bg-saffron text-white' : 'hover:bg-white/5'}`}
              data-testid={`admin-nav-${n.label.toLowerCase().replace(/\s/g, '-')}`}>
              <n.icon className="w-4 h-4 shrink-0" /> {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-3 border-t border-white/10 space-y-1">
          <button onClick={() => navigate('/')} className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm w-full hover:bg-white/5"><Home className="w-4 h-4" /> View Website</button>
          <button onClick={() => { logout(); navigate('/') }} className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm w-full hover:bg-white/5 text-red-300" data-testid="admin-logout"><LogOut className="w-4 h-4" /> Logout</button>
        </div>
      </aside>

      <main className="flex-1 ml-64 print:ml-0 p-6 lg:p-8">
        <Routes>
          <Route index element={<Dashboard />} />
          <Route path="members" element={<Members />} />
          <Route path="pending" element={<Members pendingOnly />} />
          <Route path="volunteers" element={<Volunteers />} />
          <Route path="events" element={<EventsAdmin />} />
          <Route path="registrations" element={<Registrations />} />
          <Route path="donations" element={<Donations />} />
          <Route path="certificates" element={<Certificates />} />
          <Route path="messages" element={<Messages />} />
          <Route path="settings" element={<Settings />} />
          <Route path="projects" element={<CrudManager
            title="Projects" listUrl="/admin/projects" mutateUrl="/admin/projects"
            fields={[
              { name: 'name', label: 'Name', required: true },
              { name: 'category', label: 'Category', type: 'select', options: PROJECT_CATEGORIES },
              { name: 'location', label: 'Location' },
              { name: 'date', label: 'Date', type: 'date' },
              { name: 'status', label: 'Status', type: 'select', options: ['PLANNED', 'ONGOING', 'COMPLETED'] },
              { name: 'volunteersCount', label: 'Volunteers', type: 'number' },
              { name: 'templeSeva', label: 'Is Temple Seva?', type: 'checkbox' },
              { name: 'description', label: 'Description', type: 'textarea' },
              { name: 'impact', label: 'Impact', type: 'textarea' },
              { name: 'beforeImage', label: 'Before Image', type: 'image' },
              { name: 'afterImage', label: 'After Image', type: 'image' },
            ]}
            columns={['name', 'category', 'location', 'status']} />} />
          <Route path="seva" element={<CrudManager
            title="Temple Seva Projects" listUrl="/projects/temple-seva" mutateUrl="/admin/projects"
            defaults={{ templeSeva: true, category: 'Temple Seva' }}
            fields={[
              { name: 'name', label: 'Name', required: true },
              { name: 'location', label: 'Location' },
              { name: 'date', label: 'Date', type: 'date' },
              { name: 'status', label: 'Status', type: 'select', options: ['PLANNED', 'ONGOING', 'COMPLETED'] },
              { name: 'volunteersCount', label: 'Volunteers', type: 'number' },
              { name: 'templeSeva', label: 'Is Temple Seva?', type: 'checkbox' },
              { name: 'description', label: 'Description', type: 'textarea' },
              { name: 'beforeImage', label: 'Before Image', type: 'image' },
              { name: 'afterImage', label: 'After Image', type: 'image' },
            ]}
            columns={['name', 'location', 'status']} />} />
          <Route path="gallery" element={<CrudManager
            title="Gallery" listUrl="/gallery" mutateUrl="/admin/gallery"
            fields={[
              { name: 'title', label: 'Title', required: true },
              { name: 'category', label: 'Category', type: 'select', options: GALLERY_CATEGORIES },
              { name: 'imageUrl', label: 'Image', type: 'image', required: true },
              { name: 'album', label: 'Album' },
              { name: 'date', label: 'Date', type: 'date' },
              { name: 'location', label: 'Location' },
              { name: 'caption', label: 'Caption', type: 'textarea' },
            ]}
            columns={['title', 'category', 'location']} imageCol="imageUrl" />} />
          <Route path="news" element={<CrudManager
            title="News & Articles" listUrl="/admin/news" mutateUrl="/admin/news"
            fields={[
              { name: 'title', label: 'Title', required: true },
              { name: 'category', label: 'Category' },
              { name: 'author', label: 'Author' },
              { name: 'date', label: 'Date', type: 'date' },
              { name: 'featuredImage', label: 'Featured Image', type: 'image' },
              { name: 'published', label: 'Published', type: 'checkbox' },
              { name: 'content', label: 'Content', type: 'textarea' },
              { name: 'seoTitle', label: 'SEO Title' },
              { name: 'seoDescription', label: 'SEO Description', type: 'textarea' },
            ]}
            columns={['title', 'category', 'published']} />} />
          <Route path="achievements" element={<CrudManager
            title="Achievements" listUrl="/admin/achievements" mutateUrl="/admin/achievements"
            fields={[
              { name: 'title', label: 'Title', required: true },
              { name: 'category', label: 'Category' },
              { name: 'date', label: 'Date', type: 'date' },
              { name: 'orderIndex', label: 'Order', type: 'number' },
              { name: 'published', label: 'Published', type: 'checkbox' },
              { name: 'image', label: 'Image', type: 'image' },
              { name: 'description', label: 'Description', type: 'textarea' },
            ]}
            columns={['title', 'category', 'date']} />} />
          <Route path="leadership" element={<CrudManager
            title="Leadership" listUrl="/leadership" mutateUrl="/admin/leadership"
            fields={[
              { name: 'name', label: 'Name', required: true },
              { name: 'designation', label: 'Designation', required: true },
              { name: 'orderIndex', label: 'Order', type: 'number' },
              { name: 'isPresident', label: 'Is President/Adhyaksh?', type: 'checkbox' },
              { name: 'photo', label: 'Photo', type: 'image' },
              { name: 'instagram', label: 'Instagram URL' },
              { name: 'linkedin', label: 'LinkedIn URL' },
              { name: 'email', label: 'Email' },
              { name: 'contactEnabled', label: 'Show contact button', type: 'checkbox' },
              { name: 'bio', label: 'Bio', type: 'textarea' },
              { name: 'presidentMessage', label: "President's Message (अध्यक्ष का संदेश)", type: 'textarea' },
            ]}
            columns={['name', 'designation']} imageCol="photo" />} />
          <Route path="partners" element={<CrudManager
            title="Partners" listUrl="/partners" mutateUrl="/admin/partners"
            fields={[
              { name: 'name', label: 'Name', required: true },
              { name: 'partnershipType', label: 'Partnership Type' },
              { name: 'website', label: 'Website' },
              { name: 'logo', label: 'Logo', type: 'image' },
              { name: 'description', label: 'Description', type: 'textarea' },
            ]}
            columns={['name', 'partnershipType']} imageCol="logo" />} />
          <Route path="*" element={<Navigate to="/admin" replace />} />
        </Routes>
      </main>
    </div>
  )
}
