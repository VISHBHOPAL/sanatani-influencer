import { useEffect, useState } from 'react'
import api from '../../lib/api'
import { Spinner } from '../../components/ui'
import { AdminHeader } from './CrudManager'
import {
  Users, UserCheck, HandHeart, Calendar, ClipboardList, IndianRupee,
  FolderKanban, Newspaper, Award, MessageSquare,
} from 'lucide-react'

const cards = [
  ['totalMembers', 'Total Members', Users, 'text-blue-600 bg-blue-50'],
  ['pendingApplications', 'Pending Applications', UserCheck, 'text-amber-600 bg-amber-50'],
  ['totalVolunteers', 'Volunteers', HandHeart, 'text-green-600 bg-green-50'],
  ['upcomingEvents', 'Upcoming Events', Calendar, 'text-purple-600 bg-purple-50'],
  ['eventRegistrations', 'Event Registrations', ClipboardList, 'text-pink-600 bg-pink-50'],
  ['totalDonations', 'Total Donations (₹)', IndianRupee, 'text-saffron bg-orange-50', true],
  ['monthlyDonations', 'Monthly Donations (₹)', IndianRupee, 'text-rose-600 bg-rose-50', true],
  ['activeProjects', 'Active Projects', FolderKanban, 'text-teal-600 bg-teal-50'],
  ['publishedArticles', 'Published Articles', Newspaper, 'text-indigo-600 bg-indigo-50'],
  ['certificatesIssued', 'Certificates Issued', Award, 'text-yellow-600 bg-yellow-50'],
  ['unreadMessages', 'Unread Messages', MessageSquare, 'text-red-600 bg-red-50'],
]

function BarChart({ title, data }) {
  const entries = Object.entries(data || {})
  const max = Math.max(1, ...entries.map(([, v]) => v))
  return (
    <div className="bg-white rounded-2xl shadow-card border border-gold/20 p-6">
      <h3 className="font-semibold text-maroon mb-4">{title}</h3>
      {entries.length === 0 ? <p className="text-ink/40 text-sm">No data yet.</p> : (
        <div className="space-y-3">
          {entries.map(([k, v]) => (
            <div key={k}>
              <div className="flex justify-between text-xs mb-1"><span className="text-ink/70">{k}</span><span className="text-maroon font-medium">{typeof v === 'number' && v > 999 ? v.toLocaleString('en-IN') : v}</span></div>
              <div className="h-2 bg-cream-muted rounded-full"><div className="h-full bg-saffron rounded-full" style={{ width: `${(v / max) * 100}%` }} /></div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default function Dashboard() {
  const [stats, setStats] = useState(null)
  const [charts, setCharts] = useState({})
  useEffect(() => {
    api.get('/admin/dashboard/stats').then((r) => setStats(r.data)).catch(() => setStats({}))
    api.get('/admin/dashboard/charts').then((r) => setCharts(r.data)).catch(() => {})
  }, [])

  return (
    <div>
      <AdminHeader title="Dashboard" />
      {!stats ? <Spinner /> : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
            {cards.map(([key, label, Icon, color, money]) => (
              <div key={key} className="bg-white rounded-2xl shadow-card border border-gold/20 p-5" data-testid={`dash-${key}`}>
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${color}`}><Icon className="w-5 h-5" /></div>
                <p className="text-2xl font-bold text-maroon font-display">{money ? '₹' : ''}{Number(stats[key] || 0).toLocaleString('en-IN')}</p>
                <p className="text-xs text-ink/50 mt-1">{label}</p>
              </div>
            ))}
          </div>
          <div className="grid md:grid-cols-3 gap-6 mt-6">
            <BarChart title="Members by City" data={charts.membersByCity} />
            <BarChart title="Creator Categories" data={charts.membersByCategory} />
            <BarChart title="Donations by Category (₹)" data={charts.donationsByCategory} />
          </div>
        </>
      )}
    </div>
  )
}
