import { useEffect, useState } from 'react'
import api from '../../lib/api'
import { Spinner, EmptyState } from '../../components/ui'
import { AdminHeader } from './CrudManager'
import { IndianRupee } from 'lucide-react'

export default function Donations() {
  const [list, setList] = useState(null)
  useEffect(() => { api.get('/admin/donations').then((r) => setList(r.data)).catch(() => setList([])) }, [])
  const total = (list || []).filter((d) => d.status === 'SUCCESS').reduce((a, d) => a + (d.amount || 0), 0)
  return (
    <div>
      <AdminHeader title="Donations" />
      {list === null ? <Spinner /> : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Stat label="Total Received" value={`₹${total.toLocaleString('en-IN')}`} />
            <Stat label="Successful" value={list.filter((d) => d.status === 'SUCCESS').length} />
            <Stat label="Pending" value={list.filter((d) => d.status === 'PENDING').length} />
            <Stat label="Failed" value={list.filter((d) => d.status === 'FAILED').length} />
          </div>
          {list.length === 0 ? <EmptyState icon={IndianRupee} title="No donations yet" /> : (
            <div className="bg-white rounded-2xl shadow-card border border-gold/20 overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-cream-muted text-left text-maroon"><tr>
                  <th className="px-4 py-3">Donation ID</th><th className="px-4 py-3">Donor</th><th className="px-4 py-3">Amount</th><th className="px-4 py-3">Category</th><th className="px-4 py-3">Status</th>
                </tr></thead>
                <tbody className="divide-y divide-cream-muted">
                  {list.map((d) => (
                    <tr key={d.id} className="hover:bg-cream/50">
                      <td className="px-4 py-3 text-saffron font-medium">{d.donationId}</td>
                      <td className="px-4 py-3 text-maroon">{d.anonymous ? 'Anonymous' : d.name}</td>
                      <td className="px-4 py-3 text-ink/80">₹{Number(d.amount).toLocaleString('en-IN')}</td>
                      <td className="px-4 py-3 text-ink/70">{d.category}</td>
                      <td className="px-4 py-3"><span className={`text-xs px-2 py-0.5 rounded-full ${d.status === 'SUCCESS' ? 'bg-green-100 text-green-700' : d.status === 'PENDING' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'}`}>{d.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  )
}
function Stat({ label, value }) {
  return <div className="bg-white rounded-2xl shadow-card border border-gold/20 p-5"><p className="text-2xl font-bold text-maroon font-display">{value}</p><p className="text-xs text-ink/50 mt-1">{label}</p></div>
}
