import { useEffect, useState } from 'react'
import api from '../../lib/api'
import { useToast, Spinner, EmptyState } from '../../components/ui'
import { AdminHeader } from './CrudManager'
import { MessageSquare, Check } from 'lucide-react'

export default function Messages() {
  const toast = useToast()
  const [list, setList] = useState(null)
  const load = () => api.get('/admin/messages').then((r) => setList(r.data)).catch(() => setList([]))
  useEffect(() => { load() }, [])
  const markRead = async (id) => { try { await api.post(`/admin/messages/${id}/read`); load() } catch { toast.error('Failed') } }
  return (
    <div>
      <AdminHeader title="Contact Messages" />
      {list === null ? <Spinner /> : list.length === 0 ? <EmptyState icon={MessageSquare} title="No messages yet" /> : (
        <div className="space-y-3">
          {list.map((m) => (
            <div key={m.id} className={`bg-white rounded-2xl shadow-card border p-5 ${m.readFlag ? 'border-cream-muted' : 'border-saffron/40'}`} data-testid={`message-${m.id}`}>
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold text-maroon">{m.name} {!m.readFlag && <span className="text-xs bg-saffron text-white px-2 py-0.5 rounded-full ml-2">New</span>}</p>
                  <p className="text-xs text-ink/50">{m.email} • {m.mobile}</p>
                </div>
                {!m.readFlag && <button onClick={() => markRead(m.id)} className="btn-secondary !py-1.5 !px-3 text-xs"><Check className="w-3.5 h-3.5" /> Mark read</button>}
              </div>
              {m.subject && <p className="text-sm font-medium text-ink/80 mt-3">{m.subject}</p>}
              <p className="text-sm text-ink/70 mt-1">{m.message}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
