import PageHero from '../components/PageHero'
import { Reveal, SectionTitle } from '../components/ui'
import { useSettings } from '../hooks/useSettings'
import { SEVA_PHOTOS, STOCK } from '../constants'
import { Target, Eye } from 'lucide-react'

const activities = ['Digital content', 'Creator networking', 'Temple cleanliness', 'Temple renovation/support activities', 'Cultural campaigns', 'Religious event participation', 'Volunteer activities', 'Community awareness', 'Social media campaigns']

export default function About() {
  const s = useSettings()
  return (
    <div>
      <PageHero overline="About Us" title="About Sanatani Influencers Group" hindi="हमारे बारे में" image={SEVA_PHOTOS[3]} />
      <section className="bg-cream section-pad">
        <div className="mx-auto max-w-4xl">
          <Reveal>
            <p className="text-lg text-ink/75 leading-relaxed">{s.aboutText}</p>
          </Reveal>
          <Reveal delay={0.1}>
            <h3 className="text-2xl font-bold text-maroon mt-12 mb-6">We work through</h3>
            <div className="grid sm:grid-cols-3 gap-3">
              {activities.map((a) => (
                <div key={a} className="card p-4 text-sm text-maroon flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-saffron" />{a}</div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>
      <section className="bg-cream-muted section-pad">
        <div className="mx-auto max-w-7xl grid lg:grid-cols-2 gap-8">
          <Reveal>
            <div className="bg-white rounded-3xl p-8 shadow-card border border-gold/20 h-full">
              <Target className="w-7 h-7 text-saffron mb-4" />
              <h3 className="text-2xl font-bold text-maroon mb-3">Our Mission</h3>
              <p className="text-ink/70">To promote Indian culture, connect creators with meaningful causes, encourage youth participation in seva and build a responsible creator community.</p>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <div className="bg-maroon rounded-3xl p-8 text-cream h-full relative overflow-hidden">
              <img src={STOCK.ganesha} alt="" className="absolute -right-6 -bottom-6 w-40 opacity-20" />
              <Eye className="w-7 h-7 text-gold mb-4 relative" />
              <h3 className="text-2xl font-bold mb-3 devanagari relative">हमारी दृष्टि</h3>
              <p className="text-cream/85 devanagari relative">{s.visionText}</p>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  )
}
