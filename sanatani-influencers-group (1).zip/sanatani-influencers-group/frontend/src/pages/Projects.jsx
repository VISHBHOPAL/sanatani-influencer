import { useEffect, useState } from 'react'
import api, { imgUrl } from '../lib/api'
import PageHero from '../components/PageHero'
import { Reveal, Spinner, EmptyState } from '../components/ui'
import { PROJECT_CATEGORIES, STOCK } from '../constants'
import { MapPin, Users, FolderOpen } from 'lucide-react'

export default function Projects() {
  const [projects, setProjects] = useState(null)
  const [filter, setFilter] = useState('All')
  useEffect(() => { api.get('/projects').then((r) => setProjects(r.data)).catch(() => setProjects([])) }, [])
  const shown = projects?.filter((p) => filter === 'All' || p.category === filter) || []

  return (
    <div>
      <PageHero overline="Our Work" title="Seva Projects & Initiatives" hindi="हमारा कार्य"
        subtitle="Temple seva, cleanliness drives, cultural events, social work and creator campaigns." image={STOCK.culture1} />
      <section className="bg-cream section-pad">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-wrap gap-2 mb-10">
            {['All', ...PROJECT_CATEGORIES].map((c) => (
              <button key={c} onClick={() => setFilter(c)} data-testid={`project-filter-${c}`}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${filter === c ? 'bg-saffron text-white' : 'bg-white text-ink/70 border border-maroon/10 hover:border-saffron'}`}>{c}</button>
            ))}
          </div>
          {projects === null ? <Spinner /> : shown.length === 0 ? (
            <EmptyState icon={FolderOpen} title="No projects found" message="Try a different category or check back soon." />
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {shown.map((p, i) => (
                <Reveal key={p.id} delay={i * 0.06}>
                  <div className="card hover:-translate-y-1 transition-transform" data-testid={`project-${p.id}`}>
                    <img src={p.afterImage ? imgUrl(p.afterImage) : (p.photos ? imgUrl(p.photos.split(',')[0]) : STOCK.seva)} alt={p.name} className="w-full h-44 object-cover" />
                    <div className="p-5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs bg-saffron/10 text-saffron px-2 py-0.5 rounded-full">{p.category}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${p.status === 'COMPLETED' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>{p.status}</span>
                      </div>
                      <h4 className="font-semibold text-maroon mt-2">{p.name}</h4>
                      <p className="text-sm text-ink/60 mt-1 line-clamp-2">{p.description}</p>
                      <div className="flex items-center gap-4 mt-3 text-xs text-ink/60">
                        <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{p.location}</span>
                        <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" />{p.volunteersCount}</span>
                      </div>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
