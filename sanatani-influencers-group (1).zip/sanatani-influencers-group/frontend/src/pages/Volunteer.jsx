import { useState } from 'react'
import api from '../lib/api'
import PageHero from '../components/PageHero'
import { useToast } from '../components/ui'
import { VOLUNTEER_CATEGORIES, SEVA_PHOTOS } from '../constants'
import { HandHeart, CheckCircle2 } from 'lucide-react'

export default function Volunteer() {
  const toast = useToast()
  const [done, setDone] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ name: '', mobile: '', email: '', city: '', age: '', skills: '', availability: '', interestedActivities: '', prevExperience: '', category: '' })
  const submit = async (e) => {
    e.preventDefault(); setSaving(true)
    try { await api.post('/volunteers/apply', { ...form, age: form.age ? parseInt(form.age) : null }); setDone(true); toast.success('Application submitted!') }
    catch { toast.error('Submission failed') } setSaving(false)
  }
  if (done) return (
    <div className="min-h-[60vh] flex items-center justify-center section-pad">
      <div className="card p-10 text-center max-w-md">
        <CheckCircle2 className="w-14 h-14 text-green-600 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-maroon">Thank you for volunteering!</h2>
        <p className="text-ink/60 mt-2">Your application has been received. Admin approval is required — we will contact you soon.</p>
      </div>
    </div>
  )
  return (
    <div>
      <PageHero overline="Volunteer" title="Become a Volunteer" hindi="स्वयंसेवक बनें"
        subtitle="Join our seva abhiyaan and contribute your time and skills to the community." image={SEVA_PHOTOS[3]} />
      <section className="bg-cream section-pad">
        <div className="mx-auto max-w-2xl card p-8">
          <form onSubmit={submit} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div><label className="label">Name *</label><input required className="input" data-testid="vol-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div><label className="label">Mobile *</label><input required className="input" data-testid="vol-mobile" value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} /></div>
              <div><label className="label">Email</label><input type="email" className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
              <div><label className="label">City</label><input className="input" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
              <div><label className="label">Age</label><input type="number" className="input" value={form.age} onChange={(e) => setForm({ ...form, age: e.target.value })} /></div>
              <div><label className="label">Category</label>
                <select className="input" data-testid="vol-category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                  <option value="">Select</option>{VOLUNTEER_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div><label className="label">Availability</label><input className="input" placeholder="Weekends, evenings…" value={form.availability} onChange={(e) => setForm({ ...form, availability: e.target.value })} /></div>
              <div><label className="label">Interested Activities</label><input className="input" value={form.interestedActivities} onChange={(e) => setForm({ ...form, interestedActivities: e.target.value })} /></div>
            </div>
            <div><label className="label">Skills</label><input className="input" value={form.skills} onChange={(e) => setForm({ ...form, skills: e.target.value })} /></div>
            <div><label className="label">Previous Experience</label><textarea rows="3" className="input" value={form.prevExperience} onChange={(e) => setForm({ ...form, prevExperience: e.target.value })} /></div>
            <button disabled={saving} className="btn-primary w-full" data-testid="vol-submit">{saving ? 'Submitting…' : <>Submit Application <HandHeart className="w-4 h-4" /></>}</button>
          </form>
        </div>
      </section>
    </div>
  )
}
