import { useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../lib/api'
import PageHero from '../components/PageHero'
import { useToast } from '../components/ui'
import { useSettings } from '../hooks/useSettings'
import { DONATION_CATEGORIES, STOCK } from '../constants'
import { Heart, IndianRupee, ShieldCheck, Info } from 'lucide-react'

const presets = [251, 501, 1100, 2100, 5100]

export default function Donate() {
  const s = useSettings()
  const toast = useToast()
  const [form, setForm] = useState({ name: '', mobile: '', email: '', city: '', amount: '', category: 'Temple Seva', purpose: '', anonymous: false })
  const [saving, setSaving] = useState(false)
  const [result, setResult] = useState(null)
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }))

  const submit = async (e) => {
    e.preventDefault()
    if (!form.amount || form.amount <= 0) return toast.error('Please enter a valid amount.')
    setSaving(true)
    try {
      const res = await api.post('/donations/create', { ...form, amount: parseFloat(form.amount) })
      setResult(res.data)
      if (res.data.paymentConfigured) {
        toast.info('Payment gateway ready — checkout would open here.')
        // When Razorpay keys are configured, initialize checkout using res.data.razorpayKeyId here.
      } else {
        toast.success('Donation intent recorded.')
      }
    } catch (err) { toast.error(err.response?.data?.message || 'Failed') }
    setSaving(false)
  }

  return (
    <div>
      <PageHero overline="Donation" title="Support Our Seva" hindi="हमारी सेवा में सहयोग करें"
        subtitle="Your contribution powers temple seva, cleanliness drives and community initiatives." image={STOCK.temple} />
      <section className="bg-cream section-pad">
        <div className="mx-auto max-w-5xl grid lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2 space-y-4">
            <div className="card p-6"><ShieldCheck className="w-7 h-7 text-saffron mb-2" /><h4 className="font-semibold text-maroon">100% Transparent</h4><p className="text-sm text-ink/60 mt-1">We publish verified donation reports. Private donor information is never shared.</p><Link to="/donation-report" className="text-saffron text-sm font-medium mt-2 inline-block">View Reports →</Link></div>
            <div className="card p-6"><Heart className="w-7 h-7 text-saffron mb-2" /><h4 className="font-semibold text-maroon">Where it goes</h4><ul className="text-sm text-ink/60 mt-2 space-y-1">{DONATION_CATEGORIES.map((c) => <li key={c} className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-gold" />{c}</li>)}</ul></div>
          </div>

          <div className="lg:col-span-3">
            {result ? (
              <div className="card p-8" data-testid="donation-result">
                {result.paymentConfigured ? (
                  <div className="text-center">
                    <IndianRupee className="w-12 h-12 text-saffron mx-auto mb-3" />
                    <h3 className="text-xl font-bold text-maroon">Proceed to Payment</h3>
                    <p className="text-ink/60 mt-2 text-sm">Donation ID: <b>{result.donation.donationId}</b></p>
                    <p className="text-ink/60 text-sm">Razorpay checkout will open for ₹{result.donation.amount}. Complete payment to receive your receipt.</p>
                  </div>
                ) : (
                  <div>
                    <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 rounded-xl p-4 text-amber-800 text-sm mb-4">
                      <Info className="w-5 h-5 shrink-0" /> Online payment gateway is not configured yet. Your donation intent has been recorded.
                    </div>
                    <h3 className="text-lg font-bold text-maroon">Donation Recorded</h3>
                    <p className="text-sm text-ink/60 mt-1">Reference ID: <b>{result.donation.donationId}</b> • ₹{result.donation.amount} • {result.donation.category}</p>
                    {s.upiId ? (
                      <div className="mt-4 bg-cream-muted rounded-xl p-4">
                        <p className="text-sm text-ink/70">You can complete your donation via UPI:</p>
                        <p className="font-bold text-maroon mt-1">{s.upiId}</p>
                      </div>
                    ) : (
                      <p className="text-sm text-ink/50 mt-4">Payment details will be shared by our team. Admin can enable Razorpay/UPI from Settings.</p>
                    )}
                    <button onClick={() => setResult(null)} className="btn-secondary mt-6">Make Another Donation</button>
                  </div>
                )}
              </div>
            ) : (
              <form onSubmit={submit} className="card p-8 space-y-4">
                <div>
                  <label className="label">Select Amount (₹)</label>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {presets.map((p) => (
                      <button type="button" key={p} onClick={() => set('amount', p)} data-testid={`donate-preset-${p}`}
                        className={`px-4 py-2 rounded-full text-sm font-medium border ${String(form.amount) === String(p) ? 'bg-saffron text-white border-saffron' : 'bg-white text-ink/70 border-maroon/10'}`}>₹{p}</button>
                    ))}
                  </div>
                  <input type="number" className="input" placeholder="Enter amount" data-testid="donate-amount" value={form.amount} onChange={(e) => set('amount', e.target.value)} />
                </div>
                <div><label className="label">Donation Purpose</label>
                  <select className="input" data-testid="donate-category" value={form.category} onChange={(e) => set('category', e.target.value)}>{DONATION_CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div><label className="label">Name *</label><input required className="input" data-testid="donate-name" value={form.name} onChange={(e) => set('name', e.target.value)} /></div>
                  <div><label className="label">Mobile *</label><input required className="input" value={form.mobile} onChange={(e) => set('mobile', e.target.value)} /></div>
                  <div><label className="label">Email</label><input type="email" className="input" value={form.email} onChange={(e) => set('email', e.target.value)} /></div>
                  <div><label className="label">City</label><input className="input" value={form.city} onChange={(e) => set('city', e.target.value)} /></div>
                </div>
                <label className="flex items-center gap-2 text-sm text-ink/70"><input type="checkbox" checked={form.anonymous} onChange={(e) => set('anonymous', e.target.checked)} /> Make this an anonymous donation</label>
                <button disabled={saving} className="btn-primary w-full" data-testid="donate-submit">{saving ? 'Processing…' : <>Donate ₹{form.amount || 0} <Heart className="w-4 h-4" /></>}</button>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  )
}
