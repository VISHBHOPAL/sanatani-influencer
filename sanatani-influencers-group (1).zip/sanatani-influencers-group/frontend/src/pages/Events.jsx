import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api, { imgUrl } from '../lib/api'
import PageHero from '../components/PageHero'
import { Reveal, Spinner, EmptyState } from '../components/ui'
import { STOCK } from '../constants'
import { Calendar, MapPin, CalendarX } from 'lucide-react'

const tabs = ['UPCOMING', 'ONGOING', 'PAST']

export default function Events() {
  const [events, setEvents] = useState(null)
  const [tab, setTab] = useState('UPCOMING')
  useEffect(() => { api.get('/events').then((r) => setEvents(r.data)).catch(() => setEvents([])) }, [])
  const shown = events?.filter((e) => e.status === tab) || []

  return (
    <div>
      <PageHero overline="Events" title="Community Events" hindi="कार्यक्रम"
        subtitle="Creator meets, cultural programs, workshops and religious events." image={STOCK.culture2} />
      <section className="bg-cream section-pad">
        <div className="mx-auto max-w-7xl">
          <div className="flex gap-2 mb-10">
            {tabs.map((t) => (
              <button key={t} onClick={() => setTab(t)} data-testid={`event-tab-${t}`}
                className={`px-5 py-2.5 rounded-full text-sm font-medium capitalize ${tab === t ? 'bg-maroon text-cream' : 'bg-white text-ink/70 border border-maroon/10'}`}>{t.toLowerCase()}</button>
            ))}
          </div>
          {events === null ? <Spinner /> : shown.length === 0 ? (
            <EmptyState icon={CalendarX} title={`No ${tab.toLowerCase()} events`} message="Please check back soon for updates." />
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {shown.map((e, i) => (
                <Reveal key={e.id} delay={i * 0.06}>
                  <Link to={`/events/${e.id}`} className="card block hover:-translate-y-1 transition-transform" data-testid={`event-card-${e.id}`}>
                    <div className="h-44 relative">
                      <img src={e.banner ? imgUrl(e.banner) : STOCK.culture1} alt={e.name} className="w-full h-full object-cover" />
                      <span className="absolute top-3 left-3 bg-saffron text-white text-xs px-3 py-1 rounded-full">{e.category}</span>
                    </div>
                    <div className="p-5">
                      <h4 className="font-semibold text-maroon">{e.name}</h4>
                      <div className="mt-3 space-y-1 text-sm text-ink/60">
                        <p className="flex items-center gap-2"><Calendar className="w-4 h-4 text-saffron" />{e.date} {e.time && `• ${e.time}`}</p>
                        <p className="flex items-center gap-2"><MapPin className="w-4 h-4 text-saffron" />{e.venue}</p>
                      </div>
                    </div>
                  </Link>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
