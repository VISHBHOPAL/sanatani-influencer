import { useEffect, useState } from 'react'
import api, { imgUrl } from '../lib/api'
import PageHero from '../components/PageHero'
import { Reveal, Spinner, EmptyState, Modal } from '../components/ui'
import { GALLERY_CATEGORIES, STOCK } from '../constants'
import { Image as ImageIcon } from 'lucide-react'

export default function Gallery() {
  const [items, setItems] = useState(null)
  const [filter, setFilter] = useState('All')
  const [lightbox, setLightbox] = useState(null)
  useEffect(() => { api.get('/gallery').then((r) => setItems(r.data)).catch(() => setItems([])) }, [])
  const shown = items?.filter((i) => filter === 'All' || i.category === filter) || []
  return (
    <div>
      <PageHero overline="Media" title="Gallery" hindi="गैलरी" subtitle="Moments from our events, temple seva and creator meets." image={STOCK.culture1} />
      <section className="bg-cream section-pad">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-wrap gap-2 mb-10">
            {['All', ...GALLERY_CATEGORIES].map((c) => (
              <button key={c} onClick={() => setFilter(c)} data-testid={`gallery-filter-${c}`}
                className={`px-4 py-2 rounded-full text-sm font-medium ${filter === c ? 'bg-saffron text-white' : 'bg-white text-ink/70 border border-maroon/10 hover:border-saffron'}`}>{c}</button>
            ))}
          </div>
          {items === null ? <Spinner /> : shown.length === 0 ? (
            <EmptyState icon={ImageIcon} title="No media yet" message="Photos will be added soon." />
          ) : (
            <div className="columns-2 md:columns-3 lg:columns-4 gap-4 space-y-4">
              {shown.map((g, i) => (
                <Reveal key={g.id} delay={(i % 8) * 0.04}>
                  <button onClick={() => setLightbox(g)} className="block w-full rounded-2xl overflow-hidden group" data-testid={`gallery-item-${g.id}`}>
                    <img src={imgUrl(g.imageUrl)} alt={g.title} className="w-full group-hover:scale-105 transition-transform duration-500" />
                  </button>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>
      <Modal open={!!lightbox} onClose={() => setLightbox(null)} testid="gallery-lightbox">
        {lightbox && (
          <div>
            <img src={imgUrl(lightbox.imageUrl)} alt={lightbox.title} className="w-full rounded-xl" />
            <h4 className="font-semibold text-maroon mt-4">{lightbox.title}</h4>
            <p className="text-sm text-ink/60">{lightbox.caption}</p>
            <p className="text-xs text-ink/40 mt-1">{lightbox.location} {lightbox.date && `• ${lightbox.date}`}</p>
          </div>
        )}
      </Modal>
    </div>
  )
}
