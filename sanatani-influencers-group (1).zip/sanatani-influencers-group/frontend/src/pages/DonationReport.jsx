import { useEffect, useState } from 'react'
import api from '../lib/api'
import PageHero from '../components/PageHero'
import { Spinner } from '../components/ui'
import { STOCK } from '../constants'
import { IndianRupee, TrendingUp, PieChart } from 'lucide-react'

export default function DonationReport() {
  const [report, setReport] = useState(null)
  useEffect(() => { api.get('/donations/report').then((r) => setReport(r.data)).catch(() => setReport({ totalFundsReceived: 0, successfulDonations: 0, byCategory: {} })) }, [])
  return (
    <div>
      <PageHero overline="Transparency" title="Donation Reports" hindi="दान रिपोर्ट"
        subtitle="We believe in full transparency. Private donor information is never shared." image={STOCK.temple} />
      <section className="bg-cream section-pad">
        <div className="mx-auto max-w-4xl">
          {!report ? <Spinner /> : (
            <>
              <div className="grid sm:grid-cols-2 gap-6 mb-10">
                <div className="card p-8"><IndianRupee className="w-8 h-8 text-saffron mb-3" /><p className="text-3xl font-bold text-maroon font-display">₹{Number(report.totalFundsReceived).toLocaleString('en-IN')}</p><p className="text-ink/60 text-sm mt-1">Total Verified Funds Received</p></div>
                <div className="card p-8"><TrendingUp className="w-8 h-8 text-saffron mb-3" /><p className="text-3xl font-bold text-maroon font-display">{report.successfulDonations}</p><p className="text-ink/60 text-sm mt-1">Successful Donations</p></div>
              </div>
              <div className="card p-8">
                <h3 className="flex items-center gap-2 text-xl font-bold text-maroon mb-5"><PieChart className="w-5 h-5 text-saffron" /> Contribution by Category</h3>
                {Object.keys(report.byCategory || {}).length === 0 ? (
                  <p className="text-ink/50">Verified reports will be published here as donations are received.</p>
                ) : (
                  <div className="space-y-3">
                    {Object.entries(report.byCategory).map(([cat, amt]) => {
                      const pct = report.totalFundsReceived ? (amt / report.totalFundsReceived) * 100 : 0
                      return (
                        <div key={cat}>
                          <div className="flex justify-between text-sm mb-1"><span className="text-maroon">{cat}</span><span className="text-ink/60">₹{Number(amt).toLocaleString('en-IN')}</span></div>
                          <div className="h-2 bg-cream-muted rounded-full overflow-hidden"><div className="h-full bg-saffron rounded-full" style={{ width: `${pct}%` }} /></div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </section>
    </div>
  )
}
