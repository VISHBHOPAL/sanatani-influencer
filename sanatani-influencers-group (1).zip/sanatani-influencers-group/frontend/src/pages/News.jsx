import { useEffect, useState } from 'react'
import api, { imgUrl } from '../lib/api'
import PageHero from '../components/PageHero'
import { Reveal, Spinner, EmptyState, Modal } from '../components/ui'
import { STOCK } from '../constants'
import { Newspaper, Calendar, User } from 'lucide-react'

export default function News() {
  const [news, setNews] = useState(null)
  const [active, setActive] = useState(null)
  useEffect(() => { api.get('/news').then((r) => setNews(r.data)).catch(() => setNews([])) }, [])
  return (
    <div>
      <PageHero overline="News & Updates" title="Sanatani Stories" hindi="समाचार एवं अपडेट" image={STOCK.culture2} />
      <section className="bg-cream section-pad">
        <div className="mx-auto max-w-7xl">
          {news === null ? <Spinner /> : news.length === 0 ? (
            <EmptyState icon={Newspaper} title="No articles yet" message="Announcements and stories will be published here." />
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {news.map((n, i) => (
                <Reveal key={n.id} delay={(i % 6) * 0.06}>
                  <button onClick={() => setActive(n)} className="card text-left block hover:-translate-y-1 transition-transform" data-testid={`news-${n.id}`}>
                    <img src={n.featuredImage ? imgUrl(n.featuredImage) : STOCK.culture1} alt={n.title} className="w-full h-44 object-cover" />
                    <div className="p-5">
                      <span className="text-xs bg-saffron/10 text-saffron px-2 py-0.5 rounded-full">{n.category}</span>
                      <h4 className="font-semibold text-maroon mt-2 line-clamp-2">{n.title}</h4>
                      <div className="flex items-center gap-3 mt-3 text-xs text-ink/50">
                        <span className="flex items-center gap-1"><User className="w-3 h-3" />{n.author}</span>
                        <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{n.date}</span>
                      </div>
                    </div>
                  </button>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>
      <Modal open={!!active} onClose={() => setActive(null)} title={active?.title} testid="news-modal">
        {active && (
          <div>
            {active.featuredImage && <img src={imgUrl(active.featuredImage)} alt="" className="w-full rounded-xl mb-4" />}
            <div className="flex items-center gap-3 text-xs text-ink/50 mb-3"><span>{active.author}</span><span>{active.date}</span><span className="text-saffron">{active.category}</span></div>
            <p className="text-ink/75 whitespace-pre-line leading-relaxed">{active.content}</p>
          </div>
        )}
      </Modal>
    </div>
  )
}
