import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../components/ui'
import { LOGO } from '../constants'
import { LogIn } from 'lucide-react'

export default function Login() {
  const { login } = useAuth()
  const toast = useToast()
  const navigate = useNavigate()
  const [form, setForm] = useState({ email: '', password: '' })
  const [saving, setSaving] = useState(false)

  const submit = async (e) => {
    e.preventDefault(); setSaving(true)
    try {
      const u = await login(form.email, form.password)
      toast.success('Welcome back!')
      navigate(['ADMIN', 'SUPER_ADMIN', 'EVENT_MANAGER', 'CONTENT_MANAGER'].includes(u.role) ? '/admin' : '/portal')
    } catch (err) { toast.error(err.response?.data?.message || 'Invalid credentials') }
    setSaving(false)
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-cream section-pad">
      <div className="card p-8 w-full max-w-md">
        <div className="text-center mb-6">
          <img src={LOGO} alt="logo" className="w-16 h-16 rounded-full mx-auto ring-2 ring-gold/40" />
          <h1 className="text-2xl font-bold text-maroon mt-4">Member & Admin Login</h1>
          <p className="text-sm text-ink/50 mt-1">Sanatani Influencers Group</p>
        </div>
        <form onSubmit={submit} className="space-y-4">
          <div><label className="label">Email</label><input required type="email" className="input" data-testid="login-email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
          <div><label className="label">Password</label><input required type="password" className="input" data-testid="login-password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
          <div className="text-right"><Link to="/forgot-password" className="text-sm text-saffron hover:underline">Forgot password?</Link></div>
          <button disabled={saving} className="btn-primary w-full" data-testid="login-submit">{saving ? 'Signing in…' : <>Login <LogIn className="w-4 h-4" /></>}</button>
        </form>
        <p className="text-center text-sm text-ink/50 mt-6">Not a member yet? <Link to="/join" className="text-saffron font-medium">Join the Group</Link></p>
      </div>
    </div>
  )
}
