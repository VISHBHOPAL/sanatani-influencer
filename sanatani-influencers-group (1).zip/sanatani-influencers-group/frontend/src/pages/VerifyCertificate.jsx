import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import api from '../lib/api'
import PageHero from '../components/PageHero'
import { useToast } from '../components/ui'
import { STOCK } from '../constants'
import { ShieldCheck, ShieldX, Search } from 'lucide-react'

export default function VerifyCertificate() {
  const { number } = useParams()
  const toast = useToast()
  const [num, setNum] = useState(number || '')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)

  const verify = async (val) => {
    const n = (val ?? num).trim()
    if (!n) return
    setLoading(true)
    try { const res = await api.get(`/certificates/verify/${encodeURIComponent(n)}`); setResult(res.data) }
    catch { toast.error('Verification failed') } setLoading(false)
  }
  useEffect(() => { if (number) verify(number) }, [number])

  return (
    <div>
      <PageHero overline="Verification" title="Verify Certificate" hindi="प्रमाणपत्र सत्यापन" image={STOCK.temple} />
      <section className="bg-cream section-pad">
        <div className="mx-auto max-w-xl">
          <div className="card p-8">
            <label className="label">Certificate Number</label>
            <div className="flex gap-2">
              <input className="input" placeholder="SIG-CERT-2026-0001" data-testid="verify-input" value={num} onChange={(e) => setNum(e.target.value)} />
              <button onClick={() => verify()} disabled={loading} className="btn-primary shrink-0" data-testid="verify-btn"><Search className="w-4 h-4" /></button>
            </div>
            {result && (
              <div className={`mt-6 rounded-2xl p-6 border ${result.valid ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`} data-testid="verify-result">
                {result.valid ? (
                  <>
                    <div className="flex items-center gap-2 text-green-700 font-semibold mb-4"><ShieldCheck className="w-6 h-6" /> Valid Certificate</div>
                    <dl className="space-y-2 text-sm">
                      {[['Number', result.certificateNumber], ['Recipient', result.recipient], ['Type', result.type], ['Event/Project', result.eventProject], ['Issue Date', result.issueDate], ['Issued By', result.issuedBy], ['Status', result.status]].map(([k, v]) => v && (
                        <div key={k} className="flex justify-between border-b border-green-100 pb-1"><dt className="text-ink/60">{k}</dt><dd className="text-maroon font-medium">{v}</dd></div>
                      ))}
                    </dl>
                  </>
                ) : (
                  <div className="flex items-center gap-2 text-red-700 font-semibold"><ShieldX className="w-6 h-6" /> {result.message || 'Certificate not found or revoked.'}</div>
                )}
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  )
}
