import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api, { imgUrl, ASSET_BASE } from '../lib/api'
import { useAuth } from '../context/AuthContext'
import { useToast, Spinner } from '../components/ui'
import { LOGO, STOCK } from '../constants'
import { Download, Save, User, QrCode, Award, Calendar, MapPin } from 'lucide-react'

export default function MemberPortal() {
  const { user } = useAuth()
  const toast = useToast()
  const [member, setMember] = useState(null)
  const [edit, setEdit] = useState({ bio: '', skills: '', instagram: '', youtube: '', publicProfile: true })
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!user?.memberId) { setMember(false); return }
    api.get(`/members/${user.memberId}`).then((r) => {
      setMember(r.data)
      setEdit({ bio: r.data.bio || '', skills: r.data.skills || '', instagram: r.data.instagram || '', youtube: r.data.youtube || '', publicProfile: r.data.publicProfile ?? true })
    }).catch(() => setMember(false))
  }, [user])

  const save = async () => {
    setSaving(true)
    try { const r = await api.put(`/members/${user.memberId}`, edit); setMember(r.data.data); toast.success('Profile updated') }
    catch { toast.error('Update failed') } setSaving(false)
  }

  if (member === null) return <div className="section-pad"><Spinner label="Loading profile…" /></div>
  if (member === false) return (
    <div className="section-pad text-center bg-cream min-h-[60vh] flex flex-col items-center justify-center">
      <User className="w-14 h-14 text-maroon/30 mb-4" />
      <h2 className="text-2xl font-bold text-maroon">No approved membership linked</h2>
      <p className="text-ink/60 mt-2 max-w-md">Your account is not yet linked to an approved member profile. Apply for membership or wait for admin approval.</p>
      <Link to="/join" className="btn-primary mt-6">Apply for Membership</Link>
    </div>
  )

  const qr = `https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=${encodeURIComponent(`${ASSET_BASE.replace(/\/$/, '')}/api/members/public/${member.id}`)}`
  const approved = member.status === 'APPROVED'

  return (
    <div className="bg-cream section-pad min-h-[80vh]">
      <div className="mx-auto max-w-5xl">
        <h1 className="text-3xl font-bold text-maroon mb-2">My Portal</h1>
        <p className="text-ink/60 mb-8">Manage your profile and membership card.</p>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Membership Card */}
          <div>
            <h3 className="font-semibold text-maroon mb-3">Digital Membership Card</h3>
            {approved ? (
              <div id="member-card" className="rounded-2xl overflow-hidden shadow-lift bg-gradient-to-br from-maroon to-maroon-dark text-cream p-6 relative">
                <img src={STOCK.ganesha} alt="" className="absolute right-2 bottom-2 w-24 opacity-10" />
                <div className="flex items-center gap-3 mb-5 relative">
                  <img src={LOGO} alt="logo" className="w-12 h-12 rounded-full ring-2 ring-gold/50" />
                  <div><p className="font-display font-bold">Sanatani Influencers Group</p><p className="text-[10px] tracking-widest uppercase text-gold">Membership Card</p></div>
                </div>
                <div className="flex gap-4 relative">
                  <div className="w-24 h-24 rounded-xl bg-white/10 overflow-hidden shrink-0">
                    <img src={member.profilePhoto ? imgUrl(member.profilePhoto) : STOCK.creator1} alt="" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 text-sm">
                    <p className="text-lg font-bold">{member.fullName}</p>
                    <p className="text-gold">{member.memberId}</p>
                    <p className="text-cream/80 text-xs mt-1">{member.creatorCategory}</p>
                    <p className="text-cream/70 text-xs flex items-center gap-1"><MapPin className="w-3 h-3" />{member.city}</p>
                    <p className="text-cream/60 text-xs mt-1">Joined {member.joinedDate}</p>
                  </div>
                  <img src={qr} alt="QR" className="w-16 h-16 rounded bg-white p-1 self-start" />
                </div>
              </div>
            ) : (
              <div className="card p-8 text-center"><p className="text-amber-600 font-semibold">Status: {member.status}</p><p className="text-ink/60 text-sm mt-2">Your membership card will be available once approved.</p></div>
            )}
            {approved && <button onClick={() => window.print()} className="btn-secondary mt-4" data-testid="download-card-btn"><Download className="w-4 h-4" /> Download / Print Card</button>}
          </div>

          {/* Editable profile */}
          <div className="card p-6">
            <h3 className="font-semibold text-maroon mb-4">Edit Profile</h3>
            <div className="space-y-4">
              <div><label className="label">Bio</label><textarea rows="3" className="input" data-testid="portal-bio" value={edit.bio} onChange={(e) => setEdit({ ...edit, bio: e.target.value })} /></div>
              <div><label className="label">Skills</label><input className="input" value={edit.skills} onChange={(e) => setEdit({ ...edit, skills: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="label">Instagram</label><input className="input" value={edit.instagram} onChange={(e) => setEdit({ ...edit, instagram: e.target.value })} /></div>
                <div><label className="label">YouTube</label><input className="input" value={edit.youtube} onChange={(e) => setEdit({ ...edit, youtube: e.target.value })} /></div>
              </div>
              <label className="flex items-center gap-2 text-sm text-ink/70"><input type="checkbox" checked={edit.publicProfile} onChange={(e) => setEdit({ ...edit, publicProfile: e.target.checked })} /> Show my profile publicly</label>
              <button onClick={save} disabled={saving} className="btn-primary w-full" data-testid="portal-save"><Save className="w-4 h-4" /> {saving ? 'Saving…' : 'Save Changes'}</button>
            </div>
          </div>
        </div>

        <div className="grid sm:grid-cols-3 gap-4 mt-8">
          {[[Award, 'Achievements', member.achievements || '—'], [Calendar, 'Joined', member.joinedDate || '—'], [QrCode, 'Member ID', member.memberId || 'Pending']].map(([Icon, label, val]) => (
            <div key={label} className="card p-5"><Icon className="w-6 h-6 text-saffron mb-2" /><p className="text-xs text-ink/50">{label}</p><p className="text-maroon font-medium text-sm">{val}</p></div>
          ))}
        </div>
      </div>
    </div>
  )
}
