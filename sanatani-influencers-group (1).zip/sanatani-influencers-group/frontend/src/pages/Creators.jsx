import { useEffect, useMemo, useState } from 'react'
import api, { imgUrl } from '../lib/api'
import PageHero from '../components/PageHero'
import { Reveal, Spinner, EmptyState } from '../components/ui'
import { CREATOR_CATEGORIES, STOCK } from '../constants'
import { Instagram, Youtube, Search, MapPin, Users2 } from 'lucide-react'

export default function Creators() {
  const [creators, setCreators] = useState(null)
  const [q, setQ] = useState('')
  const [cat, setCat] = useState('All')
  const [city, setCity] = useState('All')
  useEffect(() => { api.get('/members/public').then((r) => setCreators(r.data)).catch(() => setCreators([])) }, [])

  const cities = useMemo(() => ['All', ...new Set((creators || []).map((c) => c.city).filter(Boolean))], [creators])
  const shown = (creators || []).filter((c) =>
    (cat === 'All' || c.creatorCategory === cat) &&
    (city === 'All' || c.city === city) &&
    (!q || c.fullName?.toLowerCase().includes(q.toLowerCase()))
  )

  return (
    <div>
      <PageHero overline="Community" title="Sanatani Creator Directory" hindi="क्रिएटर डायरेक्टरी"
        subtitle="Discover creators by name, city, category and platform." image={STOCK.creator2} />
      <section className="bg-cream section-pad">
        <div className="mx-auto max-w-7xl">
          <div className="card p-4 mb-8 grid md:grid-cols-3 gap-3">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-ink/40" />
              <input className="input !pl-9" placeholder="Search by name…" data-testid="creator-search" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
            <select className="input" data-testid="creator-cat" value={cat} onChange={(e) => setCat(e.target.value)}><option>All</option>{CREATOR_CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
            <select className="input" data-testid="creator-city" value={city} onChange={(e) => setCity(e.target.value)}>{cities.map((c) => <option key={c}>{c}</option>)}</select>
          </div>
          {creators === null ? <Spinner /> : shown.length === 0 ? (
            <EmptyState icon={Users2} title="No creators found" message="Try adjusting your filters." />
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {shown.map((c, i) => (
                <Reveal key={c.id} delay={(i % 8) * 0.05}>
                  <div className="card p-6 text-center hover:-translate-y-1 transition-transform" data-testid={`creator-${c.id}`}>
                    <div className="w-20 h-20 mx-auto rounded-full overflow-hidden ring-2 ring-gold/30 bg-saffron/10">
                      <img src={c.profilePhoto ? imgUrl(c.profilePhoto) : STOCK.creator1} alt={c.fullName} className="w-full h-full object-cover" />
                    </div>
                    <h4 className="font-semibold text-maroon mt-3 text-sm">{c.fullName}</h4>
                    <p className="text-xs text-saffron">{c.creatorCategory}</p>
                    <p className="text-xs text-ink/50 flex items-center justify-center gap-1 mt-1"><MapPin className="w-3 h-3" />{c.city}</p>
                    {c.instagramFollowers > 0 && <p className="text-xs text-ink/60 mt-2">{Number(c.instagramFollowers).toLocaleString('en-IN')} followers</p>}
                    <div className="flex justify-center gap-2 mt-2">
                      {c.instagram && <span className="text-ink/40"><Instagram className="w-4 h-4" /></span>}
                      {c.youtube && <span className="text-ink/40"><Youtube className="w-4 h-4" /></span>}
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
