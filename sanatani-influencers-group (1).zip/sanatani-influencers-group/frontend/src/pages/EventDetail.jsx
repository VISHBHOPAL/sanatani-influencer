import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import api, { imgUrl } from '../lib/api'
import { Spinner, useToast, Modal } from '../components/ui'
import { STOCK, CREATOR_CATEGORIES } from '../constants'
import { Calendar, MapPin, Clock, User, Users, ArrowLeft, CheckCircle2 } from 'lucide-react'

export default function EventDetail() {
  const { id } = useParams()
  const toast = useToast()
  const [data, setData] = useState(null)
  const [open, setOpen] = useState(false)
  const [done, setDone] = useState(null)
  const [form, setForm] = useState({ fullName: '', mobile: '', email: '', city: '', age: '', instagram: '', youtube: '', creatorCategory: '', followers: '', interestedIn: '', volunteerExperience: '', agreedTerms: false })
  const [saving, setSaving] = useState(false)

  useEffect(() => { api.get(`/events/${id}`).then((r) => setData(r.data)).catch(() => setData(false)) }, [id])

  const submit = async (e) => {
    e.preventDefault()
    if (!form.agreedTerms) return toast.error('Please agree to the terms and conditions.')
    setSaving(true)
    try {
      const res = await api.post(`/events/${id}/register`, { ...form, age: form.age ? parseInt(form.age) : null })
      setDone(res.data.data.registrationId)
      setOpen(false)
      toast.success('Registration successful!')
    } catch (err) { toast.error(err.response?.data?.message || 'Registration failed') }
    setSaving(false)
  }

  if (data === null) return <Spinner label="Loading event…" />
  if (!data) return <div className="section-pad text-center"><p>Event not found.</p><Link to="/events" className="btn-secondary mt-4">Back to Events</Link></div>
  const e = data.event

  return (
    <div className="bg-cream">
      <div className="relative h-72 sm:h-96 bg-charcoal">
        <img src={e.banner ? imgUrl(e.banner) : STOCK.culture1} alt={e.name} className="w-full h-full object-cover opacity-60" />
        <div className="absolute inset-0 bg-gradient-to-t from-charcoal to-transparent" />
        <div className="absolute bottom-0 inset-x-0 mx-auto max-w-5xl px-5 lg:px-8 pb-8">
          <Link to="/events" className="inline-flex items-center gap-1 text-cream/70 hover:text-gold text-sm mb-3"><ArrowLeft className="w-4 h-4" /> All Events</Link>
          <span className="block text-gold text-sm mb-1">{e.category}</span>
          <h1 className="text-3xl sm:text-4xl font-bold text-cream">{e.name}</h1>
        </div>
      </div>

      <section className="section-pad">
        <div className="mx-auto max-w-5xl grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <h3 className="text-xl font-bold text-maroon mb-3">About this event</h3>
            <p className="text-ink/70 leading-relaxed whitespace-pre-line">{e.description || 'Details will be updated soon.'}</p>
            {e.mapsLocation && (
              <a href={e.mapsLocation} target="_blank" rel="noreferrer" className="btn-secondary mt-6"><MapPin className="w-4 h-4" /> View on Google Maps</a>
            )}
          </div>
          <div className="card p-6 h-fit sticky top-24">
            <div className="space-y-3 text-sm">
              <p className="flex items-center gap-2 text-ink/70"><Calendar className="w-4 h-4 text-saffron" />{e.date}</p>
              {e.time && <p className="flex items-center gap-2 text-ink/70"><Clock className="w-4 h-4 text-saffron" />{e.time}</p>}
              <p className="flex items-center gap-2 text-ink/70"><MapPin className="w-4 h-4 text-saffron" />{e.venue}</p>
              {e.organizer && <p className="flex items-center gap-2 text-ink/70"><User className="w-4 h-4 text-saffron" />{e.organizer}</p>}
              <p className="flex items-center gap-2 text-ink/70"><Users className="w-4 h-4 text-saffron" />{data.registrations}{e.maxParticipants ? ` / ${e.maxParticipants}` : ''} registered</p>
            </div>
            {done ? (
              <div className="mt-6 bg-green-50 border border-green-200 rounded-xl p-4 text-center">
                <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <p className="text-sm text-green-800">Registered! Your ID:</p>
                <p className="font-bold text-green-900">{done}</p>
              </div>
            ) : e.registrationRequired ? (
              <button onClick={() => setOpen(true)} className="btn-primary w-full mt-6" data-testid="event-register-btn">Register Now</button>
            ) : (
              <p className="mt-6 text-sm text-ink/50 text-center">No registration required.</p>
            )}
          </div>
        </div>
      </section>

      <Modal open={open} onClose={() => setOpen(false)} title="Event Registration" testid="event-register-modal">
        <form onSubmit={submit} className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div><label className="label">Full Name *</label><input required className="input" data-testid="reg-name" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></div>
            <div><label className="label">Mobile *</label><input required className="input" data-testid="reg-mobile" value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} /></div>
            <div><label className="label">Email</label><input type="email" className="input" data-testid="reg-email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div><label className="label">City</label><input className="input" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
            <div><label className="label">Age</label><input type="number" className="input" value={form.age} onChange={(e) => setForm({ ...form, age: e.target.value })} /></div>
            <div><label className="label">Instagram</label><input className="input" value={form.instagram} onChange={(e) => setForm({ ...form, instagram: e.target.value })} /></div>
            <div><label className="label">YouTube</label><input className="input" value={form.youtube} onChange={(e) => setForm({ ...form, youtube: e.target.value })} /></div>
            <div><label className="label">Creator Category</label>
              <select className="input" value={form.creatorCategory} onChange={(e) => setForm({ ...form, creatorCategory: e.target.value })}>
                <option value="">Select</option>{CREATOR_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div><label className="label">Followers</label><input className="input" value={form.followers} onChange={(e) => setForm({ ...form, followers: e.target.value })} /></div>
            <div><label className="label">Interested In</label><input className="input" value={form.interestedIn} onChange={(e) => setForm({ ...form, interestedIn: e.target.value })} /></div>
          </div>
          <div><label className="label">Volunteer Experience</label><textarea className="input" rows="2" value={form.volunteerExperience} onChange={(e) => setForm({ ...form, volunteerExperience: e.target.value })} /></div>
          <label className="flex items-start gap-2 text-sm text-ink/70"><input type="checkbox" className="mt-1" data-testid="reg-terms" checked={form.agreedTerms} onChange={(e) => setForm({ ...form, agreedTerms: e.target.checked })} /> I agree to the terms and conditions.</label>
          <button disabled={saving} className="btn-primary w-full" data-testid="reg-submit">{saving ? 'Submitting…' : 'Submit Registration'}</button>
        </form>
      </Modal>
    </div>
  )
}
