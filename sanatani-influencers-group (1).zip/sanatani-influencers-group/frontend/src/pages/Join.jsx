import { useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../lib/api'
import PageHero from '../components/PageHero'
import { useToast } from '../components/ui'
import { CREATOR_CATEGORIES, INDIAN_STATES, SEVA_PHOTOS } from '../constants'
import { CheckCircle2, Upload, UserPlus } from 'lucide-react'

const empty = {
  fullName: '', mobile: '', whatsapp: '', email: '', dob: '', gender: '', city: '', state: 'Madhya Pradesh',
  instagram: '', instagramUrl: '', instagramFollowers: '', youtube: '', youtubeSubscribers: '', facebook: '',
  creatorCategory: '', contentCategory: '', languages: '', profession: '', skills: '',
  whyJoin: '', howContribute: '', prevExperience: '',
  interestedVolunteering: false, interestedEvents: false, interestedTempleSeva: false,
  profilePhoto: '', idProof: '', publicProfile: true, consent: false,
}

export default function Join() {
  const toast = useToast()
  const [form, setForm] = useState(empty)
  const [saving, setSaving] = useState(false)
  const [done, setDone] = useState(false)
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }))

  const upload = async (file, key) => {
    if (!file) return
    const fd = new FormData(); fd.append('file', file)
    try { const res = await api.post('/upload', fd, { headers: { 'Content-Type': 'multipart/form-data' } }); set(key, res.data.data.url); toast.success('Uploaded') }
    catch (e) { toast.error(e.response?.data?.message || 'Upload failed') }
  }

  const submit = async (e) => {
    e.preventDefault()
    if (!form.consent) return toast.error('Please provide consent to continue.')
    setSaving(true)
    try {
      await api.post('/members/apply', {
        ...form,
        instagramFollowers: form.instagramFollowers ? parseInt(form.instagramFollowers) : null,
        youtubeSubscribers: form.youtubeSubscribers ? parseInt(form.youtubeSubscribers) : null,
      })
      setDone(true); toast.success('Application submitted!')
    } catch (err) { toast.error(err.response?.data?.message || 'Submission failed') }
    setSaving(false)
  }

  if (done) return (
    <div className="min-h-[70vh] flex items-center justify-center section-pad bg-cream">
      <div className="card p-10 text-center max-w-md">
        <CheckCircle2 className="w-16 h-16 text-green-600 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-maroon">Application Submitted!</h2>
        <p className="text-ink/60 mt-3">Your membership status is <b className="text-amber-600">PENDING</b>. Our admin team will review your application. Once approved, you'll receive your Member ID and digital membership card.</p>
        <Link to="/" className="btn-primary mt-6">Back to Home</Link>
      </div>
    </div>
  )

  return (
    <div>
      <PageHero overline="Membership" title="Join Our Community" hindi="हमारे समुदाय से जुड़ें"
        subtitle="Become part of a responsible creator community rooted in Sanatan values." image={SEVA_PHOTOS[1]} />
      <section className="bg-cream section-pad">
        <form onSubmit={submit} className="mx-auto max-w-3xl card p-8 space-y-8">
          <div>
            <h3 className="text-lg font-bold text-maroon mb-4">Personal Details</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <div><label className="label">Full Name *</label><input required className="input" data-testid="join-name" value={form.fullName} onChange={(e) => set('fullName', e.target.value)} /></div>
              <div><label className="label">Mobile Number *</label><input required className="input" data-testid="join-mobile" value={form.mobile} onChange={(e) => set('mobile', e.target.value)} /></div>
              <div><label className="label">WhatsApp Number</label><input className="input" value={form.whatsapp} onChange={(e) => set('whatsapp', e.target.value)} /></div>
              <div><label className="label">Email *</label><input required type="email" className="input" data-testid="join-email" value={form.email} onChange={(e) => set('email', e.target.value)} /></div>
              <div><label className="label">Date of Birth</label><input type="date" className="input" value={form.dob} onChange={(e) => set('dob', e.target.value)} /></div>
              <div><label className="label">Gender</label><select className="input" value={form.gender} onChange={(e) => set('gender', e.target.value)}><option value="">Select</option><option>Male</option><option>Female</option><option>Other</option></select></div>
              <div><label className="label">City *</label><input required className="input" value={form.city} onChange={(e) => set('city', e.target.value)} /></div>
              <div><label className="label">State</label><select className="input" value={form.state} onChange={(e) => set('state', e.target.value)}>{INDIAN_STATES.map((s) => <option key={s}>{s}</option>)}</select></div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold text-maroon mb-4">Creator Details</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <div><label className="label">Instagram Username</label><input className="input" value={form.instagram} onChange={(e) => set('instagram', e.target.value)} /></div>
              <div><label className="label">Instagram Profile URL</label><input className="input" value={form.instagramUrl} onChange={(e) => set('instagramUrl', e.target.value)} /></div>
              <div><label className="label">Instagram Followers</label><input type="number" className="input" value={form.instagramFollowers} onChange={(e) => set('instagramFollowers', e.target.value)} /></div>
              <div><label className="label">YouTube Channel</label><input className="input" value={form.youtube} onChange={(e) => set('youtube', e.target.value)} /></div>
              <div><label className="label">YouTube Subscribers</label><input type="number" className="input" value={form.youtubeSubscribers} onChange={(e) => set('youtubeSubscribers', e.target.value)} /></div>
              <div><label className="label">Facebook Profile</label><input className="input" value={form.facebook} onChange={(e) => set('facebook', e.target.value)} /></div>
              <div><label className="label">Creator Category</label><select className="input" data-testid="join-category" value={form.creatorCategory} onChange={(e) => set('creatorCategory', e.target.value)}><option value="">Select</option>{CREATOR_CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
              <div><label className="label">Content Category</label><input className="input" value={form.contentCategory} onChange={(e) => set('contentCategory', e.target.value)} /></div>
              <div><label className="label">Languages</label><input className="input" value={form.languages} onChange={(e) => set('languages', e.target.value)} /></div>
              <div><label className="label">Profession</label><input className="input" value={form.profession} onChange={(e) => set('profession', e.target.value)} /></div>
            </div>
            <div className="mt-4"><label className="label">Skills</label><input className="input" value={form.skills} onChange={(e) => set('skills', e.target.value)} /></div>
          </div>

          <div>
            <h3 className="text-lg font-bold text-maroon mb-4">Your Motivation</h3>
            <div className="space-y-4">
              <div><label className="label">Why do you want to join?</label><textarea rows="2" className="input" value={form.whyJoin} onChange={(e) => set('whyJoin', e.target.value)} /></div>
              <div><label className="label">How can you contribute?</label><textarea rows="2" className="input" value={form.howContribute} onChange={(e) => set('howContribute', e.target.value)} /></div>
              <div><label className="label">Previous social work experience</label><textarea rows="2" className="input" value={form.prevExperience} onChange={(e) => set('prevExperience', e.target.value)} /></div>
            </div>
            <div className="flex flex-wrap gap-4 mt-4 text-sm text-ink/70">
              <label className="flex items-center gap-2"><input type="checkbox" checked={form.interestedVolunteering} onChange={(e) => set('interestedVolunteering', e.target.checked)} /> Interested in volunteering</label>
              <label className="flex items-center gap-2"><input type="checkbox" checked={form.interestedEvents} onChange={(e) => set('interestedEvents', e.target.checked)} /> Interested in events</label>
              <label className="flex items-center gap-2"><input type="checkbox" checked={form.interestedTempleSeva} onChange={(e) => set('interestedTempleSeva', e.target.checked)} /> Interested in temple seva</label>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold text-maroon mb-4">Documents</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="label">Profile Photo</label>
                <label className="flex items-center gap-2 input cursor-pointer text-ink/60"><Upload className="w-4 h-4" /> {form.profilePhoto ? 'Uploaded ✓' : 'Choose image'}<input type="file" accept="image/*" className="hidden" onChange={(e) => upload(e.target.files[0], 'profilePhoto')} /></label>
              </div>
              <div>
                <label className="label">ID Proof (kept private)</label>
                <label className="flex items-center gap-2 input cursor-pointer text-ink/60"><Upload className="w-4 h-4" /> {form.idProof ? 'Uploaded ✓' : 'Choose file'}<input type="file" accept="image/*,application/pdf" className="hidden" onChange={(e) => upload(e.target.files[0], 'idProof')} /></label>
                <p className="text-xs text-ink/40 mt-1">Never shown publicly.</p>
              </div>
            </div>
            <label className="flex items-center gap-2 text-sm text-ink/70 mt-4"><input type="checkbox" checked={form.publicProfile} onChange={(e) => set('publicProfile', e.target.checked)} /> Show my profile publicly in the creator directory</label>
          </div>

          <label className="flex items-start gap-2 text-sm text-ink/70 bg-cream-muted p-4 rounded-xl">
            <input type="checkbox" className="mt-1" data-testid="join-consent" checked={form.consent} onChange={(e) => set('consent', e.target.checked)} />
            I agree that the information provided by me may be used for membership and community management.
          </label>

          <button disabled={saving} className="btn-primary w-full" data-testid="join-submit">{saving ? 'Submitting…' : <>Submit Application <UserPlus className="w-4 h-4" /></>}</button>
        </form>
      </section>
    </div>
  )
}
