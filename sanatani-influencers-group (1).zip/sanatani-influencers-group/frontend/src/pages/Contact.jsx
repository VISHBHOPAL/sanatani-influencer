import { useState } from 'react'
import api from '../lib/api'
import PageHero from '../components/PageHero'
import { useToast } from '../components/ui'
import { useSettings } from '../hooks/useSettings'
import { STOCK } from '../constants'
import { Phone, Mail, MapPin, MessageCircle, Send } from 'lucide-react'

export default function Contact() {
  const s = useSettings()
  const toast = useToast()
  const [form, setForm] = useState({ name: '', mobile: '', email: '', subject: '', message: '' })
  const [saving, setSaving] = useState(false)
  const submit = async (e) => {
    e.preventDefault(); setSaving(true)
    try { await api.post('/contact', form); toast.success('Message sent! We will get back to you soon.'); setForm({ name: '', mobile: '', email: '', subject: '', message: '' }) }
    catch { toast.error('Could not send message') } setSaving(false)
  }
  return (
    <div>
      <PageHero overline="Contact" title="Get in Touch" hindi="संपर्क करें" image={STOCK.temple} />
      <section className="bg-cream section-pad">
        <div className="mx-auto max-w-7xl grid lg:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-bold text-maroon mb-6">Reach out to us</h3>
            <div className="space-y-4">
              {[[MapPin, 'Address', s.address], [Phone, 'Phone', s.phone], [Mail, 'Email', s.email], [MessageCircle, 'WhatsApp', s.whatsapp || 'Updated soon']].map(([Icon, label, val]) => (
                <div key={label} className="flex items-start gap-4 card p-4">
                  <div className="w-10 h-10 rounded-full bg-saffron/10 flex items-center justify-center shrink-0"><Icon className="w-5 h-5 text-saffron" /></div>
                  <div><p className="text-xs uppercase tracking-wide text-ink/50">{label}</p><p className="text-maroon font-medium">{val || 'Updated soon'}</p></div>
                </div>
              ))}
            </div>
            {s.mapsEmbed && <div className="mt-6 rounded-2xl overflow-hidden shadow-card" dangerouslySetInnerHTML={{ __html: s.mapsEmbed }} />}
          </div>
          <div className="card p-8">
            <h3 className="text-xl font-bold text-maroon mb-5">Send a message</h3>
            <form onSubmit={submit} className="space-y-4">
              <div><label className="label">Name *</label><input required className="input" data-testid="contact-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div><label className="label">Mobile</label><input className="input" value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} /></div>
                <div><label className="label">Email *</label><input required type="email" className="input" data-testid="contact-email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
              </div>
              <div><label className="label">Subject</label><input className="input" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} /></div>
              <div><label className="label">Message *</label><textarea required rows="4" className="input" data-testid="contact-message" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} /></div>
              <button disabled={saving} className="btn-primary w-full" data-testid="contact-submit">{saving ? 'Sending…' : <>Send Message <Send className="w-4 h-4" /></>}</button>
            </form>
          </div>
        </div>
      </section>
    </div>
  )
}
