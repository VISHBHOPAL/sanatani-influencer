import { useEffect, useState } from 'react'
import api, { imgUrl } from '../lib/api'
import PageHero from '../components/PageHero'
import { Reveal, Spinner } from '../components/ui'
import { STOCK } from '../constants'
import { Instagram, Linkedin, Mail, User, Quote } from 'lucide-react'

export default function Leadership() {
  const [leaders, setLeaders] = useState(null)
  const [president, setPresident] = useState(null)
  useEffect(() => {
    api.get('/leadership').then((r) => setLeaders(r.data)).catch(() => setLeaders([]))
    api.get('/leadership/president').then((r) => setPresident(r.data)).catch(() => {})
  }, [])
  return (
    <div>
      <PageHero overline="Leadership" title="Leadership & Core Team" hindi="नेतृत्व एवं कोर टीम" image={STOCK.temple} />

      {president && (
        <section className="bg-cream section-pad">
          <div className="mx-auto max-w-5xl">
            <div className="card p-8 lg:p-10 grid md:grid-cols-3 gap-8 items-center bg-gradient-to-br from-white to-cream-muted">
              <div className="md:col-span-1">
                <div className="aspect-square rounded-3xl bg-maroon/10 overflow-hidden ring-4 ring-gold/30">
                  {president.photo ? <img src={imgUrl(president.photo)} alt={president.name} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-maroon/30"><User className="w-16 h-16" /></div>}
                </div>
              </div>
              <div className="md:col-span-2">
                <span className="overline">Adhyaksh</span>
                <h2 className="text-3xl font-bold text-maroon mt-1">{president.name}</h2>
                <p className="text-saffron devanagari text-lg">{president.designation}</p>
                {president.presidentMessage && (
                  <div className="mt-5 bg-maroon/5 rounded-2xl p-5 relative">
                    <Quote className="w-6 h-6 text-gold mb-2" />
                    <p className="devanagari text-ink/75 text-sm font-semibold mb-1">अध्यक्ष का संदेश</p>
                    <p className="text-ink/70 devanagari">{president.presidentMessage}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      <section className="bg-cream-muted section-pad">
        <div className="mx-auto max-w-7xl">
          {leaders === null ? <Spinner /> : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {leaders.map((l, i) => (
                <Reveal key={l.id} delay={(i % 8) * 0.06}>
                  <div className="card p-6 text-center">
                    <div className="w-24 h-24 mx-auto rounded-2xl bg-maroon/10 overflow-hidden">
                      {l.photo ? <img src={imgUrl(l.photo)} alt={l.name} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-maroon/30"><User className="w-8 h-8" /></div>}
                    </div>
                    <h4 className="font-semibold text-maroon mt-4 text-sm">{l.name}</h4>
                    <p className="text-xs text-saffron">{l.designation}</p>
                    {l.bio && <p className="text-xs text-ink/50 mt-2 line-clamp-2">{l.bio}</p>}
                    <div className="flex justify-center gap-2 mt-3">
                      {l.instagram && <a href={l.instagram} target="_blank" rel="noreferrer" className="text-ink/40 hover:text-saffron"><Instagram className="w-4 h-4" /></a>}
                      {l.linkedin && <a href={l.linkedin} target="_blank" rel="noreferrer" className="text-ink/40 hover:text-saffron"><Linkedin className="w-4 h-4" /></a>}
                      {l.contactEnabled && l.email && <a href={`mailto:${l.email}`} className="text-ink/40 hover:text-saffron"><Mail className="w-4 h-4" /></a>}
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
