import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  ArrowRight, Users, Sparkles, HandHeart, Landmark, Calendar, Heart,
  Instagram, Youtube, Quote, Target, Eye, ChevronRight,
} from 'lucide-react'
import api, { imgUrl } from '../lib/api'
import { LOGO, SEVA_PHOTOS, STOCK } from '../constants'
import { useSettings } from '../hooks/useSettings'
import { Reveal, SectionTitle } from '../components/ui'

function CountUp({ value }) {
  const num = parseInt(String(value).replace(/\D/g, '')) || 0
  const suffix = String(value).replace(/[0-9]/g, '')
  const [n, setN] = useState(0)
  useEffect(() => {
    let start = 0
    const dur = 1400, step = Math.max(1, Math.floor(num / (dur / 16)))
    const t = setInterval(() => { start += step; if (start >= num) { start = num; clearInterval(t) } setN(start) }, 16)
    return () => clearInterval(t)
  }, [num])
  return <span>{n}{suffix}</span>
}

const missions = [
  'Promote Indian culture and traditions',
  'Connect creators with meaningful social causes',
  'Encourage youth participation in seva',
  'Support temple cleanliness and preservation',
  'Create positive digital content',
  'Build a responsible creator community',
  'Organize cultural and social initiatives',
]

export default function Home() {
  const s = useSettings()
  const [events, setEvents] = useState([])
  const [creators, setCreators] = useState([])
  const [leaders, setLeaders] = useState([])
  const [gallery, setGallery] = useState([])

  useEffect(() => {
    api.get('/events?status=UPCOMING').then((r) => setEvents(r.data.slice(0, 3))).catch(() => {})
    api.get('/members/public').then((r) => setCreators(r.data.slice(0, 4))).catch(() => {})
    api.get('/leadership').then((r) => setLeaders(r.data.slice(0, 4))).catch(() => {})
    api.get('/gallery').then((r) => setGallery(r.data.slice(0, 6))).catch(() => {})
  }, [])

  const stats = [
    { label: 'Community Members', value: s.statMembers || '1000+', icon: Users },
    { label: 'Digital Creators', value: s.statCreators || '100+', icon: Sparkles },
    { label: 'Temple Seva Projects', value: s.statSeva || '25+', icon: Landmark },
    { label: 'Social Initiatives', value: s.statInitiatives || '40+', icon: HandHeart },
    { label: 'Cultural Events', value: s.statEvents || '50+', icon: Calendar },
  ]

  return (
    <div>
      {/* ---------------- HERO ---------------- */}
      <section className="relative overflow-hidden bg-charcoal">
        <div className="absolute inset-0 grid grid-cols-2 md:grid-cols-4 opacity-40">
          {[STOCK.temple, SEVA_PHOTOS[1], SEVA_PHOTOS[2], STOCK.creator1].map((src, i) => (
            <div key={i} className="relative h-full">
              <img src={src} alt="" className="w-full h-full object-cover" />
            </div>
          ))}
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-charcoal/85 to-charcoal/60" />
        <div className="relative mx-auto max-w-7xl px-5 lg:px-8 py-24 sm:py-32">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="max-w-3xl">
            <div className="inline-flex items-center gap-2 rounded-full bg-white/10 border border-gold/30 px-4 py-1.5 mb-6">
              <img src={LOGO} alt="logo" className="w-6 h-6 rounded-full" />
              <span className="text-cream/90 text-xs tracking-widest uppercase">Bhopal, Madhya Pradesh</span>
            </div>
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold text-cream leading-[1.05]">
              Sanatani <span className="text-saffron">Influencers</span> Group
            </h1>
            <p className="mt-4 text-gold devanagari text-lg sm:text-xl">जुड़ें संस्कृति से, जुड़ें सेवा से, जुड़ें सनातन से</p>
            <p className="mt-6 text-cream/75 text-base sm:text-lg leading-relaxed max-w-2xl devanagari">
              {s.heroSubtitle || 'एक ऐसा creator community platform जो digital creators को Sanatan culture, seva, social responsibility और community initiatives से जोड़ता है।'}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/join" className="btn-primary" data-testid="hero-join-btn">Join the Group <ArrowRight className="w-4 h-4" /></Link>
              <Link to="/volunteer" className="btn-gold" data-testid="hero-volunteer-btn">Become a Volunteer</Link>
              <Link to="/donate" className="btn-secondary !border-cream/40 !text-cream hover:!bg-cream hover:!text-maroon" data-testid="hero-donate-btn"><Heart className="w-4 h-4" /> Donate</Link>
              <Link to="/projects" className="inline-flex items-center gap-1 text-cream/80 hover:text-gold px-4 py-3 text-sm font-medium" data-testid="hero-explore-btn">Explore Our Work <ChevronRight className="w-4 h-4" /></Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ---------------- STATS ---------------- */}
      <section className="bg-cream section-pad !py-14">
        <div className="mx-auto max-w-7xl">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {stats.map((st, i) => (
              <Reveal key={st.label} delay={i * 0.08}>
                <div className="card p-6 text-center hover:-translate-y-1 transition-transform" data-testid={`stat-${i}`}>
                  <st.icon className="w-7 h-7 mx-auto text-saffron mb-3" />
                  <p className="text-3xl font-bold text-maroon font-display"><CountUp value={st.value} /></p>
                  <p className="text-xs text-ink/60 mt-1">{st.label}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- ABOUT ---------------- */}
      <section className="bg-cream-muted section-pad">
        <div className="mx-auto max-w-7xl grid lg:grid-cols-2 gap-14 items-center">
          <Reveal>
            <div className="relative">
              <img src={SEVA_PHOTOS[0]} alt="Seva drive" className="rounded-3xl shadow-lift w-full object-cover aspect-[4/3]" />
              <div className="absolute -bottom-6 -right-4 sm:right-6 card p-5 w-48 bg-white">
                <p className="text-2xl font-bold text-saffron font-display">Since 2024</p>
                <p className="text-xs text-ink/60">Serving culture & community across Madhya Pradesh</p>
              </div>
            </div>
          </Reveal>
          <Reveal delay={0.15}>
            <SectionTitle overline="About Us" title="A creator community rooted in Sanatan values" />
            <p className="text-ink/70 leading-relaxed">{s.aboutText || 'Sanatani Influencers Group is a creator/community initiative connecting digital creators and volunteers for promoting cultural awareness, Sanatan traditions, temple seva, social responsibility and positive community initiatives.'}</p>
            <div className="mt-6 grid grid-cols-2 gap-3">
              {['Digital content', 'Creator networking', 'Temple cleanliness', 'Cultural campaigns', 'Religious events', 'Community awareness'].map((w) => (
                <div key={w} className="flex items-center gap-2 text-sm text-maroon"><span className="w-1.5 h-1.5 rounded-full bg-gold" />{w}</div>
              ))}
            </div>
            <Link to="/about" className="btn-secondary mt-8">Read More <ArrowRight className="w-4 h-4" /></Link>
          </Reveal>
        </div>
      </section>

      {/* ---------------- MISSION & VISION ---------------- */}
      <section className="bg-cream section-pad">
        <div className="mx-auto max-w-7xl grid lg:grid-cols-5 gap-8">
          <Reveal className="lg:col-span-3">
            <div className="bg-white rounded-3xl p-8 shadow-card border border-gold/20 h-full">
              <div className="flex items-center gap-3 mb-6"><Target className="w-6 h-6 text-saffron" /><h3 className="text-2xl font-bold text-maroon">Our Mission</h3></div>
              <ul className="space-y-3">
                {missions.map((m, i) => (
                  <li key={i} className="flex gap-3 text-ink/75"><span className="shrink-0 w-6 h-6 rounded-full bg-saffron/10 text-saffron text-xs font-bold flex items-center justify-center mt-0.5">{i + 1}</span>{m}</li>
                ))}
              </ul>
            </div>
          </Reveal>
          <Reveal delay={0.15} className="lg:col-span-2">
            <div className="bg-maroon rounded-3xl p-8 text-cream h-full relative overflow-hidden">
              <img src={STOCK.ganesha} alt="" className="absolute -right-8 -bottom-8 w-48 opacity-20" />
              <div className="relative">
                <div className="flex items-center gap-3 mb-6"><Eye className="w-6 h-6 text-gold" /><h3 className="text-2xl font-bold devanagari">हमारी दृष्टि</h3></div>
                <p className="text-cream/85 leading-relaxed devanagari">{s.visionText || 'एक ऐसी युवा और डिजिटल community का निर्माण करना जो अपनी संस्कृति, परंपराओं और सामाजिक जिम्मेदारियों से जुड़ी रहे और technology तथा social media का उपयोग सकारात्मक परिवर्तन के लिए करे।'}</p>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ---------------- TEMPLE SEVA CTA ---------------- */}
      <section className="relative section-pad overflow-hidden">
        <img src={SEVA_PHOTOS[2]} alt="Temple seva" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-charcoal/90 to-maroon/70" />
        <div className="relative mx-auto max-w-7xl text-center">
          <Reveal>
            <p className="overline !text-gold mb-3">Temple Seva</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-cream max-w-2xl mx-auto devanagari">क्या आप हमारे अगले Seva Abhiyan का हिस्सा बनना चाहते हैं?</h2>
            <Link to="/volunteer" className="btn-primary mt-8">Volunteer Now <HandHeart className="w-4 h-4" /></Link>
          </Reveal>
        </div>
      </section>

      {/* ---------------- UPCOMING EVENTS ---------------- */}
      <section className="bg-cream-muted section-pad">
        <div className="mx-auto max-w-7xl">
          <div className="flex items-end justify-between mb-10">
            <SectionTitle overline="Events" title="Upcoming Events" />
            <Link to="/events" className="hidden sm:inline-flex text-maroon hover:text-saffron font-medium items-center gap-1">View all <ArrowRight className="w-4 h-4" /></Link>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {events.length === 0 && <p className="text-ink/50 col-span-3">No upcoming events yet. Check back soon.</p>}
            {events.map((e, i) => (
              <Reveal key={e.id} delay={i * 0.1}>
                <Link to={`/events/${e.id}`} className="card block hover:-translate-y-1 transition-transform" data-testid={`home-event-${e.id}`}>
                  <div className="h-40 bg-maroon/10 relative">
                    <img src={e.banner ? imgUrl(e.banner) : STOCK.culture2} alt={e.name} className="w-full h-full object-cover" />
                    <span className="absolute top-3 left-3 bg-saffron text-white text-xs px-3 py-1 rounded-full">{e.category}</span>
                  </div>
                  <div className="p-5">
                    <p className="text-xs text-saffron flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{e.date}</p>
                    <h4 className="font-semibold text-maroon mt-2 line-clamp-2">{e.name}</h4>
                    <p className="text-sm text-ink/60 mt-1">{e.venue}</p>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- CREATOR COMMUNITY ---------------- */}
      <section className="bg-cream section-pad">
        <div className="mx-auto max-w-7xl">
          <SectionTitle center overline="Creator Community" title="Meet Our Sanatani Creators" subtitle="Digital creators using their voice for culture, seva and positive change." />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {creators.map((c, i) => (
              <Reveal key={c.id} delay={i * 0.08}>
                <div className="card p-6 text-center hover:-translate-y-1 transition-transform">
                  <div className="w-20 h-20 mx-auto rounded-full bg-saffron/10 overflow-hidden ring-2 ring-gold/30">
                    <img src={c.profilePhoto ? imgUrl(c.profilePhoto) : STOCK.creator1} alt={c.fullName} className="w-full h-full object-cover" />
                  </div>
                  <h4 className="font-semibold text-maroon mt-4 text-sm">{c.fullName}</h4>
                  <p className="text-xs text-saffron">{c.creatorCategory}</p>
                  <p className="text-xs text-ink/50 mt-1">{c.city}</p>
                </div>
              </Reveal>
            ))}
            {creators.length === 0 && <p className="text-ink/50 col-span-4 text-center">Creators will appear here soon.</p>}
          </div>
          <div className="text-center mt-10"><Link to="/creators" className="btn-secondary">Explore Directory <ArrowRight className="w-4 h-4" /></Link></div>
        </div>
      </section>

      {/* ---------------- LEADERSHIP ---------------- */}
      <section className="bg-cream-muted section-pad">
        <div className="mx-auto max-w-7xl">
          <SectionTitle center overline="Leadership" title="Leadership & Core Team" subtitle="Official information will be updated by the organization." />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {leaders.map((l, i) => (
              <Reveal key={l.id} delay={i * 0.08}>
                <div className="card p-6 text-center">
                  <div className="w-24 h-24 mx-auto rounded-2xl bg-maroon/10 overflow-hidden">
                    {l.photo ? <img src={imgUrl(l.photo)} alt={l.name} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-maroon/30"><Users className="w-8 h-8" /></div>}
                  </div>
                  <h4 className="font-semibold text-maroon mt-4 text-sm">{l.name}</h4>
                  <p className="text-xs text-saffron">{l.designation}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <div className="text-center mt-10"><Link to="/leadership" className="btn-secondary">Meet the Team <ArrowRight className="w-4 h-4" /></Link></div>
        </div>
      </section>

      {/* ---------------- GALLERY ---------------- */}
      {gallery.length > 0 && (
        <section className="bg-cream section-pad">
          <div className="mx-auto max-w-7xl">
            <SectionTitle overline="Media" title="Moments of Seva & Culture" />
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {gallery.map((g, i) => (
                <Reveal key={g.id} delay={i * 0.05}>
                  <div className={`overflow-hidden rounded-2xl ${i % 5 === 0 ? 'md:row-span-2' : ''}`}>
                    <img src={imgUrl(g.imageUrl)} alt={g.title} className="w-full h-full object-cover aspect-square hover:scale-105 transition-transform duration-500" />
                  </div>
                </Reveal>
              ))}
            </div>
            <div className="text-center mt-10"><Link to="/gallery" className="btn-secondary">View Gallery <ArrowRight className="w-4 h-4" /></Link></div>
          </div>
        </section>
      )}

      {/* ---------------- DONATION + JOIN CTA ---------------- */}
      <section className="bg-charcoal section-pad">
        <div className="mx-auto max-w-7xl grid md:grid-cols-2 gap-6">
          <Reveal>
            <div className="bg-gradient-to-br from-maroon to-maroon-dark rounded-3xl p-10 text-cream h-full">
              <Heart className="w-8 h-8 text-gold mb-4" />
              <h3 className="text-2xl font-bold mb-3">Support Our Seva</h3>
              <p className="text-cream/75 mb-6">Your contribution supports temple seva, cleanliness drives and community initiatives across Bhopal.</p>
              <Link to="/donate" className="btn-gold">Donate Now</Link>
            </div>
          </Reveal>
          <Reveal delay={0.12}>
            <div className="bg-gradient-to-br from-saffron to-saffron-dark rounded-3xl p-10 text-white h-full">
              <Users className="w-8 h-8 text-cream mb-4" />
              <h3 className="text-2xl font-bold mb-3">Become a Member</h3>
              <p className="text-white/85 mb-6">Join a growing community of creators committed to culture, seva and sanskar.</p>
              <Link to="/join" className="inline-flex items-center gap-2 bg-white text-saffron rounded-full px-6 py-3 font-semibold hover:-translate-y-0.5 transition-transform">Join the Group <ArrowRight className="w-4 h-4" /></Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ---------------- FOLLOW ---------------- */}
      <section className="bg-cream section-pad !py-14">
        <div className="mx-auto max-w-7xl text-center">
          <p className="overline mb-2">Follow Our Journey</p>
          <h2 className="text-3xl font-bold text-maroon mb-6">Stay connected with our community</h2>
          <div className="flex justify-center gap-4">
            {s.instagram && <a href={s.instagram} target="_blank" rel="noreferrer" className="btn-secondary"><Instagram className="w-4 h-4" /> Instagram</a>}
            {s.youtube && <a href={s.youtube} target="_blank" rel="noreferrer" className="btn-secondary"><Youtube className="w-4 h-4" /> YouTube</a>}
            {!s.instagram && !s.youtube && <p className="text-ink/50">Social links will be updated soon.</p>}
          </div>
        </div>
      </section>
    </div>
  )
}
