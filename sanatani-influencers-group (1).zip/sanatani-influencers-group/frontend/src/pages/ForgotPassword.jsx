import { useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../lib/api'
import { useToast } from '../components/ui'
import { KeyRound } from 'lucide-react'

export default function ForgotPassword() {
  const toast = useToast()
  const [step, setStep] = useState(1)
  const [email, setEmail] = useState('')
  const [token, setToken] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [saving, setSaving] = useState(false)

  const request = async (e) => {
    e.preventDefault(); setSaving(true)
    try {
      const res = await api.post('/auth/forgot-password', { email })
      const t = res.data?.data?.resetToken
      if (t) { setToken(t); toast.info('Email service not configured — use the reset token shown below.') }
      else toast.success('If the email exists, reset instructions were sent.')
      setStep(2)
    } catch { toast.error('Request failed') }
    setSaving(false)
  }
  const reset = async (e) => {
    e.preventDefault(); setSaving(true)
    try { await api.post('/auth/reset-password', { token, newPassword }); toast.success('Password reset! You can now log in.'); setStep(3) }
    catch (err) { toast.error(err.response?.data?.message || 'Reset failed') }
    setSaving(false)
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-cream section-pad">
      <div className="card p-8 w-full max-w-md">
        <div className="text-center mb-6"><KeyRound className="w-10 h-10 text-saffron mx-auto" /><h1 className="text-2xl font-bold text-maroon mt-3">Reset Password</h1></div>
        {step === 1 && (
          <form onSubmit={request} className="space-y-4">
            <div><label className="label">Your Email</label><input required type="email" className="input" data-testid="forgot-email" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
            <button disabled={saving} className="btn-primary w-full" data-testid="forgot-submit">{saving ? 'Sending…' : 'Send Reset Link'}</button>
          </form>
        )}
        {step === 2 && (
          <form onSubmit={reset} className="space-y-4">
            <div><label className="label">Reset Token</label><input required className="input" data-testid="reset-token" value={token} onChange={(e) => setToken(e.target.value)} /></div>
            <div><label className="label">New Password</label><input required type="password" className="input" data-testid="reset-password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} /></div>
            <button disabled={saving} className="btn-primary w-full" data-testid="reset-submit">{saving ? 'Resetting…' : 'Reset Password'}</button>
          </form>
        )}
        {step === 3 && (
          <div className="text-center"><p className="text-green-700 mb-4">Password reset successfully.</p><Link to="/login" className="btn-primary">Go to Login</Link></div>
        )}
        <p className="text-center text-sm text-ink/50 mt-6"><Link to="/login" className="text-saffron">Back to Login</Link></p>
      </div>
    </div>
  )
}
