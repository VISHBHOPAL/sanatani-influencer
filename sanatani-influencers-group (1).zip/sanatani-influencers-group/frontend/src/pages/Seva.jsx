import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api, { imgUrl } from '../lib/api'
import PageHero from '../components/PageHero'
import { Reveal, Spinner, EmptyState } from '../components/ui'
import { SEVA_PHOTOS, STOCK } from '../constants'
import { MapPin, Users, HandHeart, Landmark } from 'lucide-react'

export default function Seva() {
  const [projects, setProjects] = useState(null)
  useEffect(() => { api.get('/projects/temple-seva').then((r) => setProjects(r.data)).catch(() => setProjects([])) }, [])

  return (
    <div>
      <PageHero overline="Temple Seva" title="Temple Seva Abhiyan" hindi="मंदिर सेवा अभियान"
        subtitle="Cleaning campaigns, renovation support and preservation of temples across Bhopal and Madhya Pradesh."
        image={SEVA_PHOTOS[2]} />

      <section className="bg-cream section-pad">
        <div className="mx-auto max-w-7xl">
          {projects === null ? <Spinner /> : projects.length === 0 ? (
            <EmptyState icon={Landmark} title="No temple seva projects yet" message="Verified seva projects will be published here soon." />
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((p, i) => (
                <Reveal key={p.id} delay={i * 0.08}>
                  <div className="card hover:-translate-y-1 transition-transform" data-testid={`seva-project-${p.id}`}>
                    <div className="grid grid-cols-2 h-44">
                      <div className="relative"><img src={p.beforeImage ? imgUrl(p.beforeImage) : STOCK.seva} className="w-full h-full object-cover" alt="before" /><span className="absolute top-2 left-2 bg-charcoal/70 text-cream text-[10px] px-2 py-0.5 rounded">Before</span></div>
                      <div className="relative"><img src={p.afterImage ? imgUrl(p.afterImage) : SEVA_PHOTOS[0]} className="w-full h-full object-cover" alt="after" /><span className="absolute top-2 left-2 bg-saffron text-white text-[10px] px-2 py-0.5 rounded">After</span></div>
                    </div>
                    <div className="p-5">
                      <span className="text-xs bg-saffron/10 text-saffron px-2 py-0.5 rounded-full">{p.category}</span>
                      <h4 className="font-semibold text-maroon mt-2">{p.name}</h4>
                      <p className="text-sm text-ink/60 mt-1 line-clamp-2">{p.description}</p>
                      <div className="flex items-center gap-4 mt-3 text-xs text-ink/60">
                        <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{p.location}</span>
                        <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" />{p.volunteersCount} volunteers</span>
                      </div>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="relative section-pad overflow-hidden">
        <img src={SEVA_PHOTOS[1]} alt="" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-charcoal/90 to-maroon/70" />
        <div className="relative mx-auto max-w-7xl text-center">
          <h2 className="text-3xl font-bold text-cream max-w-2xl mx-auto devanagari">क्या आप हमारे अगले Seva Abhiyan का हिस्सा बनना चाहते हैं?</h2>
          <Link to="/volunteer" className="btn-primary mt-8">Volunteer Now <HandHeart className="w-4 h-4" /></Link>
        </div>
      </section>
    </div>
  )
}
