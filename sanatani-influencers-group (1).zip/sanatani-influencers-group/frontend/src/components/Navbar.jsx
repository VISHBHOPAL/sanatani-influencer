import { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { Menu, X, ChevronDown, LogOut, LayoutDashboard, User } from 'lucide-react'
import { LOGO } from '../constants'
import { useAuth } from '../context/AuthContext'

const links = [
  { to: '/', label: 'Home' },
  { to: '/about', label: 'About' },
  { to: '/seva', label: 'Temple Seva' },
  { to: '/projects', label: 'Our Work' },
  { to: '/events', label: 'Events' },
  { to: '/creators', label: 'Creators' },
  { to: '/gallery', label: 'Gallery' },
  { to: '/leadership', label: 'Team' },
  { to: '/news', label: 'News' },
  { to: '/contact', label: 'Contact' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const { user, isAdmin, logout } = useAuth()
  const navigate = useNavigate()

  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-cream/80 border-b border-maroon/10">
      <nav className="mx-auto max-w-7xl px-5 lg:px-8 h-[72px] flex items-center justify-between gap-4">
        <Link to="/" className="flex items-center gap-3 shrink-0" data-testid="nav-logo">
          <img src={LOGO} alt="Sanatani Influencers Group" className="w-11 h-11 rounded-full object-cover ring-2 ring-gold/40" />
          <div className="hidden sm:block leading-tight">
            <p className="font-display font-bold text-maroon text-[15px]">Sanatani Influencers</p>
            <p className="text-[10px] tracking-widest uppercase text-saffron">Group • Bhopal</p>
          </div>
        </Link>

        <div className="hidden xl:flex items-center gap-1">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `px-3 py-2 text-sm font-medium rounded-full transition-colors ${isActive ? 'text-saffron' : 'text-ink/70 hover:text-maroon'}`}
              data-testid={`nav-link-${l.label.toLowerCase().replace(/\s/g, '-')}`}
            >
              {l.label}
            </NavLink>
          ))}
        </div>

        <div className="flex items-center gap-2">
          {user ? (
            <div className="hidden sm:flex items-center gap-2">
              {isAdmin ? (
                <Link to="/admin" className="btn-secondary !py-2 !px-4 text-sm" data-testid="nav-admin-btn"><LayoutDashboard className="w-4 h-4" /> Admin</Link>
              ) : (
                <Link to="/portal" className="btn-secondary !py-2 !px-4 text-sm" data-testid="nav-portal-btn"><User className="w-4 h-4" /> My Portal</Link>
              )}
              <button onClick={() => { logout(); navigate('/') }} className="p-2 text-ink/60 hover:text-maroon" data-testid="nav-logout-btn"><LogOut className="w-5 h-5" /></button>
            </div>
          ) : (
            <Link to="/login" className="hidden sm:inline-flex text-sm font-medium text-maroon hover:text-saffron px-3 py-2" data-testid="nav-login-btn">Login</Link>
          )}
          <Link to="/join" className="hidden sm:inline-flex btn-primary !py-2.5 !px-5 text-sm" data-testid="nav-join-btn">Join the Group</Link>
          <button className="xl:hidden p-2 text-maroon" onClick={() => setOpen(!open)} data-testid="nav-hamburger">
            {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      {open && (
        <div className="xl:hidden border-t border-maroon/10 bg-cream px-5 py-4 flex flex-col gap-1" data-testid="mobile-menu">
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} onClick={() => setOpen(false)}
              className={({ isActive }) => `px-3 py-2.5 rounded-lg font-medium ${isActive ? 'bg-saffron/10 text-saffron' : 'text-ink/80'}`}>
              {l.label}
            </NavLink>
          ))}
          <div className="flex flex-col gap-2 mt-3 pt-3 border-t border-maroon/10">
            {user ? (
              <>
                <Link to={isAdmin ? '/admin' : '/portal'} onClick={() => setOpen(false)} className="btn-secondary">{isAdmin ? 'Admin Dashboard' : 'My Portal'}</Link>
                <button onClick={() => { logout(); setOpen(false); navigate('/') }} className="text-maroon text-sm py-2">Logout</button>
              </>
            ) : (
              <Link to="/login" onClick={() => setOpen(false)} className="btn-secondary">Login</Link>
            )}
            <Link to="/join" onClick={() => setOpen(false)} className="btn-primary">Join the Group</Link>
          </div>
        </div>
      )}
    </header>
  )
}
