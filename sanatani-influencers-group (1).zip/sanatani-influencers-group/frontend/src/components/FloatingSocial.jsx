import { Instagram, Youtube, Facebook, MessageCircle } from 'lucide-react'
import { useSettings } from '../hooks/useSettings'

export default function FloatingSocial() {
  const s = useSettings()
  const items = [
    { href: s.instagram, icon: Instagram, bg: 'bg-gradient-to-br from-pink-500 to-orange-400', show: s.instagram },
    { href: s.youtube, icon: Youtube, bg: 'bg-red-600', show: s.youtube },
    { href: s.facebook, icon: Facebook, bg: 'bg-blue-600', show: s.facebook },
    { href: s.whatsapp ? `https://wa.me/${s.whatsapp.replace(/\D/g, '')}` : '', icon: MessageCircle, bg: 'bg-green-500', show: s.whatsapp },
  ].filter((i) => i.show)

  if (items.length === 0) return null
  return (
    <div className="fixed right-4 bottom-24 sm:bottom-6 z-40 flex flex-col gap-3" data-testid="floating-social">
      {items.map((i, idx) => {
        const Icon = i.icon
        return (
          <a key={idx} href={i.href} target="_blank" rel="noreferrer"
            className={`w-11 h-11 rounded-full ${i.bg} text-white flex items-center justify-center shadow-lift hover:scale-110 transition-transform`}>
            <Icon className="w-5 h-5" />
          </a>
        )
      })}
    </div>
  )
}
