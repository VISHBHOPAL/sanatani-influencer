import { createContext, useContext, useState, useCallback } from 'react'
import { motion, AnimatePresence, useInView } from 'framer-motion'
import { useRef } from 'react'
import { CheckCircle2, XCircle, Info, Loader2 } from 'lucide-react'

/* ---------------- Scroll reveal ---------------- */
export function Reveal({ children, delay = 0, className = '' }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-60px' })
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 28 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay, ease: 'easeOut' }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

/* ---------------- Section heading ---------------- */
export function SectionTitle({ overline, title, subtitle, hindi, center = false, light = false }) {
  return (
    <div className={`max-w-2xl ${center ? 'mx-auto text-center' : ''} mb-12`}>
      {overline && <p className="overline mb-3">{overline}</p>}
      <h2 className={`text-3xl sm:text-4xl lg:text-5xl font-bold leading-tight ${light ? 'text-cream' : 'text-maroon'}`}>{title}</h2>
      {hindi && <p className={`devanagari mt-2 text-xl ${light ? 'text-gold' : 'text-saffron'}`}>{hindi}</p>}
      {subtitle && <p className={`mt-4 text-base leading-relaxed ${light ? 'text-cream/70' : 'text-ink/70'}`}>{subtitle}</p>}
    </div>
  )
}

/* ---------------- Loader ---------------- */
export function Spinner({ label }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-maroon/60" data-testid="loading-spinner">
      <Loader2 className="w-8 h-8 animate-spin mb-3" />
      {label && <p className="text-sm">{label}</p>}
    </div>
  )
}

/* ---------------- Empty state ---------------- */
export function EmptyState({ icon: Icon = Info, title, message }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center" data-testid="empty-state">
      <div className="w-16 h-16 rounded-full bg-cream-muted flex items-center justify-center mb-4">
        <Icon className="w-7 h-7 text-maroon/50" />
      </div>
      <h3 className="text-xl font-semibold text-maroon">{title}</h3>
      {message && <p className="mt-2 text-ink/60 max-w-md">{message}</p>}
    </div>
  )
}

/* ---------------- Toast ---------------- */
const ToastCtx = createContext(null)
export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([])
  const push = useCallback((type, msg) => {
    const id = Date.now() + Math.random()
    setToasts((t) => [...t, { id, type, msg }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4000)
  }, [])
  const toast = {
    success: (m) => push('success', m),
    error: (m) => push('error', m),
    info: (m) => push('info', m),
  }
  const iconFor = { success: CheckCircle2, error: XCircle, info: Info }
  const colorFor = { success: 'border-green-500 text-green-700', error: 'border-red-500 text-red-700', info: 'border-saffron text-saffron' }
  return (
    <ToastCtx.Provider value={toast}>
      {children}
      <div className="fixed top-5 right-5 z-[100] flex flex-col gap-3 w-[calc(100%-2.5rem)] sm:w-96">
        <AnimatePresence>
          {toasts.map((t) => {
            const Icon = iconFor[t.type]
            return (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, x: 40 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 40 }}
                className={`bg-white rounded-xl shadow-lift border-l-4 ${colorFor[t.type]} px-4 py-3 flex items-start gap-3`}
                data-testid={`toast-${t.type}`}
              >
                <Icon className="w-5 h-5 mt-0.5 shrink-0" />
                <p className="text-sm text-ink">{t.msg}</p>
              </motion.div>
            )
          })}
        </AnimatePresence>
      </div>
    </ToastCtx.Provider>
  )
}
export const useToast = () => useContext(ToastCtx)

/* ---------------- Modal ---------------- */
export function Modal({ open, onClose, title, children, testid }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[90] flex items-center justify-center p-4 bg-charcoal/60 backdrop-blur-sm"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          onClick={onClose}
          data-testid={testid}
        >
          <motion.div
            className="bg-white rounded-2xl shadow-lift w-full max-w-lg max-h-[90vh] overflow-y-auto"
            initial={{ scale: 0.95, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 20 }}
            onClick={(e) => e.stopPropagation()}
          >
            {title && (
              <div className="px-6 py-4 border-b border-cream-muted flex items-center justify-between sticky top-0 bg-white">
                <h3 className="text-xl font-semibold text-maroon">{title}</h3>
                <button onClick={onClose} className="text-ink/40 hover:text-maroon" data-testid="modal-close"><XCircle className="w-6 h-6" /></button>
              </div>
            )}
            <div className="p-6">{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
