import { Link } from 'react-router-dom'
import { Instagram, Youtube, Facebook, MapPin, Mail, Phone } from 'lucide-react'
import { LOGO } from '../constants'
import { useSettings } from '../hooks/useSettings'

export default function Footer() {
  const s = useSettings()
  return (
    <footer className="bg-charcoal text-cream/80" data-testid="site-footer">
      <div className="mx-auto max-w-7xl px-5 lg:px-8 py-16 grid gap-10 md:grid-cols-2 lg:grid-cols-4">
        <div className="lg:col-span-1">
          <div className="flex items-center gap-3 mb-4">
            <img src={LOGO} alt="logo" className="w-12 h-12 rounded-full object-cover ring-2 ring-gold/40" />
            <span className="font-display font-bold text-cream text-lg">Sanatani Influencers Group</span>
          </div>
          <p className="text-sm leading-relaxed text-cream/60">
            A creator community connecting digital creators with Sanatan culture, temple seva, social responsibility and community initiatives.
          </p>
          <p className="devanagari mt-4 text-gold text-sm">जुड़ें संस्कृति से, जुड़ें सेवा से, जुड़ें सनातन से</p>
        </div>

        <div>
          <h4 className="text-cream font-semibold mb-4">Quick Links</h4>
          <ul className="space-y-2 text-sm">
            {[['About', '/about'], ['Join', '/join'], ['Events', '/events'], ['Temple Seva', '/seva'], ['Gallery', '/gallery'], ['Donation', '/donate'], ['Contact', '/contact']].map(([l, to]) => (
              <li key={to}><Link to={to} className="hover:text-gold transition-colors">{l}</Link></li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="text-cream font-semibold mb-4">Community</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/creators" className="hover:text-gold">Creators</Link></li>
            <li><Link to="/volunteer" className="hover:text-gold">Volunteers</Link></li>
            <li><Link to="/donation-report" className="hover:text-gold">Donation Reports</Link></li>
            <li><Link to="/verify-certificate" className="hover:text-gold">Verify Certificate</Link></li>
          </ul>
          <h4 className="text-cream font-semibold mb-3 mt-6">Legal</h4>
          <ul className="space-y-2 text-sm text-cream/60">
            <li>Privacy Policy</li><li>Terms & Conditions</li><li>Donation & Refund Policy</li>
          </ul>
        </div>

        <div>
          <h4 className="text-cream font-semibold mb-4">Get in Touch</h4>
          <ul className="space-y-3 text-sm text-cream/70">
            <li className="flex gap-2"><MapPin className="w-4 h-4 text-gold shrink-0 mt-0.5" />{s.address || 'Bhopal, Madhya Pradesh, India'}</li>
            <li className="flex gap-2"><Phone className="w-4 h-4 text-gold shrink-0 mt-0.5" />{s.phone || 'Updated soon'}</li>
            <li className="flex gap-2"><Mail className="w-4 h-4 text-gold shrink-0 mt-0.5" />{s.email || 'Updated soon'}</li>
          </ul>
          <div className="flex gap-3 mt-5">
            {s.instagram && <a href={s.instagram} target="_blank" rel="noreferrer" className="p-2 rounded-full bg-white/10 hover:bg-saffron transition-colors"><Instagram className="w-4 h-4" /></a>}
            {s.youtube && <a href={s.youtube} target="_blank" rel="noreferrer" className="p-2 rounded-full bg-white/10 hover:bg-saffron transition-colors"><Youtube className="w-4 h-4" /></a>}
            {s.facebook && <a href={s.facebook} target="_blank" rel="noreferrer" className="p-2 rounded-full bg-white/10 hover:bg-saffron transition-colors"><Facebook className="w-4 h-4" /></a>}
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 py-6 text-center text-xs text-cream/50">
        © 2026 Sanatani Influencers Group. All Rights Reserved.
      </div>
    </footer>
  )
}
