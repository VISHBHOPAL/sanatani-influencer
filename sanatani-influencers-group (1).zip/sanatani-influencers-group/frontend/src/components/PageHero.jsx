import { STOCK } from '../constants'

export default function PageHero({ overline, title, hindi, subtitle, image = STOCK.temple }) {
  return (
    <section className="relative bg-charcoal overflow-hidden">
      <img src={image} alt="" className="absolute inset-0 w-full h-full object-cover opacity-30" />
      <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-charcoal/80 to-charcoal/50" />
      <div className="relative mx-auto max-w-7xl px-5 lg:px-8 py-20 sm:py-24">
        {overline && <p className="overline !text-gold mb-3">{overline}</p>}
        <h1 className="text-4xl sm:text-5xl font-bold text-cream">{title}</h1>
        {hindi && <p className="devanagari mt-2 text-xl text-gold">{hindi}</p>}
        {subtitle && <p className="mt-4 text-cream/70 max-w-2xl">{subtitle}</p>}
      </div>
    </section>
  )
}
