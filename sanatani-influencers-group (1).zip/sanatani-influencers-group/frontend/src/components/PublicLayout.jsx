import { Link, Outlet } from 'react-router-dom'
import Navbar from './Navbar'
import Footer from './Footer'
import FloatingSocial from './FloatingSocial'
import { Sparkles } from 'lucide-react'

export default function PublicLayout() {
  return (
    <div className="min-h-screen flex flex-col">
      <div className="bg-maroon text-cream text-center text-xs sm:text-sm py-2 px-4 flex items-center justify-center gap-2" data-testid="announcement-bar">
        <Sparkles className="w-3.5 h-3.5 text-gold" />
        <span className="devanagari">जुड़ें संस्कृति से, जुड़ें सेवा से, जुड़ें सनातन से</span>
      </div>
      <Navbar />
      <main className="flex-1"><Outlet /></main>
      <Footer />
      <FloatingSocial />
      {/* Sticky mobile CTA */}
      <Link to="/join" className="sm:hidden fixed bottom-0 inset-x-0 z-40 bg-saffron text-white text-center py-3.5 font-semibold shadow-lift" data-testid="sticky-mobile-cta">
        Join Group
      </Link>
    </div>
  )
}
