import { useEffect, useState } from 'react'
import api from '../lib/api'

let cache = null
export function useSettings() {
  const [settings, setSettings] = useState(cache || {})
  useEffect(() => {
    if (cache) return
    api.get('/settings/public').then((res) => { cache = res.data; setSettings(res.data) }).catch(() => {})
  }, [])
  return settings
}
