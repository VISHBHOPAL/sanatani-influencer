import { Routes, Route, Navigate } from 'react-router-dom'
import { ToastProvider } from './components/ui'
import PublicLayout from './components/PublicLayout'
import { useAuth } from './context/AuthContext'
import { Spinner } from './components/ui'

import Home from './pages/Home'
import About from './pages/About'
import Events from './pages/Events'
import EventDetail from './pages/EventDetail'
import Join from './pages/Join'
import Donate from './pages/Donate'
import DonationReport from './pages/DonationReport'
import Seva from './pages/Seva'
import Projects from './pages/Projects'
import Gallery from './pages/Gallery'
import Leadership from './pages/Leadership'
import Creators from './pages/Creators'
import News from './pages/News'
import Contact from './pages/Contact'
import Volunteer from './pages/Volunteer'
import VerifyCertificate from './pages/VerifyCertificate'
import Login from './pages/Login'
import ForgotPassword from './pages/ForgotPassword'
import MemberPortal from './pages/MemberPortal'
import AdminApp from './pages/admin/AdminApp'

function Protected({ children, admin }) {
  const { user, isAdmin, loading } = useAuth()
  if (loading) return <Spinner label="Loading…" />
  if (!user) return <Navigate to="/login" replace />
  if (admin && !isAdmin) return <Navigate to="/portal" replace />
  return children
}

export default function App() {
  return (
    <ToastProvider>
      <Routes>
        <Route element={<PublicLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/events" element={<Events />} />
          <Route path="/events/:id" element={<EventDetail />} />
          <Route path="/join" element={<Join />} />
          <Route path="/donate" element={<Donate />} />
          <Route path="/donation-report" element={<DonationReport />} />
          <Route path="/seva" element={<Seva />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/leadership" element={<Leadership />} />
          <Route path="/creators" element={<Creators />} />
          <Route path="/news" element={<News />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/volunteer" element={<Volunteer />} />
          <Route path="/verify-certificate" element={<VerifyCertificate />} />
          <Route path="/verify-certificate/:number" element={<VerifyCertificate />} />
          <Route path="/login" element={<Login />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/portal" element={<Protected><MemberPortal /></Protected>} />
        </Route>
        <Route path="/admin/*" element={<Protected admin><AdminApp /></Protected>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </ToastProvider>
  )
}
