// Brand assets (official uploaded by organization)
export const LOGO = "https://customer-assets-39nsmqrw.emergentagent.net/job_bhopal-influencers/artifacts/ml00va44_sanatani%20logo.jpeg"

export const SEVA_PHOTOS = [
  "https://customer-assets-39nsmqrw.emergentagent.net/job_bhopal-influencers/artifacts/4idh03ay_WhatsApp%20Image%202026-08-23%20at%205.14.54%20PM%20%282%29.jpeg",
  "https://customer-assets-39nsmqrw.emergentagent.net/job_bhopal-influencers/artifacts/6fy719qh_WhatsApp%20Image%202026-08-23%20at%205.14.58%20PM.jpeg",
  "https://customer-assets-39nsmqrw.emergentagent.net/job_bhopal-influencers/artifacts/op2zzkzo_WhatsApp%20Image%202026-08-23%20at%205.16.15%20PM.jpeg",
  "https://customer-assets-39nsmqrw.emergentagent.net/job_bhopal-influencers/artifacts/3ro2bsq3_WhatsApp%20Image%202026-08-23%20at%205.16.15%20PM%20%281%29.jpeg",
]

export const STOCK = {
  temple: "https://images.unsplash.com/photo-1715876722520-02ccc9248dab?w=1200&q=80",
  ganesha: "https://images.unsplash.com/photo-1598090216740-eb040d8c3f82?w=800&q=80",
  culture1: "https://images.unsplash.com/photo-1514178703120-3fa66528901d?w=800&q=80",
  culture2: "https://images.unsplash.com/photo-1587271636175-90d58cdad458?w=800&q=80",
  creator1: "https://images.unsplash.com/photo-1780919308555-f565f7fb761f?w=800&q=80",
  creator2: "https://images.unsplash.com/photo-1618245472177-2a74ad3b994a?w=800&q=80",
  seva: "https://images.unsplash.com/photo-1524069290683-0457abfe42c3?w=800&q=80",
}

export const CREATOR_CATEGORIES = [
  "Vlogger", "Instagram Creator", "YouTuber", "Photographer", "Videographer",
  "Editor", "Graphic Designer", "Podcaster", "Singer", "Artist",
  "Religious Content Creator", "Cultural Creator", "Social Worker",
]

export const PROJECT_CATEGORIES = [
  "Temple Seva", "Cleanliness Drive", "Cultural Event", "Social Work",
  "Creator Campaign", "Youth Initiative", "Religious Event",
]

export const EVENT_CATEGORIES = [
  "Sanatan Event", "Temple Event", "Creator Meet", "Workshop",
  "Social Work", "Cultural Program", "Religious Event",
]

export const DONATION_CATEGORIES = [
  "Temple Seva", "Temple Cleaning", "Social Work", "Cultural Events",
  "Community Support", "General Donation",
]

export const VOLUNTEER_CATEGORIES = [
  "Temple Seva", "Event Management", "Photography", "Videography",
  "Social Media", "Graphic Design", "Content Writing", "Ground Operations", "Public Relations",
]

export const GALLERY_CATEGORIES = [
  "Events", "Temple Seva", "Creator Meets", "Cultural Programs", "Social Work", "Behind The Scenes",
]

export const INDIAN_STATES = [
  "Madhya Pradesh", "Uttar Pradesh", "Maharashtra", "Rajasthan", "Gujarat",
  "Delhi", "Karnataka", "Bihar", "Chhattisgarh", "Other",
]
