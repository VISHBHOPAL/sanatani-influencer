/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        saffron: "#D94A1C",
        "saffron-dark": "#b83d16",
        maroon: "#6A1A22",
        "maroon-dark": "#4d1219",
        gold: "#D4AF37",
        cream: "#F9F8F6",
        "cream-muted": "#F3F1EC",
        charcoal: "#1C1C1C",
        ink: "#2D2D2D",
      },
      fontFamily: {
        display: ["'Playfair Display'", "serif"],
        sans: ["Outfit", "sans-serif"],
        deva: ["Mukta", "sans-serif"],
      },
      boxShadow: {
        soft: "0 2px 8px rgba(106,26,34,0.05)",
        card: "0 4px 16px rgba(106,26,34,0.08)",
        lift: "0 12px 32px rgba(106,26,34,0.12)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(24px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "float-slow": {
          "0%,100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-10px)" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.7s ease-out forwards",
        "float-slow": "float-slow 6s ease-in-out infinite",
      },
    },
  },
  plugins: [],
}
