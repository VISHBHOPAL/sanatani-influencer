# Sanatani Influencers Group — Full-Stack Platform

Premium community platform for **Sanatani Influencers Group, Bhopal (MP)** — public website + member portal + admin dashboard.

- **Backend:** Java 17 · Spring Boot 3 · Spring Security (JWT) · Spring Data JPA
- **Database:** MySQL 8 (H2 in-memory option for instant testing)
- **Frontend:** React 18 · Vite · Tailwind CSS · Framer Motion · Axios

---

## 1. Prerequisites
- Java 17+ and Maven 3.8+
- Node 18+ and Yarn
- MySQL 8 (optional — you can run with H2 for a quick demo)

## 2. Quick Start (H2 — no database setup needed)
```bash
cd backend
mvn spring-boot:run -Dspring-boot.run.profiles=h2
# API runs at http://localhost:8080/api  (seeds demo data on start)
```
In a second terminal:
```bash
cd frontend
yarn install
yarn dev
# Website at http://localhost:5173
```

## 3. Run with MySQL (recommended for production)
1. Create the database (auto-created if the user has privileges):
   ```sql
   CREATE DATABASE sanatani_sig CHARACTER SET utf8mb4;
   ```
2. Set backend environment variables (or edit `backend/src/main/resources/application.properties`):
   ```bash
   export DB_HOST=localhost DB_PORT=3306 DB_NAME=sanatani_sig
   export DB_USERNAME=root DB_PASSWORD=yourpassword
   export JWT_SECRET="a-very-long-random-secret"
   cd backend && mvn spring-boot:run
   ```
3. Start the frontend as above.

## 4. Docker (one command)
```bash
docker compose up --build
# frontend: http://localhost:5173  ·  backend: http://localhost:8080  ·  mysql: 3306
```

## 5. Default Admin Login
| Email | Password |
|-------|----------|
| `admin@sanataniinfluencers.org` | `Admin@12345` |

Change these via `SUPERADMIN_EMAIL` / `SUPERADMIN_PASSWORD` env vars. Approved members get a login (temporary password = their Member ID; use *Forgot Password* to reset).

## 6. Integrations (ready-to-configure)
All external services are wired but disabled until you add credentials — nothing is faked.

| Service | Env vars | Effect when unset |
|--------|----------|-------------------|
| Razorpay | `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET` | Donations are recorded as PENDING; UI shows "gateway not configured" |
| Email/SMTP | `MAIL_ENABLED`, `MAIL_FROM` | Reset token returned in API response instead of email |
| File uploads | `UPLOAD_DIR` (default `uploads/`) | Local disk storage, served at `/uploads/**` |

## 7. Key Features
Public site (Home, About, Temple Seva, Projects, Events + registration, Creator Directory, Gallery, Leadership + Adhyaksh message, News, Achievements, Partners, Contact, Volunteer, Donate, Donation Report, Certificate verification) · JWT auth with 6 roles · Member apply → admin approve → Member ID + digital membership card with QR · Admin dashboard with stats & charts and full CMS/CRUD over every content type · Audit logging · CSV export.

## 8. Project Structure
```
sanatani-influencers-group/
├── backend/    Spring Boot API (com.sanatani.sig)
├── frontend/   React + Vite app
└── docker-compose.yml
```

## 9. Main API Endpoints
`POST /api/auth/login|register|forgot-password|reset-password` · `GET/POST /api/members/apply` · `GET /api/events` `POST /api/events/{id}/register` · `POST /api/donations/create|verify` · `GET /api/certificates/verify/{number}` · `GET /api/leadership|projects|gallery|news|partners|achievements` · protected `GET/POST/PUT/DELETE /api/admin/**`.

---
© 2026 Sanatani Influencers Group. Built as a modular, production-ready platform.
